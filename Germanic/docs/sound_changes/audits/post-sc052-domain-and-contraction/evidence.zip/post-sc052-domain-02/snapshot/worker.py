import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

sys.path.insert(0, "/usr/app/tools")
from executable_facts import parse_defines
from probe import native


def run(commands, label):
    result = native(commands, output)
    (output / (label + ".native.json")).write_text(json.dumps(result, ensure_ascii=False))
    assert result["returncode"] == 0
    assert not any(s in result["stdout"] + result["stderr"]
                   for s in ("***Unknown", "Syntax error", "***Error"))


def export(expression, label):
    return ["clear stack", f"regex {expression};", f"save stack {label}.bin",
            f"write att > {label}.att"]


def lookup(path, words):
    result = subprocess.run(["flookup", "-i", str(path)], input="\n".join(words) + "\n",
                            capture_output=True, text=True, check=True)
    found = {word: [] for word in words}
    for line in result.stdout.splitlines():
        if "\t" in line:
            word, value = line.split("\t", 1)
            if value != "+?" and value not in found[word]:
                found[word].append(value)
    return {key: sorted(value) for key, value in found.items()}


snapshot, output = map(Path, sys.argv[1:3])
output.mkdir()
source = (snapshot / "fst.txt").read_text()
facts = parse_defines(source)
definitions = re.sub(
    r"(?m)^\s*(?:clear stack|save stack [^\n;]+|regex [A-Za-z][A-Za-z0-9_]*\s*;)\s*$",
    "", source)
(output / "definitions.txt").write_text(definitions)
commands = [f"source {output / 'definitions.txt'}", "define OriginalParser EnglishProtoInput;"]
for name in ("pgrmStrongPlainHeavy", "pgrmSimpleWord", "pgrmWord",
             "EnglishProtoNative", "PGCellRoot", "PGCellInput", "EnglishProtoInput"):
    commands += export(name, name)
commands += export("EnglishProtoInput.u", "upper-domain")
commands += export("EnglishProtoInput.l", "lower-domain")
commands += ["define OriginalFull OldEnglish;"]
commands += export("[EnglishProtoInput.u - OriginalFull.u]", "original-domain-difference")
variants = {}
for label, names in (
    ("mandatory-heavy", ("pgrmStrongPlainHeavy",)),
    ("mandatory-simple", ("pgrmSimpleWord",)),
    ("mandatory-both", ("pgrmStrongPlainHeavy", "pgrmSimpleWord")),
):
    candidate = source
    for name in names:
        raw = facts[name].definition_raw
        assert raw.count("(") == (1 if name == "pgrmStrongPlainHeavy" else 5)
        candidate = candidate.replace(raw, raw.replace("(", "[").replace(")", "]"), 1)
    variants[label] = {"definitions": list(names),
                       "source_sha256": hashlib.sha256(candidate.encode()).hexdigest()}
    (output / (label + ".txt")).write_text(candidate)
    path = output / (label + "-definitions.txt")
    grammar_end = candidate.index("## Proto-Germanic starred inventories")
    parser_start = candidate.index("define EnglishProtoNative [")
    parser_end = candidate.index("define OldEnglishCore ")
    parser_definitions = candidate[:grammar_end] + "\n" + candidate[parser_start:parser_end]
    if label == "mandatory-both":
        parsed = parse_defines(candidate)
        parser_definitions += "\n".join(parsed[name].definition_raw for name in (
            "OldEnglishCore", "OldEnglishAfterEpenthesis", "OldEnglishRules",
            "OldEnglishReflexes", "OldEnglish"))
    path.write_text(parser_definitions)
    commands += [f"source {path}"]
    commands += export("EnglishProtoInput", label)
    if label == "mandatory-both":
        commands += ["define FixedParser EnglishProtoInput;"]
        commands += export("[OriginalParser.u - FixedParser.u]", "removed-domain-difference")
        commands += export("[FixedParser.u - OriginalParser.u]", "added-domain-difference")
        commands += export(
            "[FixedParser.u - [?* [pgrmShortVowel.u | pgrmLongVowel.u | "
            "pgrmNasalVowel.u | pgrmDiphthong.u] ?*]]", "fixed-vowelless-difference")
        commands += export("OldEnglish", "fixed-full")
        commands += export("[FixedParser.u - OldEnglish.u]", "fixed-totality-difference")
run(commands, "domain-factorization")
words = ["p", "s", "-", "ô", "ḗô", "é-ìwi", "fléuxaną", "sláxaną",
         "téuxaną", "táixōn", "sáiwiz", "θréjez", "néwun", "biu", "bíu", "biú"]
checks = {}
for name in ("pgrmStrongPlainHeavy", "pgrmSimpleWord", "pgrmWord",
             "EnglishProtoNative", "PGCellRoot", "PGCellInput", "EnglishProtoInput",
             *variants, "fixed-full"):
    checks[name] = lookup(output / (name + ".bin"), words)
rows = json.loads((snapshot / "rows.json").read_text())
selected = [row["fst_input"] for row in rows]
old_parser = lookup(output / "EnglishProtoInput.bin", selected)
new_parser = lookup(output / "mandatory-both.bin", selected)
old_full = lookup(snapshot / "accepted.bin", selected)
new_full = lookup(output / "fixed-full.bin", selected)
(output / "selected391.json").write_text(json.dumps({
    "population": len(rows),
    "parser_changes": [{"row": row, "old": old_parser[row["fst_input"]],
                        "new": new_parser[row["fst_input"]]}
                       for row in rows if old_parser[row["fst_input"]] != new_parser[row["fst_input"]]],
    "complete_changes": [{"row": row, "old": old_full[row["fst_input"]],
                          "new": new_full[row["fst_input"]]}
                         for row in rows if old_full[row["fst_input"]] != new_full[row["fst_input"]]],
}, ensure_ascii=False, indent=2))
(output / "controls.json").write_text(json.dumps(checks, ensure_ascii=False, indent=2))
(output / "variants.json").write_text(json.dumps(variants, indent=2))
(output / "compiler.json").write_text(json.dumps({
    "version": subprocess.check_output(["foma", "-v"], text=True).strip(),
    "sha256": hashlib.sha256(Path("/usr/local/bin/foma").read_bytes()).hexdigest(),
    "fst_sha256": hashlib.sha256(source.encode()).hexdigest(),
}, indent=2))
print("Actual parser factors, both projections, exact inclusion differences and six-group private parser correction exported.")
