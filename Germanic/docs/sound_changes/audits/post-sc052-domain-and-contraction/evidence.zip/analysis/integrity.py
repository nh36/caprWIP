import hashlib
import importlib.util
import json
from pathlib import Path
import re
import subprocess
import tarfile
import zipfile

root = Path("Germanic/docs/sound_changes/audits")
spec = importlib.util.spec_from_file_location("integrity_proof", root / "parser-formal-resolution/functionality.py")
proof = importlib.util.module_from_spec(spec)
spec.loader.exec_module(proof)
out = Path(".capr-work/post-sc052-domain")
results = {}
for folder in ("sc052-scoping-acceptance", "sc086-totality-bounded"):
    path = root / folder
    meta = json.loads((path / "capsule.json").read_text())
    assert hashlib.sha256((path / meta["archive"]).read_bytes()).hexdigest() == meta["sha256"]
    with zipfile.ZipFile(path / meta["archive"]) as z:
        manifest = json.loads(z.read("MANIFEST.json"))
        assert set(z.namelist()) == set(manifest["files"]) | {"MANIFEST.json"}
        for name, value in manifest["files"].items():
            assert hashlib.sha256(z.read(name)).hexdigest() == value["sha256"]
        if folder == "sc052-scoping-acceptance":
            state = json.loads(z.read("acceptance/completed-run/state.json"))
            assert all(value["status"] == "complete" for value in state["stages"].values())
            receipts = json.loads(z.read("acceptance/validation.json"))["receipts"]
            assert all(r["ok"] and r["returncode"] == 0 for r in receipts)
            commit = json.loads(z.read("acceptance/accepted-commit.json"))
            for name, sha in commit["certified_paths_sha256"].items():
                assert hashlib.sha256(Path(name).read_bytes()).hexdigest() == sha
                assert hashlib.sha256(subprocess.check_output(
                    ["git", "show", f"529eeaa5:{name}"])).hexdigest() == sha
            results["visual_inspection"] = json.loads(z.read(
                "acceptance/current-publication/visual-inspection.json"))
            results["prior_publication"] = json.loads(z.read(
                "acceptance/prior-publication/certified-four-cell-receipt.json"))
            results["validation"] = [{k: r[k] for k in (
                "label", "returncode", "source_identity", "junit_counts") if k in r}
                for r in receipts]
    results[folder] = {"archive_sha256": meta["sha256"], "members_verified": meta["members"]}
with tarfile.open(root / "full-cascade-functionality/repair-evidence.tar.gz") as t:
    for label in ("candidate-prefix-061", "scoped-OEVelarPalatalization",
                  "scoped-OEVelarPalatalizationStops"):
        att = t.extractfile(label + ".att").read().decode()
        certificate = json.load(t.extractfile(label + ".proof.json"))
        assert certificate["functional"]
        proof.verify(att, certificate)
        results[label] = {k: v for k, v in certificate.items() if k != "delays"}
fst = Path("Germanic/fsts/germanic.txt").read_bytes()
old = subprocess.check_output(["git", "show", "e8423194:Germanic/fsts/germanic.txt"])
line = b"{*g} -> {*\xca\xa4} || EnglishStarFrontVowel _ [EnglishStarConsonant - {*j}],"
assert fst == old.replace(line, line + b",", 1)
from sys import path
path.insert(0, "Germanic/tools")
from executable_facts import parse_defines
printed = parse_defines(Path(
    "Germanic/docs/sound_changes/reader_facing/052-velar-palatalization.md").read_text())
assert re.sub(r"\s+", "", parse_defines(fst.decode())[
    "OEVelarPalatalizationStops"].body) == re.sub(
    r"\s+", "", printed["OEVelarPalatalizationStops"].body)
results["closed"] = True
results["fst_sha256"] = hashlib.sha256(fst).hexdigest()
(out / "integrity.json").write_text(json.dumps(results, ensure_ascii=False, indent=2))
print("SC052 and reader CLOSED: exact sources, complete certificate, authentic final receipts and both archive manifests verified.")
