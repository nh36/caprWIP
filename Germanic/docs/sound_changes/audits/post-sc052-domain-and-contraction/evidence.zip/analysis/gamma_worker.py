import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

sys.path.insert(0, "/usr/app/tools")
from executable_facts import parse_defines
from probe import native


def lookup(path, words):
    p = subprocess.run(["flookup", "-i", str(path)], input="\n".join(words) + "\n",
                       text=True, capture_output=True, check=True)
    found = {w: set() for w in words}
    for line in p.stdout.splitlines():
        if "\t" in line:
            word, value = line.split("\t", 1)
            if value != "+?":
                found[word].add(value)
    return {word: sorted(values) for word, values in found.items()}


def export(expression, label, att=True):
    return ["clear stack", f"regex {expression};", f"save stack {label}.bin",
            *([f"write att > {label}.att"] if att else [])]


snapshot, output = map(Path, sys.argv[1:3])
output.mkdir()
source = (snapshot / "fst.txt").read_text()
anchor = "define OldEnglishOrthography ["
assert source.count(anchor) == 1
candidate = source.replace(anchor, anchor + "\n    {*ɣ} -> g,", 1)
assert candidate != source
assert parse_defines(candidate)["OldEnglishOrthography"].body != parse_defines(
    source)["OldEnglishOrthography"].body
(output / "candidate.txt").write_text(candidate)
definitions = re.sub(
    r"(?m)^\s*(?:clear stack|save stack [^\n;]+|regex [A-Za-z][A-Za-z0-9_]*\s*;)\s*$",
    "", source)
(output / "definitions.txt").write_text(definitions)
sequence = json.loads((snapshot / "sequence.json").read_text())
index = next(i for i, stage in enumerate(sequence)
             if stage["name"] == "OldEnglishOrthography")
commands = [f"source {output / 'definitions.txt'}",
            "define OriginalOrthography OldEnglishOrthography;",
            "define OriginalFull OldEnglish;",
            parse_defines(candidate)["OldEnglishOrthography"].definition_raw,
            "define GammaMap [{*ɣ} -> g];",
            "define Tier [EnglishStarAlphabet | EnglishPalatalConsonant]*;",
            "define OriginalTier [Tier .o. OriginalOrthography];",
            "define CandidateTier [Tier .o. OldEnglishOrthography];",
            "define Factored [OriginalTier .o. GammaMap];",
            "define CandidateFull [" + " .o. ".join(
                stage["expression"] for stage in sequence) + "];"]
commands += export("EnglishProtoInput", "parser", att=False)
commands += export("OriginalFull", "original-full", att=False)
commands += export("CandidateFull", "gamma-full")
commands += export("[EnglishProtoInput.u - CandidateFull.u]", "gamma-totality-difference")
commands += export("OriginalTier", "orthography-original")
commands += export("CandidateTier", "orthography-candidate")
commands += export("[[CandidateTier - Factored] | [Factored - CandidateTier]].u",
                   "factorization-difference")
commands += export("[Tier .o. GammaMap]", "gamma-map")
commands += export(Original := "OriginalOrthography", "original-lookup", att=False)
commands += export("OldEnglishOrthography", "candidate-lookup", att=False)
receipt = native(commands, output, timeout=1800)
(output / "native.json").write_text(json.dumps(receipt, ensure_ascii=False))
assert receipt["returncode"] == 0
assert not any(s in receipt["stdout"] + receipt["stderr"]
               for s in ("***Unknown", "Syntax error", "***Error", "not defined"))
rows = json.loads((snapshot / "rows.json").read_text())
words = [r["fst_input"] for r in rows]
old, new = lookup(output / "original-full.bin", words), lookup(
    output / "gamma-full.bin", words)
controls = ["ɣó", "gó", "ɣá", "gá", "ɣí", "gí", "ɣé", "gé", "ɣú", "gú",
            "ɣrá", "grá", "ɣjó", "gjó", "áɣan", "ágan", "áɣ", "ág",
            "áɣa", "ága", "ánɣi", "ángi", "áɣɣi", "ággi",
            "á-ɣa", "á-ɣan", "ɣò-oxun", "ò-oxun", "ḗô"]
tier_controls = ["*ɣ*o", "*ɣ*i", "*a*ɣ*a", "*a*ɣ", "*a*ɣ*t",
                 "*a*ɣ*r", "*n*ɣ*a", "*n*g*a", "*ɣ*ɣ*i", "*g*g*i",
                 "*ʝ*i", "*j*i", "*ʒ*i", "*ʤ*i", "*ç*i", "*x*a", "*ɔ̆"]
(output / "regression-and-controls.json").write_text(json.dumps({
    "source_sha256": hashlib.sha256(source.encode()).hexdigest(),
    "candidate_sha256": hashlib.sha256(candidate.encode()).hexdigest(),
    "orthography_physical_stage": index + 1, "population": len(rows),
    "selected_changes": [dict(row=r, old=old[r["fst_input"]], new=new[r["fst_input"]])
                         for r in rows if old[r["fst_input"]] != new[r["fst_input"]]],
    "raw_controls": {"parser": lookup(output / "parser.bin", controls),
                     "old": lookup(output / "original-full.bin", controls),
                     "new": lookup(output / "gamma-full.bin", controls)},
    "tier_controls": {"old": lookup(output / "original-lookup.bin", tier_controls),
                      "new": lookup(output / "candidate-lookup.bin", tier_controls)},
}, ensure_ascii=False, indent=2))
print("Surviving-gamma mapping compiled; deterministic-factor comparison, raw-domain totality and all391/current-tier controls exported.")
