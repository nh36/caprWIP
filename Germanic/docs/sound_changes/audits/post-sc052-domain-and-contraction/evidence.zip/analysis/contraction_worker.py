import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

sys.path.insert(0, "/usr/app/tools")
from executable_facts import parse_defines
from probe import native


def lookup(path, words):
    p = subprocess.run(["flookup", "-i", str(path)], input="\n".join(words) + "\n",
                       text=True, capture_output=True, check=True)
    found = {w: set() for w in words}
    for line in p.stdout.splitlines():
        if "\t" in line:
            word, value = line.split("\t", 1)
            if value != "+?":
                found[word].add(value)
    return {word: sorted(values) for word, values in found.items()}


def export(expression, label, bounded=False):
    return ["clear stack", f"regex {expression};", f"save stack {label}.bin",
            *([] if bounded else [f"write att > {label}.att"])]


def fold(current, path):
    values = lookup(path, sorted({v for outputs in current.values() for v in outputs}))
    return {word: sorted({v for old in outputs for v in values[old]})
            for word, outputs in current.items()}


snapshot, output = map(Path, sys.argv[1:3])
output.mkdir()
source = (snapshot / "fst.txt").read_text()
facts = parse_defines(source)
definitions = re.sub(
    r"(?m)^\s*(?:clear stack|save stack [^\n;]+|regex [A-Za-z][A-Za-z0-9_]*\s*;)\s*$",
    "", source)
(output / "definitions.txt").write_text(definitions)
sequence = json.loads((snapshot / "sequence.json").read_text())
assert sequence[99]["name"] == "OEContraction"
body = facts["OEContraction"].body
assert body.startswith("[") and body.endswith("]")
clauses = body[1:-1].split(",")
assert len(clauses) == 27
guard = " || _ [{*} | .#.]"
variants = {
    "original": body,
    "scoped": body.replace(",", ",,"),
    "guarded": body[:-1] + guard + "]",
    "serial": " .o. ".join("[" + clause + guard + "]" for clause in clauses),
    "directed": (body[:-1] + guard + "]").replace("->", "@->"),
}
commands = [f"source {output / 'definitions.txt'}",
            "define Before [" + " .o. ".join(s["expression"] for s in sequence[:99]) + "];",
            "define After [" + " .o. ".join(s["expression"] for s in sequence[100:]) + "];",
            "define Tier [EnglishStarAlphabet | EnglishPalatalConsonant | {*ᵘ} | {*ᶜ}]*;"]
commands += export("Before", "before")
commands += export("[Before.l - Tier]", "tier-domain-difference")
for index, stage in enumerate(sequence):
    commands += export(stage["expression"], f"step-{index:03}", bounded=True)
for label, expression in variants.items():
    commands += [f"define Candidate [{expression}];"]
    commands += export("Candidate", label + "-lookup", bounded=True)
    commands += export("[Tier .o. Candidate]", label + "-component")
    if label in ("serial", "directed"):
        commands += export("[Before .o. Candidate]", label + "-100")
        commands += export("[Before .o. Candidate .o. After]", label + "-full")
commands += [
    "define HContact [EnglishProtoInput.u & "
    "[pgrmOnsetCore.u [á | é | í | ú | ḗ | ḯ | {ái} | {áu} | {éu} | {íu}] x {aną}]];"
]
commands += export("[HContact .o. OldEnglish]", "hcontact-full")
commands += export("[HContact - OldEnglish.u]", "hcontact-totality-difference")
receipt = native(commands, output, timeout=1800)
(output / "native.json").write_text(json.dumps(receipt, ensure_ascii=False))
assert receipt["returncode"] == 0
assert not any(s in receipt["stdout"] + receipt["stderr"]
               for s in ("***Unknown", "Syntax error", "***Error", "not defined"))
(output / "variants.json").write_text(json.dumps({
    name: {"expression": value, "sha256": hashlib.sha256(value.encode()).hexdigest(),
           "historical_adoption": False}
    for name, value in variants.items()}, ensure_ascii=False, indent=2))

rows = json.loads((snapshot / "rows.json").read_text())
words = [r["fst_input"] for r in rows]
baseline, current = [], {w: [w] for w in words}
for index in range(len(sequence)):
    current = fold(current, output / f"step-{index:03}.bin")
    baseline.append(current)
regression = {}
for label in ("scoped", "guarded", "serial", "directed"):
    current, changes = baseline[98], []
    for index in range(99, len(sequence)):
        current = fold(current, output / (
            label + "-lookup.bin" if index == 99 else f"step-{index:03}.bin"))
        changes += [{"physical_stage": index + 1, "name": sequence[index]["name"],
                     "row": r, "old": baseline[index][r["fst_input"]],
                     "new": current[r["fst_input"]]}
                    for r in rows if baseline[index][r["fst_input"]] != current[r["fst_input"]]]
    regression[label] = {"population": len(rows), "stage_comparisons": len(rows) * 110,
                         "shared_preceding_stages": 99, "changes": changes}
(output / "selected391-stages.json").write_text(json.dumps(regression, ensure_ascii=False, indent=2))
probes = ["é-ìwi", "ò-oxun", "éu-òxun", "ái-èxun", "rái-èxun",
          "fléuxaną", "sláxaną", "téuxaną", "táixōn", "θréjez",
          "sáiwiz", "áiwī", "glíwī", "níwi", "níwi-kènþaz",
          "sáiwi", "áiwi", "glíwi", "féxiwi", "kíjaz", "būaną"]
traces, current = {word: [] for word in probes}, {w: [w] for w in probes}
for index, stage in enumerate(sequence):
    after = fold(current, output / f"step-{index:03}.bin")
    for word in probes:
        traces[word].append({"physical_stage": index + 1, "name": stage["name"],
                             "before": current[word], "after": after[word]})
    current = after
candidate_outputs = {
    label: lookup(output / (label + "-full.bin"), probes)
    for label in ("serial", "directed")}
(output / "source-controls.json").write_text(json.dumps({
    "traces": traces, "actual_complete_outputs": current,
    "candidate_complete_outputs": candidate_outputs,
    "component_triples": {
        label: lookup(output / (label + "-lookup.bin"),
                      ["*i*i*i", "*o*o*o", "*i*i*i*i", "*ā*eo*o",
                       "*θ*r*i*i*e", "*ū*a", "*ū*ā", "*i*e", "*ī*e"])
        for label in variants},
}, ensure_ascii=False, indent=2))
print("Five contraction analyses compiled; actual cumulative/full exports, all391 stage consequences and source-directed110-stage controls preserved.")
