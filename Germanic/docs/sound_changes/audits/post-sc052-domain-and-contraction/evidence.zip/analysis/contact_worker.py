import json
from pathlib import Path
import re
import sys

from probe import native

snapshot, output = map(Path, sys.argv[1:3])
output.mkdir()
source = (snapshot / "fst.txt").read_text()
definitions = re.sub(
    r"(?m)^\s*(?:clear stack|save stack [^\n;]+|regex [A-Za-z][A-Za-z0-9_]*\s*;)\s*$",
    "", source)
(output / "definitions.txt").write_text(definitions)
sequence = json.loads((snapshot / "sequence.json").read_text())
commands = [f"source {output / 'definitions.txt'}",
            "define HContact [EnglishProtoInput.u & "
            "[pgrmOnsetCore.u [á | é | í | ú | ḗ | ḯ | {ái} | {áu} | {éu} | {íu}] x {aną}]];"]
for expression, label in [
    ("OldEnglish", "original-full"),
    ("HContact", "contact-domain"),
    ("[HContact .o. [" + " .o. ".join(s["expression"] for s in sequence[:100]) + "]]",
     "contact-100"),
    ("[HContact .o. [" + " .o. ".join(s["expression"] for s in sequence[:99]) + "]]",
     "contact-99"),
]:
    commands += ["clear stack", f"regex {expression};", f"write att > {label}.att"]
receipt = native(commands, output, timeout=1800)
(output / "native.json").write_text(json.dumps(receipt, ensure_ascii=False))
assert receipt["returncode"] == 0
assert not any(s in receipt["stdout"] + receipt["stderr"]
               for s in ("***Unknown", "Syntax error", "***Error", "not defined"))
print("Independently defined contact-template boundaries99/100 and unmodified actual full relation exported.")
