from collections import defaultdict, deque
import gc
import hashlib
import importlib.util
import json
from pathlib import Path

spec = importlib.util.spec_from_file_location(
    "proof", "Germanic/docs/sound_changes/audits/parser-formal-resolution/functionality.py")
proof = importlib.util.module_from_spec(spec)
spec.loader.exec_module(proof)
base = Path(".capr-work/experiments")


def check(path, requests):
    arcs, finals = proof.read_att(path.read_text())
    adjacent = defaultdict(list)
    for index, (source, target, upper, lower) in enumerate(arcs):
        adjacent[source].append(index)
    results = []
    for word, output in requests:
        start = (0, 0, 0)
        pending, parent, accepted = deque([start]), {start: None}, None
        while pending:
            node = pending.popleft()
            state, i, j = node
            if state in finals and i == len(word) and (output is None or j == len(output)):
                accepted = node
                break
            for index in adjacent[state]:
                _, target, upper, lower = arcs[index]
                a = "" if upper == proof.EPSILON else upper
                b = "" if lower == proof.EPSILON else lower
                if not word.startswith(a, i):
                    continue
                if output is not None and not output.startswith(b, j):
                    continue
                next_node = target, i + len(a), 0 if output is None else j + len(b)
                if next_node not in parent:
                    parent[next_node] = node, index
                    pending.append(next_node)
        item = {"input": word, "requested_output": output, "accepted": accepted is not None}
        assert item["accepted"] == (output is not None), item
        if accepted is None:
            item["exhaustive_reachable_configurations"] = len(parent)
        else:
            path_indices, node = [], accepted
            while parent[node] is not None:
                node, index = parent[node]
                path_indices.append(index)
            path_indices.reverse()
            upper = "".join(arcs[k][2] for k in path_indices if arcs[k][2] != proof.EPSILON)
            lower = "".join(arcs[k][3] for k in path_indices if arcs[k][3] != proof.EPSILON)
            assert upper == word and (output is None or lower == output)
            item.update(arc_path=path_indices, final_state=accepted[0], output=lower)
        results.append(item)
    return {"att_sha256": hashlib.sha256(path.read_bytes()).hexdigest(), "checks": results}


requests = {
    ("post-sc052-domain-03", "EnglishProtoInput"): [
        ("", ""), ("ḗô", "*ḗ*ô"), ("é-ìwi", "*é*ì*w*i")],
    ("post-sc052-domain-03", "mandatory-both"): [("", None), ("ḗô", "*ḗ*ô")],
    ("post-sc052-contact-01", "original-full"): [
        ("", None), ("ḗô", None), ("é-ìwi", "iī"), ("é-ìwi", "īi"),
        ("ò-oxun", "oōn"), ("ò-oxun", "ōon")],
    ("post-sc052-contraction-01", "directed-full"): [
        ("éu-òxun", "ēoon"), ("éu-òxun", "ēoōn")],
    ("post-sc052-gamma-01", "gamma-full"): [
        ("ɣó", "go"), ("ɣò-oxun", "goōn"), ("ɣò-oxun", "gōon"),
        ("ḗô", None), ("", None)],
    ("post-sc052-gamma-01", "orthography-original"): [
        ("*ɔ̆", "a"), ("*ɔ̆", "ŏ")],
    ("post-sc052-unified-01", "unified-full"): [("", None), ("ḗô", None)],
}
result = {}
for (experiment, name), cases in requests.items():
    directory = base / experiment
    phase = "results" if (directory / "results").is_dir() else "staging"
    result[experiment + "/" + name] = check(
        directory / phase / "outputs" / (name + ".att"), cases)
    print(experiment, name, flush=True)
    gc.collect()
Path(".capr-work/post-sc052-domain/complete-paths.json").write_text(
    json.dumps(result, ensure_ascii=False, indent=2))
