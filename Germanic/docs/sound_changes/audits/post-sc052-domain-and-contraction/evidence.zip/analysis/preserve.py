import hashlib
import difflib
import io
import json
from pathlib import Path
import subprocess
import tarfile
import zipfile

root = Path.cwd()
work = root / ".capr-work/post-sc052-domain"
target = root / "Germanic/docs/sound_changes/audits/post-sc052-domain-and-contraction"
target.mkdir(exist_ok=True)
experiments = [
    "post-sc052-domain-01", "post-sc052-domain-02", "post-sc052-domain-03",
    "post-sc052-contraction-01", "post-sc052-gamma-01",
    "post-sc052-unified-01", "post-sc052-contact-01"]


def digest(data):
    return hashlib.sha256(data).hexdigest()


def git(*args):
    return subprocess.check_output(["git", "--no-pager", *args])


assert git("rev-parse", "HEAD").decode().strip() == "efd9ec412a36aa5e9705ccacb63038c114e39fa3"
assert git("branch", "--show-current").decode().strip() == "research/full-cascade-functionality"
assert git("rev-parse", "update").decode().strip() == "8f7713c39f26a7f81ef04d29d54070f1b83ab0e0"
integrity = json.loads((work / "integrity.json").read_text())
certified = integrity["validation"][0]["source_identity"]["worktree_changes"]
assert len(certified) == 39
assert digest((root / "Germanic/data/germanic-aligned-final.tsv").read_bytes()) == (
    "acecb163dffba5c20109ca4951074056a697854fa69cf1f52bc0f82142b39d62")
for name, expected in certified.items():
    assert digest((root / name).read_bytes()) == expected, name
    assert digest(git("show", "529eeaa5864d37d2f67e54ae003247cb21421daa:" + name)) == expected

members, omitted = {}, {}
for name in experiments:
    directory = root / ".capr-work/experiments" / name
    assert (directory / "results").is_dir(), "Promote verified experiment first: " + name
    for path in sorted(directory.rglob("*")):
        if not path.is_file() or path.suffix == ".pyc":
            continue
        member = name + "/" + str(path.relative_to(directory))
        if path.suffix == ".bin":
            omitted[member] = {"sha256": digest(path.read_bytes()), "bytes": path.stat().st_size,
                               "reason": "Native binary retained in original local immutable experiment; text ATT exports are included."}
        else:
            members[member] = path.read_bytes()
for path in sorted(work.glob("*.py")):
    members["analysis/" + path.name] = path.read_bytes()
for name in ("integrity.json", "integrity-receipt.json", "complete-paths.json"):
    members["analysis/" + name] = (work / name).read_bytes()
for name in ("sc086-post-closeout-packet.txt", "post-closeout-preflight.json",
             "replacement-block-inventory.json", "complete-paths.json"):
    path = root / ".capr-work/sc086-totality" / name
    members["prior-research/" + name] = path.read_bytes()
members["prior-research/complete-traces.json"] = (
    root / ".capr-work/experiments/sc086-totality-bounded-03/results/outputs/complete-traces.json").read_bytes()
helper = "Germanic/docs/sound_changes/audits/parser-formal-resolution/functionality.py"
members["analysis/functionality.py"] = (root / helper).read_bytes()
source_pages = {
    "Campbell1959": ("campbell_old_english_grammar.pdf", [21, 98, 100, 180]),
    "RingeTaylor2014": ("ringe_taylor_linguistic_history_vol2.pdf", [4, 259, 318]),
}
source_manifest = {}
for source, (filename, pages) in source_pages.items():
    path = Path("/Users/nathanhill/Code/capr/docs/references") / filename
    source_manifest[source] = {
        "holding": "docs/references/" + filename, "sha256": digest(path.read_bytes()),
        "printed_pages_directly_inspected": pages, "original_included": False,
        "images": {
            str(page): digest((work / "source-images" / (
                ("campbell" if source == "Campbell1959" else "ringe") + f"-p{page}.png")).read_bytes())
            for page in pages},
    }
members["analysis/source-page-verification.json"] = json.dumps(
    source_manifest, indent=2).encode()
members["analysis/omitted-native-binaries.json"] = json.dumps(omitted, indent=2).encode()
for path in sorted(target.glob("*.md")):
    members["reports/" + path.name] = path.read_bytes()
manifest = {
    "classification": "Unadopted research; no new strict production certification",
    "base": "efd9ec412a36aa5e9705ccacb63038c114e39fa3",
    "scientific_commit": "529eeaa5864d37d2f67e54ae003247cb21421daa",
    "fst_sha256": digest((root / "Germanic/fsts/germanic.txt").read_bytes()),
    "production_adoption": False,
    "members": {name: {"sha256": digest(data), "bytes": len(data)}
                for name, data in sorted(members.items())},
}
archive = target / "evidence.zip"
with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as output:
    for name, data in sorted(members.items()):
        info = zipfile.ZipInfo(name, date_time=(2026, 11, 5, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        output.writestr(info, data, compresslevel=9)
with zipfile.ZipFile(archive) as check:
    assert set(check.namelist()) == set(members)
    for name, item in manifest["members"].items():
        assert digest(check.read(name)) == item["sha256"]
manifest["archive"] = {"path": "evidence.zip", "bytes": archive.stat().st_size,
                       "sha256": digest(archive.read_bytes())}
(target / "MANIFEST.json").write_text(json.dumps(manifest, indent=2) + "\n")

export = {
    "commit-metadata.txt": b"\n\n".join(
        git("show", "-s", "--format=fuller", commit)
        for commit in ("e8423194", "529eeaa5", "efd9ec41")),
    "current-germanic.txt": (root / "Germanic/fsts/germanic.txt").read_bytes(),
    "integrity-summary.json": json.dumps({
        key: value for key, value in integrity.items() if key != "validation"},
        ensure_ascii=False, indent=2).encode(),
    "certified-source-and-receipts.json": json.dumps({
        "certified_39": certified,
        "receipts": [{"label": item["label"], "returncode": item["returncode"],
                      "source_identity_sha256": item["source_identity"]["identity_sha256"]}
                     for item in integrity["validation"]],
    }, indent=2).encode(),
    "new-evidence-capsule.json": json.dumps(
        {key: value for key, value in manifest.items() if key != "members"}, indent=2).encode(),
}
changes, patches = [], []
for before, after in (("e8423194", "529eeaa5"), ("529eeaa5", "efd9ec41")):
    for name in git("diff", "--name-only", before, after).decode().splitlines():
        data = git("show", after + ":" + name)
        entry = {"range": before + ".." + after, "path": name,
                 "bytes": len(data), "sha256": digest(data)}
        if Path(name).suffix in (".md", ".py", ".txt", ".json", ".tsv", ".log"):
            patch = git("diff", "--no-ext-diff", before, after, "--", name)
            if len(patch) <= 128000:
                patches.append(patch)
                entry["included"] = "text patch"
            else:
                entry["omitted"] = "Large generated text; exact resulting hash retained"
        else:
            entry["omitted"] = "Binary/generated publication or evidence capsule; hash retained"
        changes.append(entry)
export["local-commits.patch"] = b"\n".join(patches)
export["changed-file-inventory.json"] = json.dumps(changes, indent=2).encode()
for name in experiments[2:]:
    path = root / ".capr-work/experiments" / name / "results/proofs/summary.json"
    export["proof-summaries/" + name + ".json"] = path.read_bytes()
for path in sorted(target.glob("*.md")):
    export[path.name] = path.read_bytes()
for experiment, filename in [
    ("post-sc052-domain-03", "mandatory-both.txt"),
    ("post-sc052-gamma-01", "candidate.txt"),
]:
    data = (root / ".capr-work/experiments" / experiment / "results/outputs" / filename).read_bytes()
    export["candidate-diffs/" + experiment + ".patch"] = "".join(
        difflib.unified_diff(
            export["current-germanic.txt"].decode().splitlines(keepends=True),
            data.decode().splitlines(keepends=True),
            fromfile="accepted/germanic.txt", tofile=experiment + "/germanic.txt")).encode()
export["unified-contraction-expression.txt"] = (
    root / ".capr-work/experiments/post-sc052-unified-01/results/outputs/unified-expression.txt").read_bytes()
export["complete-paths.json"] = (work / "complete-paths.json").read_bytes()
export["source-page-verification.json"] = members["analysis/source-page-verification.json"]
export["READ-ME.txt"] = (
    "Text-only independent review of local commits e8423194 -> 529eeaa5 -> efd9ec41 "
    "and the subsequent unadopted research reports.\n"
    "No copyrighted originals, OCR, PDF, PNG, native binary or bulk ATT/certificate-delay "
    "files are included. Publication/capsule hashes and all changed-file identities are recorded.\n"
    "This compact export supports review, not standalone replay of bulk graph certificates. "
    "Complete text graphs, certificates, workers, receipts and failed runs are preserved "
    "in the separately manifested local evidence.zip.\n"
    "No new production adoption, branch push, merge, or book regeneration occurred.\n").encode()
export["EXPORT-MANIFEST.json"] = json.dumps(
    {name: {"sha256": digest(data), "bytes": len(data)}
     for name, data in sorted(export.items())}, indent=2).encode()
review = target / "review-export.tar.gz"
with tarfile.open(review, "w:gz") as output:
    for name, data in sorted(export.items()):
        data.decode("utf-8")
        info = tarfile.TarInfo(name)
        info.size, info.mtime, info.mode = len(data), 0, 0o644
        output.addfile(info, io.BytesIO(data))
with tarfile.open(review) as check:
    assert set(check.getnames()) == set(export)
    for name, data in export.items():
        assert check.extractfile(name).read() == data
print(json.dumps({"evidence": manifest["archive"], "members": len(members),
                  "review": {"path": str(review.relative_to(root)), "bytes": review.stat().st_size,
                             "sha256": digest(review.read_bytes())}}, indent=2))
