from collections import defaultdict, deque
import gc
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

root, output = map(Path, sys.argv[1:3])
output.mkdir(exist_ok=True)
spec = importlib.util.spec_from_file_location(
    "proof", "Germanic/docs/sound_changes/audits/parser-formal-resolution/functionality.py")
proof = importlib.util.module_from_spec(spec)
spec.loader.exec_module(proof)
summary = {}
for path in sorted(root.glob("*.att")):
    text = path.read_text()
    if "difference" in path.stem:
        arcs, finals = proof.read_att(text)
        adjacent = defaultdict(list)
        for index, (source, target, upper, lower) in enumerate(arcs):
            assert upper == lower
            adjacent[source].append((target, index, upper))
        pending, parent, found = deque([0]), {0: None}, None
        while pending:
            state = pending.popleft()
            if state in finals:
                found = state
                break
            for target, index, symbol in adjacent[state]:
                if target not in parent:
                    parent[target] = (state, index, symbol)
                    pending.append(target)
        result = {"empty": found is None, "arcs": len(arcs),
                  "att_sha256": hashlib.sha256(text.encode()).hexdigest()}
        if found is None:
            result["reachable_states"] = sorted(parent)
        else:
            state, indices, symbols = found, [], []
            while parent[state] is not None:
                state, index, symbol = parent[state]
                indices.append(index)
                if symbol != proof.EPSILON:
                    symbols.append(symbol)
            result.update(witness=list(reversed(symbols)),
                          accepting_arc_path=list(reversed(indices)), accepting_state=found)
        del adjacent, arcs, parent, pending
    else:
        result = proof.analyze(text)
        if result["functional"]:
            proof.verify(text, result)
        else:
            arcs, finals = proof.read_att(text)
            for side, indices in enumerate(result["witness"]["arc_paths"]):
                state, upper, lower = 0, [], []
                for index in indices:
                    source, target, a, b = arcs[index]
                    assert source == state
                    state = target
                    if a != proof.EPSILON:
                        upper.append(a)
                    if b != proof.EPSILON:
                        lower.append(b)
                assert state in finals
                assert upper == result["witness"]["input"]
                assert lower == result["witness"]["outputs"][side]
            assert result["witness"]["outputs"][0] != result["witness"]["outputs"][1]
            del arcs, finals
    (output / (path.stem + ".proof.json")).write_text(json.dumps(result, ensure_ascii=False))
    summary[path.stem] = {k: v for k, v in result.items()
                          if k not in ("delays", "reachable_states")}
    (output / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2))
    print(path.stem, json.dumps(summary[path.stem], ensure_ascii=False), flush=True)
    del text, result
    gc.collect()
