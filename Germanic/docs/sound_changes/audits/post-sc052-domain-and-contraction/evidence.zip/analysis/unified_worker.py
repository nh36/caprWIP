import json
from pathlib import Path
import re
import subprocess
import sys

sys.path.insert(0, "/usr/app/tools")
from executable_facts import parse_defines
from probe import native


def lookup(path, words):
    p = subprocess.run(["flookup", "-i", str(path)], input="\n".join(words) + "\n",
                       text=True, capture_output=True, check=True)
    found = {w: set() for w in words}
    for line in p.stdout.splitlines():
        if "\t" in line:
            word, value = line.split("\t", 1)
            if value != "+?":
                found[word].add(value)
    return {word: sorted(values) for word, values in found.items()}


def fold(current, path):
    values = lookup(path, sorted({v for outputs in current.values() for v in outputs}))
    return {word: sorted({v for old in outputs for v in values[old]})
            for word, outputs in current.items()}


def export(expression, label, att=True):
    return ["clear stack", f"regex {expression};", f"save stack {label}.bin",
            *([f"write att > {label}.att"] if att else [])]


snapshot, output = map(Path, sys.argv[1:3])
output.mkdir()
source = (snapshot / "fst.txt").read_text()
body = parse_defines(source)["OEContraction"].body
clauses = body[1:-1].split(",")
mapping = " | ".join(
    "[[" + left + "] .x. [" + right + "]]"
    for left, right in (clause.split("->") for clause in clauses))
expression = "[[" + mapping + "] @-> || _ [{*} | .#.]]"
definitions = re.sub(
    r"(?m)^\s*(?:clear stack|save stack [^\n;]+|regex [A-Za-z][A-Za-z0-9_]*\s*;)\s*$",
    "", source)
(output / "definitions.txt").write_text(definitions)
(output / "unified-expression.txt").write_text(expression + "\n")
sequence = json.loads((snapshot / "sequence.json").read_text())
commands = [f"source {output / 'definitions.txt'}",
            "define Before [" + " .o. ".join(s["expression"] for s in sequence[:99]) + "];",
            "define After [" + " .o. ".join(s["expression"] for s in sequence[100:]) + "];",
            "define Tier [EnglishStarAlphabet | EnglishPalatalConsonant | {*ᵘ} | {*ᶜ}]*;",
            "define Unified " + expression + ";"]
commands += export("[Tier .o. Unified]", "unified-component")
commands += export("[Before .o. Unified]", "unified-100")
commands += export("[Before .o. Unified .o. After]", "unified-full")
commands += export("Unified", "unified-lookup", att=False)
commands += export("Before", "before-lookup", att=False)
commands += export("OEContraction", "original-lookup", att=False)
for index, stage in enumerate(sequence[100:], 100):
    commands += export(stage["expression"], f"step-{index:03}", att=False)
receipt = native(commands, output, timeout=1800)
(output / "native.json").write_text(json.dumps(receipt, ensure_ascii=False))
assert receipt["returncode"] == 0
assert not any(s in receipt["stdout"] + receipt["stderr"]
               for s in ("***Unknown", "Syntax error", "***Error", "not defined"))
rows = json.loads((snapshot / "rows.json").read_text())
before = lookup(output / "before-lookup.bin", [r["fst_input"] for r in rows])
old = fold(before, output / "original-lookup.bin")
new = fold(before, output / "unified-lookup.bin")
changes = []
for index, stage in enumerate(sequence[99:], 99):
    if index != 99:
        old = fold(old, output / f"step-{index:03}.bin")
        new = fold(new, output / f"step-{index:03}.bin")
    changes += [{"physical_stage": index + 1, "name": stage["name"],
                 "row": r, "old": old[r["fst_input"]], "new": new[r["fst_input"]]}
                for r in rows if old[r["fst_input"]] != new[r["fst_input"]]]
(output / "regression-and-controls.json").write_text(json.dumps({
    "population": len(rows), "stage_comparisons": len(rows) * 110,
    "shared_preceding_stages": 99, "changes": changes,
    "component": lookup(output / "unified-lookup.bin",
                        ["*i*i*i", "*o*o*o", "*i*i*i*i", "*ēo*o*o",
                         "*ā*eo*o", "*θ*r*i*i*e", "*ū*a", "*n*í*i", "*g*l*í*i"]),
    "full": lookup(output / "unified-full.bin",
                   ["é-ìwi", "ò-oxun", "éu-òxun", "ái-èxun", "rái-èxun",
                    "fléuxaną", "sláxaną", "téuxaną", "táixōn", "θréjez",
                    "sáiwi", "áiwi", "níwi", "glíwi", "būaną"]),
}, ensure_ascii=False, indent=2))
print("Unified mapping comparator compiled separately: one longest-leftmost centre language, with391x110 comparisons; no historical directionality verdict or adoption.")
