# Earthly publication: exact draft application

## UNAPPROVED / STOPPED BEFORE PRODUCTION — ARCHIVE ONLY

Do not apply this package. The parent stopped adoption after a failed
epsilon trial and two bounded repairs: MFoot and MLate still fail
the formal test (0). Conserved390/380 sampled stages and complete
weak-neuter/genitive success do not certify formal functionality.
No SOURCE propagation, corpus2336 admission or publication selection
is authorised by the archived draft mapping.

The article's implementation wording records attempt02's FootCtx-wrapped
calculation, not accepted production. Rejected attempt03 instead uses
SentenceCtx for MFoot, `MPrefix [*ᶠ ᵇ MC* MV MC*|0]`, and a
compulsory nonempty initial-star rewrite restricted to raw segment
initials. Lowering itself remains FootCtx-wrapped; inventories are
unchanged. Both proposals are failed and unapproved.
See `ARCHIVAL_STATUS.md`; all scholarly/source-verification work,
including bounded Kroonen evidence, is retained without further research.

This directory is draft-only. All real SOURCE paths, generated outputs,
scientific files, other worktrees and controller state are untouched by
this drafting task. No commit, Foma, Docker, refresh or validation lane
has been run.

## Former parent-controlled application specification (not executable authority)

1. Finalize the scientific verdict and candidate implementation first.
   Recheck that identity2336 is free in corpus and sidecars. The present
   files use PROTO `*érθa-kùnðaz`, PROTOFORM `*érθa-kùnðǭ`,
   COUNTERPART `eorþcunde`, class `attested_variant`. Parent owns
   corpus, explicit same-stage cell metadata and context, not this package.
2. Review the model's “Selected regular span” and “Medial prominence”
   sections against the exact final all-five short-grave calculation
   wrapped in FootCtx, headed-ù trigger exclusion and compulsory
   initial-boundary repair.
   They deliberately say “proposed” and “experimental”; replace only
   those executable-dependent statements after the parent has actual
   final-definition receipts. The retained all-five calculation is a
   proposal, not validated production; snapshot02 was reported compiling.
   The frozen chain needs no ending
   repair; SC038 stays inherited, rainbow early SC017 and world initial
   LH remain unchanged.
3. `*.append.tsv` contain the exact header plus appended rows. Complete
   replacement previews are mirrored under `SOURCE/` with their real
   intended relative paths. `application_manifest.json` supplies exact
   mapping, observed original SHA256 and intended draft SHA256. The
   preview operation preserves original text and appends records; it
   does not normalize or rewrite historical rows.
4. Add the explicitly declared three bibliography keys from
   `bibliography.append.bib` to `docs/refs.bib` together with this article.
   They are new, not falsely identified as existing. Metadata comes
   from the frozen reference list; no original holding is asserted.
   Existing keys HoggGrammar2011/Hogg1996/Goering2023 are used exactly.
   MinkovaZhou2022 is a different paper, not a substitute for2023.
5. Recompute final draft hashes after any parent wording change and
   reconcile any intervening SOURCE edit. Never copy an outdated full
   table preview over another participant's changes. Declare the final
   SOURCE paths/hashes in the existing controlled propagation journal;
   new models/ledger are declared `absent` → hash.
6. Only then apply the controlled SOURCE replacements. Parent alone
   executes canonical finalization/regeneration, all validation lanes,
   baseline adoption and actual book/ledger publication verification.
   Do not edit report/class manifests or publication projections.

`prepare_apparatus.py` writes only this directory's draft previews and
mapping. It is not an application script, controller bypass or permanent
tool. Run it from this worktree only if the original sources have not
changed and a fresh draft preview is wanted.

## Actual authorities and schema

There is no additional editable `consultations.tsv`: `coverage.tsv`
owns actual consultations; `reading_scopes.tsv` and `review_targets.tsv`
own finite passage commitments. The generated `source_coverage.tsv`
is not edited. The exact live headers are reproduced in every append
file and in `application_manifest.json`:

- sources: source_key, role, holding_paths, scope, edition_status,
  conventions_status, notes, consultation_mode, priority, payoff.
- forms: evidence_id, row_ids, source_key, printed_pages, locator,
  diplomatic_form, asserted_stage, form_kind, cell, comparison_form,
  normalization_basis, argument, verification, confidence, quoted_author,
  basis, notes.
- coverage: row_id, source_key, status, evidence_ids, search_basis, assessment.
- analyses: analysis_id, row_id, evidence_id, status, relation_to_row,
  attribution_status, comparison_unit, stage_interpretation, stage_basis,
  stage_evidence_ids, analytical_form, normalization_basis,
  normalization_evidence_ids, features, feature_evidence_ids, notes.
- comparisons: comparison_id, row_ids, analysis_ids, scope, question,
  comparison_unit, type_tags, comparability, status, explanation_status,
  conclusion, premises, rationale_ids, notes, alignment_status,
  alignment_basis, alignment_evidence_ids, alignment_limits.
- rationales: rationale_id, analysis_ids, comparison_ids, basis_type,
  support_mode, evidence_ids, statement, premises, counterarguments,
  reason_target, conditioning_tags.
- editorial_cases: case_id, row_id, scope, category, evidence_ids,
  judgement, missing_premise, example_path, requires_extended_discussion,
  publication_source.

The package appends two context-source identities (Hogg1996, Goering2023),
18 forms/processes, nine source consultation rows, 18 evidence-linked
analyses, one bounded comparison, one analyst-inference descriptive
bridge, seven finite reading scopes/targets and one editorial case.
The mature model and ledger are new SOURCE files. The editorial case
explicitly has `requires_extended_discussion=1` and
`publication_source=model_entries/2336-earthly-eorþcunde.model.md`.
No pilot/full report-manifest promotion is requested.

## Access and validation obstacles to keep explicit

The article/ledger can reuse recorded source readings, including the three
unrecovered original papers, without claiming fresh access. No manuscripts
or newly retrieved critical editions were collated.

The current survey excludes BosworthToller1898 because the previously
associated scan is actually the Supplement. The included Supplement
key is Toller1921. Do not silently reactivate the excluded key or file
Genesis under the wrong edition merely to fill a survey slot.
The Genesis evidence is therefore preserved in the full lexical ledger
and article, but no invalid main-dictionary SOURCE `forms.tsv` row is
included. The formal documentary survey rows are the actually included
Supplement's Oxford and Benedict loci.

The frozen census calls
`docs/references/legacy/anglosaxondictio00tolluoft.txt` an independently
OCR'd original main dictionary. A bounded check here found Supplement
“Add” entries; two locator/form searches did not recover the
Genesis1627/98,8 passage. That search outcome is not proof of absence. This does
not invalidate the independently recorded live main-dictionary
quotations; it does prevent treating that legacy filename as newly
verified main-volume holding identity. Parent should retain the online
quotation's mediation and, if formal main-volume survey ingestion is
required, resolve the edition/holding identity separately rather than
inventing an original or recataloguing the whole library.

Campbell printed261 (§638) and272 (§656), Supplement192 (Oxford/
exclusions) and483 (grædiglice/Benedict) were recovered from existing
running folios, not guessed global offsets. No glyph-image verification
was repeated. Other source pages use the frozen passage receipts.

The authorised follow-up resolved the bounded Kroonen consultation.
Literal earthly/erþa/kunþ/kund searches, narrowly justified OCR variants,
and relevant entries on printed118–119,310–312 yielded the earth noun
and *kunda- 'born' adjective stem, distinguishing the separate known/
know formation. The SOURCE coverage draft now says `evidence_found`,
with three `text_checked` records backed by the actual included
tracked dictionary text. This is not an authored whole earthly
compound, a weak-cell reconstruction, new glyph verification or a
general survey. `KROONEN_CONSULTATION.md` records the bounded reading.

## Which gaps actually block the existing gates

Read-only code inspection, not an executed validation, establishes:

- `pgmc_reconstruction_survey.validate` rejects any form whose
  source is excluded. `verified_ledger` does not waive that condition.
  `sources.tsv.holding_paths` must resolve under `docs/references`;
  a URL is not a holding path. A form's `basis` must be an in-repository
  file (tracked for portable mode), and printed folios are mandatory.
  There is consequently no valid main-dictionary survey row under the
  currently excluded BosworthToller1898 identity merely because its
  online quotation is verified. Do not invent a local original to
  reactivate it. Online-mediated Genesis remains accurately in the
  lexical article and ledger.
- This is not itself a mature-publication blocker. The editorial
  `load_cases` gate requires valid row-linked, page/source-bearing
  evidence IDs for the scoped judgement, not a forms-table record
  for every documentary locus mentioned in prose. The proposed case
  uses admissible formation, morphology and Supplement evidence.
  `publication_gate` then requires the selected model actually
  assembled from the exact approved path and its companion ledger
  present. It does not demand that every prose citation's edition be
  an included survey source or inspect the ledger's online provenance.
  Bibliography keys still need the declared additions. Scientific
  adequacy remains separate from passing these mechanical gates.
- `require_core_complete` checks unchecked Orel/Kroonen pairs and
  unreviewed source conventions; `require_alignment_complete` accepts
  explicit `bounded_limit`, not only `feature_aligned`. With this
  bounded Kroonen evidence and the reviewed core2336 comparison,
  earthly contributes no missing core or alignment row. The earlier
  speculation that the Kroonen gap necessarily blocked core completion
  was too strong: even `verification_gap` is not an unchecked pair
  in that function.
- `require_reading_complete` actually screens through reviewed
  `all_rows` or named-row scopes; it does not demand a new immutable
  394-row accountability receipt merely because the corpus grows.
  The actual Ringe2017, Fulk2018 and RingeTaylor2014 screen rows
  are all currently reviewed `all_rows` scopes.
  Historical393-row receipts remain historically limited and must
  not be relabelled. The seven new finite actual consultation scopes
  do not certify a fresh whole-population reading. The existing
  RingeTaylor2014 `conventions_status=verification_gap` is a genuine
  unchanged blocker for `--require-three-source-complete`,
  `--require-feature-alignment-complete` (which invokes that reading
  gate first), and composite `--require-complete`. It is not a new
  earthly manuscript-access or Kroonen blocker.
- General rendering records incomplete three-source status rather
  than raising merely for that status; ordinary portable integrity
  and mature publication can coexist with the declared RT gap.
  Actual corpus2336 admission, fresh generated survey/provenance,
  correct assembled identity/path, ledger presence and parent-owned
  executable validation remain real preconditions. Present
  draft-only files cannot pass those production gates before adoption.

No validation commands were run here. These findings identify the
existing gate logic, not a certification that all other production
inputs or holdings currently pass.

Hogg1996 and Goering actual bibliography-associated PDF paths exist;
old receipt names `Hogg1996.txt` and `Goering2023.txt` do not exist
under those names in this worktree. New source-table rows use the real
paths; forms use `verified_ledger` and the tracked frozen dossier as
basis. No fresh original hash/title-page verification is claimed.
Strict holdings and citation checks remain the parent's responsibility.

## Twelve-point editorial coverage

1. Selected complete weak neuter accusative and attested_variant meaning.
2. Orel whole compound versus CAPR accent/sign/cell assembly.
3. Three located loci versus reported six DOEC tokens and exclusions.
4. Genesis neuter-object agreement and OCR/manuscript limits.
5. Source-backed poetic weak use without determiner.
6. N-stem class, unaugmented singular stem and bimoric nasal ending.
7. Fulk inherited PIE account versus cited Boutkan alternative.
8. General quantity/domain-sensitive medial-foot protection.
9. World initial LH, rainbow early SC017 and noncircular controls.
10. Complete inherited chain, unchanged SC038 and temporary marking limits.
11. Oxford feminine r-syncope and dative *-aimiz/-em unresolved.
12. Unattested regular genitive fallback, no ending repairs or chronology
    reopening, and editorial/ledger publication certification.

These headings explain the requested scholarly coverage, not a new
scientific checklist, fictitious SC adjudication or parallel SOURCE owner.
