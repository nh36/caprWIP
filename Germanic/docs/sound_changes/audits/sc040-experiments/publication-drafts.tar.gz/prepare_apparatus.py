"""Reproduce unapproved archival drafts; never write or authorise real SOURCE."""

import csv
import hashlib
import io
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
DRAFT = Path(__file__).resolve().parent
SURVEY = Path("Germanic/docs/lexeme_reports/pgmc_reconstructions")
FROZEN = "Germanic/docs/sound_changes/audits/earthly-regular-cell/"
PRIOR = "Germanic/docs/sound_changes/audits/rainbow-earthly-secondary-stress/"
ROW = "2336"


def read(name):
    path = ROOT / SURVEY / (name + ".tsv")
    with path.open(newline="") as stream:
        reader = csv.DictReader(stream, delimiter="\t")
        return tuple(reader.fieldnames), list(reader)


def table(columns, rows):
    output = io.StringIO()
    writer = csv.DictWriter(output, fieldnames=columns, delimiter="\t", lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
    return output.getvalue()


forms = []
analyses = []


def evidence(label, source, pages, locator, argument, *, form="", cell="general process",
             stage="unspecified", features=None, relation="process", attribution="endorsed",
             kind="process", basis=None, confidence="high", verification="verified_ledger"):
    key = "earthly-2336-" + label
    basis = basis or FROZEN + "source-ledger.md"
    forms.append(dict(
        evidence_id=key, row_ids=ROW, source_key=source, printed_pages=pages,
        locator=locator, diplomatic_form=form, asserted_stage=stage, form_kind=kind,
        cell=cell, comparison_form=form,
        normalization_basis="Identity of quoted source notation; no accented whole adjective or selected ending assembled as an author's word.",
        argument=argument, verification=verification, confidence=confidence,
        quoted_author="", basis=basis,
        notes=("New bounded held-text consultation; original-page glyph verification not repeated. " if verification == "text_checked" else
               "Reuse of the tracked frozen consultation receipt, not fresh reading or original-page certification. ") +
              ("Empty form denotes process evidence, not an author-printed word." if not form else
               "Source form and CAPR selected-cell assembly are distinct.")))
    analysis_id = "a-" + key
    analyses.append(dict(
        analysis_id=analysis_id, row_id=ROW, evidence_id=key, status="reviewed",
        relation_to_row=relation, attribution_status=attribution,
        comparison_unit="process" if kind == "process" else "source_citation",
        stage_interpretation=stage, stage_basis="unknown" if stage == "unspecified" else "explicit_statement",
        stage_evidence_ids="" if stage == "unspecified" else key,
        analytical_form=form, normalization_basis="Source notation retained; complete selected weak cell remains CAPR comparative inference.",
        normalization_evidence_ids="", features=json.dumps(features or {"cell": cell}, ensure_ascii=False),
        feature_evidence_ids=key, notes="Source argument, documentary cell, stage and selected input kept distinct; no production execution certified."))
    return analysis_id


evidence("orel-compound", "Orel2003", "85", "s.v. *erþa-kunđaz; whole earthly formation",
         "Whole compound with OE eorþ-cund and Gothic airþa-kunds; not a printed accented weak-neuter cell.",
         form="*erþa-kunđaz", cell="adjectival citation", kind="word", relation="same_etymon_citation",
         features={"cell": "citation, not weak neuter accusative", "segments": "source þ and barred đ; CAPR θ/ð distinguished"},
         basis=PRIOR + "lexical-evidence.md")
evidence("kroonen-earth-component", "Kroonen2013", "118-119", "s.v. *erþō-; exact cross-reference spelling on119",
         "Earth noun supplies lexical first constituent only, not linking *-a- or a whole compound. Source heading OCR erpō- distinguished from exact cross-reference *erþō-; remote external etymology qualified.",
         form="*erþō-", cell="feminine earth-noun stem", kind="stem", relation="compound_component",
         features={"cell": "first lexical constituent, not whole compound", "gender": "feminine"},
         basis="docs/references/kroonen_etymological_dictionary_pgmc.vision.txt", verification="text_checked")
evidence("kroonen-born-component", "Kroonen2013", "310", "s.v. *kunda-; OE -cund",
         "Adjective *kunda- 'born' is the old participle of 'be born', with Gothic -kunds, Norse -kundr and OE -cund. Component evidence only; no earthly compound or weak-neuter ending printed in this entry.",
         form="*kunda-", cell="adjective stem, second compound constituent", kind="stem", relation="compound_component",
         features={"cell": "second lexical constituent, not selected weak cell", "segments": "source stem has d; not silently rewritten as selected ð"},
         basis="docs/references/kroonen_etymological_dictionary_pgmc.vision.txt", verification="text_checked")
evidence("kroonen-known-distinction", "Kroonen2013", "311-312", "s.vv. *kunnan-, *kunþa-; comparison with *kunda- on310",
         "The known adjective and know verb are a separate formation from born *kunda-. Narrow earthly/erþa/kunþ/kund searches followed relevant entries and OCR variants only; no complete earthly compound recovered, not author silence.",
         features={"cell": "excluded know/known formation, not -cund born", "segments": "distinct dental histories and meanings retained"},
         basis="docs/references/kroonen_etymological_dictionary_pgmc.vision.txt", verification="text_checked")
evidence("fulk-weak-class", "Fulk2018", "168", "p.168 n.1; weak adjectives and n-stems",
         "Weak adjectives are n-stems; this class statement licenses comparison with n-stem morphology, not insertion of oblique -an-.",
         features={"stem_class": "n-stem weak adjective", "cell": "class statement, not whole word"},
         basis=FROZEN + "morphology.md")
evidence("fulk-neuter-ending", "Fulk2018", "168-170", "§§7.29-7.31; neuter singular ending and augō paradigm",
         "OE-relevant WGmc/Norse neuter singular *-ōⁿ is bimoric nasal, on the unaugmented stem; singular/plural n distinctions preserved.",
         form="*-ōⁿ", cell="n-stem neuter nominative/accusative singular ending", kind="word",
         relation="comparandum", stage="mixed",
         features={"ending": "*-ōⁿ", "quantity": "bimoric nasal long ō, not circumflex trimoric", "stem_class": "unaugmented n-stem singular"},
         basis=FROZEN + "morphology.md")
evidence("fulk-neuter-origin", "Fulk2018", "170", "§7.31; inherited account and cited alternative",
         "Fulk connects neuter ending with PIE *-ōn < *-on-h₂, citing Jasanoff2002 p.33; reports Boutkan1995b pp.285-286 plural-analogy alternative. Neither cited original newly read.",
         features={"ending": "inherited account preferred; reported analogical origin remains alternative"},
         basis=FROZEN + "morphology.md")
evidence("fulk-strong-cells", "Fulk2018", "209-211", "§9.2; strong adjective paradigm",
         "Genitive *-as(a), neuter alternate *-es(a), feminine *-(a)izōz and dative plural *-aimiz kept separate; nasal superscripts not literal consonants.",
         features={"ending": "strong cell alternatives, not weak neuter ending", "cell": "genitives and dat.pl"},
         basis=FROZEN + "morphology.md")
evidence("fulk-poetic-weak", "Fulk2018", "216-217", "§§9.7-9.8; poetic syntax and weak paradigm",
         "Weak adjectives may appear without ordinary specifiers in poetry; weak neuter nom./acc.sg has -e.",
         features={"ending": "OE weak neuter -e", "cell": "neuter acc.sg by contextual agreement"},
         basis=FROZEN + "morphology.md")
evidence("campbell-poetic-weak", "Campbell1959", "261,272", "§§638,656; poetic weak use and blinde paradigm",
         "Freer poetic weak inflection and OE weak-neuter -e independently support syntax and surface cell; not an independent PGmc compound assembly.",
         features={"ending": "OE weak neuter -e", "cell": "neuter nom./acc.sg"},
         basis=FROZEN + "morphology.md")
evidence("toller-oxford", "Toller1921", "192", "s.v. eorþ-cund; An. Ox.691, online44148",
         "Dictionary quotes ealre eorþcundre gesceafte and Latin totius terrestris (i. terrene) creaturae; exact underlying edition/compiler/manuscript not checked.",
         form="eorþcundre", cell="strong feminine genitive singular", stage="oe",
         kind="attestation", relation="same_etymon_other_cell",
         features={"cell": "strong fem.gen.sg", "ending": "-re"},
         basis=FROZEN + "attestation-census.md")
evidence("toller-benedict", "Toller1921", "483", "s.v. grædiglice, cross-cited under sceamleáslice; R.Ben.139,27/28",
         "One eorþcundum lustum filigaþ occurrence cross-cited under two headwords; masculine dat.pl by agreement, surface -um gender-syncretic. Underlying Schröer edition not retrieved.",
         form="eorþcundum", cell="strong masculine dative plural by agreement with lustum",
         stage="oe", kind="attestation", relation="same_etymon_other_cell",
         features={"cell": "masc.dat.pl by agreement", "ending": "-um syncretic"},
         basis=FROZEN + "attestation-census.md")
evidence("toller-exclusions", "Toller1921", "192", "s.v. eorþ-cund and separate eorþcund-lic; Rtl.33,36; Past.78,18",
         "Eardcundes is a different first constituent; eorþcundlic is separately suffixed. Their dictionary grouping does not reconcile six reported tokens with three loci.",
         features={"cell": "excluded lexemes, not census members"},
         basis=FROZEN + "attestation-census.md")
evidence("hogg-compound-prominence", "HoggGrammar2011", "49-50", "§2.89; historically compound-derived suffixes",
         "-cund is included among historically compound-derived elements; disyllabic/inflected forms can receive later subordinate stress. No complete accented earthly input printed.",
         features={"stress": "historical constituent versus later subordinate prominence"})
evidence("hogg-late-lowering", "HoggGrammar2011", "239-241", "§§6.55-6.58; unstressed lowering and retention",
         "Retention conditions, date/dialect and phonetic [u] distinguished; no universal dental-nasal exemption or Oxford-dialect assignment.",
         features={"vocalism": "unstressed u lowering versus conditioned retention"})
evidence("hogg-tertiary-caution", "Hogg1996", "8-11", "suffix vowels and p.11 n.7",
         "Tertiary-stress label alone is circular; labial nasal differs from dental nasal, ordinary -un > -on excluding a blanket dental block.",
         features={"stress": "independently motivated prominence required", "vocalism": "labial and dental retention distinguished"})
evidence("goering-feet", "Goering2023", "79-84", "§§4.5.1.1-4.5.2; initial and medial foot accommodation",
         "Initial LH is accommodated together; after initial H a nonfinal heavy syllable can head a medial foot. Final feet, final stress and exceptional overheavy evidence kept separate.",
         features={"stress": "initial H versus LH domain; not every medial heavy-looking syllable"})
evidence("rt-syncope", "RingeTaylor2014", "264-266", "§6.7.3; medial syncope and feminine pronominal endings",
         "Ordinary medial syncope and ending comparison do not establish the exact Oxford private insertion or repair dat.pl *-aimiz > experimental -em.",
         features={"ending": "feminine comparison, not settled whole-cell derivation"})

coverage = []
for key in dict.fromkeys(row["source_key"] for row in forms):
    relevant = [row for row in forms if row["source_key"] == key]
    coverage.append(dict(
        row_id=ROW, source_key=key,
        status="discussion_only" if all(row["form_kind"] in {"process", "attestation"} for row in relevant) else "evidence_found",
        evidence_ids=";".join(row["evidence_id"] for row in relevant),
        search_basis="Reuse of frozen earthly and prior rainbow/earthly passage-specific consultation receipts, with printed locators; no new broad reading or page-image certification.",
        assessment="; ".join(row["argument"] for row in relevant)))
for consultation in coverage:
    if consultation["source_key"] == "Kroonen2013":
        consultation["search_basis"] = (
            "2026-11-01 bounded direct consultation of included held dictionary text: literal earthly/erþa/kunþ/kund searches, "
            "relevant earth and born/known formation entries plus narrowly justified OCR p/þ variants; printed118-119,310-312 read. "
            "No broad survey, no original-glyph certification, no complete accented compound assembled as Kroonen's word.")

comparison_id = "core-2336"
rationale_id = "r-earthly-2336-cell-and-prominence"
all_a = ";".join(row["analysis_id"] for row in analyses)
all_e = ";".join(row["evidence_id"] for row in forms)
comparisons = [dict(
    comparison_id=comparison_id, row_ids=ROW, analysis_ids=all_a, scope="core_triage",
    question="What do comparative formation, n-stem morphology, documentary cells and prosodic evidence establish for selected earthly?",
    comparison_unit="selected_cell", type_tags="inflection;ending;quantity;historical_analysis",
    comparability="insufficient_evidence", status="reviewed", explanation_status="mixed",
    conclusion="Preferred weak neuter cell is CAPR assembly from Orel compound plus Fulk n-stem evidence and independently supported OE poetic -e. Full paradigm, exact prehistoric prominence and ending-origin alternative remain qualified.",
    premises="Different source units are not competing whole-cell reconstructions; experimental output is not source attribution or a chronology edge.",
    rationale_ids=rationale_id,
    notes="Scoped scholarly review with bounded Kroonen component consultation, not a general dictionary survey or executable certification.",
    alignment_status="bounded_limit",
    alignment_basis="Page-specific inherited receipts in earthly-regular-cell and rainbow-earthly-secondary-stress; exact source forms, cells and processes distinguished.",
    alignment_evidence_ids=all_e,
    alignment_limits="No complete author-printed accented weak adjective; main Genesis attestation remains ledger-mediated outside included survey holdings; Kroonen supplies separate components, not whole compound or weak ending; analogy-origin, Oxford r-syncope and dative ending remain open.")]
rationales = [dict(
    rationale_id=rationale_id, analysis_ids=all_a, comparison_ids=comparison_id,
    basis_type="morphological_argument", support_mode="analyst_inference", evidence_ids=all_e,
    statement="Select the attested Genesis weak neuter accusative using unaugmented stem plus bimoric nasal *-ōⁿ. General medial protection after initial H differs from world's initial LH; prefer Fulk's inherited ending account without deciding the reported Boutkan alternative.",
    premises="Orel supplies compound, Kroonen separately supplies earth/born components, Fulk supplies class and ending, Campbell/Fulk supply OE syntax and -e; none prints the whole selected accented input. Parent must verify final SC040 implementation and all controls.",
    counterarguments="Reported plural analogy remains possible; six-token concordance incomplete; final uninflected retention limits medial account; Oxford r-syncope and dat.pl -em mismatch not repaired.",
    reason_target="descriptive_bridge", conditioning_tags="counterexample")]

source_columns, old_sources = read("sources")
existing_sources = {row["source_key"]: row for row in old_sources}
sources = []
for key, holding, scope, notes in [
    ("Hogg1996", "docs/references/britton_1996_english_historical_linguistics.pdf",
     "OE prosodic explanation and suffix-vowel retention",
     "Recorded pp.8-11 text consultation reused; bibliography-associated held Britton volume exists. No fresh original check, no invented Hogg1996.txt holding; labial/dental distinction preserved."),
    ("Goering2023", "docs/references/goering_2023_heafudu_problem.pdf",
     "Early OE initial/medial foot structure and qualified final-overheavy evidence",
     "Held publisher chapter with original printed anchors, not sheet folios. Frozen pp.79-84 reading and pp.83-84 image receipt reused, not newly rechecked; no full cyclic grammar claimed."),
]:
    if key in existing_sources:
        raise ValueError("Unexpected existing source; parent must reconcile " + key)
    if not (ROOT / holding).is_file():
        raise ValueError("Do not invent missing holding " + holding)
    sources.append(dict(source_key=key, role="context", holding_paths=holding, scope=scope,
                        edition_status="verified", conventions_status="unreviewed", notes=notes,
                        consultation_mode="case_triggered", priority="4",
                        payoff="Bounded earthly medial-prominence question; no blanket population programme."))

scope_columns, _ = read("reading_scopes")
target_columns, _ = read("review_targets")
scopes, targets = [], []
for consultation in coverage:
    key = consultation["source_key"]
    if key in {"Orel2003", "Kroonen2013"}:
        continue
    linked = [row for row in forms if row["source_key"] == key]
    scope_id = "earthly-2336-" + key.lower()
    scopes.append(dict(
        scope_id=scope_id, source_key=key, scope_kind="passage", population_scope="named_rows",
        row_ids=ROW, printed_pages=",".join(dict.fromkeys(row["printed_pages"] for row in linked)),
        locator="; ".join(row["locator"] for row in linked),
        selection_basis="Actual frozen passage consultations pertinent to the selected weak cell and its general medial-foot comparison.",
        status="reviewed", evidence_ids=consultation["evidence_ids"],
        search_basis=consultation["search_basis"], assessment=consultation["assessment"],
        verification="verified_ledger",
        verification_limits="Reuse of historical receipts, not fresh direct or glyph reading; whole accented selected cell is analyst assembly."))
    targets.append(dict(source_key=key, row_id=ROW,
                        selection_basis="Actual consulted bounded earthly passages; no retrospective whole-population completion claim.",
                        scope_ids=scope_id))

editorial_path = Path("Germanic/docs/lexeme_reports/pgmc_integration/editorial_cases.tsv")
with (ROOT / editorial_path).open(newline="") as stream:
    editorial_columns = tuple(csv.DictReader(stream, delimiter="\t").fieldnames)
editorial = [dict(
    case_id="earthly-weak-neuter-medial-protection", row_id=ROW,
    scope="Selected poetic weak neuter accusative, inherited ending prehistory and quantity-sensitive medial prominence; not full adjective paradigm",
    category="qualified_alternative", evidence_ids=all_e,
    judgement="Select extended mature discussion of comparative n-stem assembly, attested inflected Genesis target, inherited-versus-reported plural-analogy origin, general medial-foot inference and unresolved alternative cells; not an output-success or count-based editorial trigger.",
    missing_premise="Exact prehistoric accent/domain and full six-token concordance remain qualified; cited Boutkan/Jasanoff not independently read, Kroonen has components not whole selected cell, Oxford r-syncope and dative -em history deferred. Parent owns final scientific and runtime certification.",
    example_path="", requires_extended_discussion="1",
    publication_source="model_entries/2336-earthly-eorþcunde.model.md")]

manifest = []


def preview(relative, appended, columns=None):
    original = ROOT / relative
    content = original.read_text()
    if columns:
        fragment = table(columns, appended)
        delta = fragment.split("\n", 1)[1]
        (DRAFT / (relative.stem + ".append.tsv")).write_text(fragment)
    else:
        delta = appended
    destination = DRAFT / "SOURCE" / relative
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(content + ("" if content.endswith("\n") else "\n") + delta)
    manifest.append(dict(
        source_path=str(relative), draft_path=str(destination.relative_to(ROOT)),
        operation="append", before_sha256=hashlib.sha256(original.read_bytes()).hexdigest(),
        intended_sha256=hashlib.sha256(destination.read_bytes()).hexdigest(),
        appended_rows=len(appended) if columns else "3 bibliography entries",
        schema=list(columns) if columns else "BibTeX"))


for name, rows in [("sources", sources), ("forms", forms), ("coverage", coverage),
                   ("analyses", analyses), ("comparisons", comparisons), ("rationales", rationales),
                   ("reading_scopes", scopes), ("review_targets", targets)]:
    columns, _ = read(name)
    preview(SURVEY / (name + ".tsv"), rows, columns)
preview(editorial_path, editorial, editorial_columns)
preview(Path("docs/refs.bib"), (DRAFT / "bibliography.append.bib").read_text())
for name in ["2336-earthly-eorþcunde.model.md", "2336-earthly-eorþcunde.source_ledger.md"]:
    relative = Path("Germanic/docs/lexeme_reports/model_entries") / name
    destination = DRAFT / "SOURCE" / relative
    manifest.append(dict(source_path=str(relative), draft_path=str(destination.relative_to(ROOT)),
                         operation="new", before_sha256="absent",
                         intended_sha256=hashlib.sha256(destination.read_bytes()).hexdigest()))
(DRAFT / "application_manifest.json").write_text(json.dumps(
    {"status": "unapproved_archival_stopped_before_production",
     "application_authorized": False,
     "source_head": "25b48b93", "row_id": ROW, "row_allocated": False,
     "formal_gate": {"MFoot": 0, "MLate": 0,
                     "evidence_source": "parent-reported; no drafting-task execution",
                     "sampled_conservation_does_not_discharge_formal_failure": True},
     "article_proposal_version": "failed_attempt02_FootCtx_calculation",
     "latest_proposal": "rejected_attempt03_SentenceCtx_MFoot_FootCtx_lowering",
     "files": manifest},
    ensure_ascii=False, indent=2) + "\n")
archive_files = {
    str(path.relative_to(DRAFT)): hashlib.sha256(path.read_bytes()).hexdigest()
    for path in sorted(DRAFT.rglob("*"))
    if path.is_file() and path.name != "archival_manifest.json"
}
(DRAFT / "archival_manifest.json").write_text(json.dumps(
    {"status": "unapproved_archival_stopped_before_production",
     "application_authorized": False, "files_sha256": archive_files},
    ensure_ascii=False, indent=2) + "\n")
print("Prepared draft-only SOURCE previews:", len(manifest), "paths")
print("Appended survey records:", len(forms), "forms;", len(coverage), "consultations;",
      len(analyses), "analyses;", len(scopes), "finite reading scopes")
