# Source ledger: earthly / eorþcunde

## Unapproved archival status — adoption stopped

The parent stopped adoption before production after the failed epsilon
trial and two bounded repairs. MFoot and MLate still return 0 in the
formal test. Conservation of all390/380 sampled stages and success of
the complete weak-neuter and genitive witnesses do not discharge that
failure. No selected identity, executable correction, corpus extension,
editorial certification or publication is adopted by this package.

The article's FootCtx-wrapped calculation describes attempt02 only.
Rejected attempt03 no longer wraps MFoot in FootCtx: it uses SentenceCtx
with `MPrefix [*ᶠ ᵇ MC* MV MC*|0]` and a compulsory nonempty
initial-star rewrite restricted to raw segment initials. Lowering itself
still uses FootCtx, with unchanged inventories. This is the parent's
reported failed proposal, not a definition independently executed or
validated in this drafting task. Neither proposal is accepted.
The source-critical morphology, documentary limits and bounded Kroonen
consultation remain scholarly research evidence.

## Identity and authority

Prepared as lexical-publication SOURCE for the parent's authorised SC040
adoption, not a separate sound-change adjudication. Proposed row2336
was absent from the live corpus and survey at preparation. Parent must
recheck identity before admission. Citation `*érθa-kùnðaz`, selected
`*érθa-kùnðǭ`, target `eorþcunde`, documentary class
`attested_variant`; the two reconstructed cells are PGmc under explicit
same-stage cell metadata. No scientific verdict, production execution,
baseline certification or generated-book inclusion is certified by this
draft ledger.

Frozen research `7215497b`, integrated as `25b48b93` onto
`8f7713c39f26a7f81ef04d29d54070f1b83ab0e0`, supplies the
`../../sound_changes/audits/earthly-regular-cell/` dossier. Its
`morphology.md`, `attestation-census.md`, `source-ledger.md`,
`source-searches.json`, `prosody-and-cascade.md`, cell traces and
immutable experiment receipts remain historical evidence.
The prior `rainbow-earthly-secondary-stress/` literature, lexical evidence
and holding receipts are reused, not edited or silently re-certified.
The actual adoption verdict and final executable/corpus receipt belong
to the parent-controlled SC040 record.

## Passage-specific evidence

| Authority / locator | What the retained consultation establishes | Limits and CAPR inference |
| :--- | :--- | :--- |
| Orel2003, p.85 | Whole `*erþa-kunđaz`; OE eorþ-cund and Gothic airþa-kunds | Prior recorded reading reused; no fresh glyph certification here. θ/ð, accents and weak cell are CAPR assembly. No inferred kunnan etymology. |
| Kroonen2013, pp.118–119,310–312 | Earth noun `*erþō-` and adjective stem `*kunda-` 'born' with OE -cund; distinct `*kunþa-` 'known' and kunnan family | New bounded held-text consultation in this publication preparation; not a page-image check. No whole earthly compound or selected weak-neuter ending recovered. OCR p-like dental signs are not silently certified as original glyphs. |
| Fulk2018, p.168 n.1 | Weak adjectives belong to n-stems | Process evidence, not an authored whole earthly adjective. |
| Fulk2018, pp.168–170 §§7.29–7.31 | Bare-stem neuter singular versus augmented cells; OE-relevant `*-ōⁿ` is bimoric nasal, not circumflex trimoric | Frozen page-image checks reused; final p.170 macron independently inspected during research synthesis. Superscript nasalization is not a consonantal n. |
| Fulk2018, p.170 | Inherited PIE `*-ōn < *-on-h₂`; cited Jasanoff2002 p.33 and Boutkan1995b pp.285–286 alternative from neuter plural | Jasanoff/Boutkan are read at one remove only. Fulk's separate masculine trimoric-origin uncertainty is not the OE-neuter quantity problem. Execution cannot choose the prehistory. |
| Fulk2018, pp.209–211 | Strong ending alternatives; masc. genitive `*-as(a)`; neuter also `*-es(a)`; feminine `*-(a)izōz`; dat.pl `*-aimiz` | Retain cell distinctions and optional material. Strong masc. acc. `*-anōⁿ` is not the weak neuter ending. Source nasalization and CAPR literals must not be conflated. |
| Fulk2018, pp.216–217; Campbell1959 §§638,656 | Poetic weak adjectives without a specifier; weak neuter nom./acc.sg -e | Independent OE syntax/ending support. Campbell was not separately checked for the complete PGmc n-stem assembly. |
| BosworthToller1898, online9582 and8279 | Gen1627/Th98,8; eorþ-cunde modifies neuter eád, object of ageaf | Live dictionary readings recorded in the frozen research. Main dictionary and Supplement are distinct holdings. No main-volume original PDF or manuscript image check claimed. |
| Thorpe1832, edition OCR, numbered p.98 | Same sentence and lack of determiner; archive.org caedmonsmetrica01thorgoog | Edition OCR, not page-image or Junius11 collation; exact eth/thorn, hyphenation and punctuation unresolved. Krapp1931 not consulted. |
| Toller1921, eorþ-cund, online44148; An.Ox.691 | ealre eorþcundre gesceafte / Latin totius terrestris (i. terrene) creaturae | Dictionary-mediated feminine genitive. Exact underlying volume/compiler/manuscript not established; no unsupported Antwerp–London attribution. |
| Toller1921, grædiglice and sceamleáslice; R.Ben.139,27/28 | One eorþcundum lustum filigaþ occurrence, cross-cited twice | Strong dat.pl, masculine by agreement; surface -um syncretic. Schröer edition/manuscript not retrieved. No doubled token count. |
| CiszekKiliszewska2015, pp.489–490 | Six eorþcund and761 godcund tokens; wildcard inflections, lexeme-level table | Earlier direct-reading receipt reused; original PDF not recovered now. Three dictionary loci are not the reported six-token concordance. |
| HoggGrammar2011, pp.49–50 §2.89;239–241 §§6.55–6.58 | Historical constituent stress and later inflected/disyllabic subordinate prominence; lowering and retention qualifications | Held2011 sole-authored grammar, not CHEL chapter or joint Hogg/Fulk authorship. p.49 image check is historical reuse. No Oxford dialect inferred. |
| McCullyHogg1990, pp.323–333, especially330–333 | Revised quantity/domain-sensitive initial-foot conditions | Earlier direct-reading receipt reused; historical hashed PDF unavailable, fresh publisher request returned HTML. No new original reading here. |
| Goering2023, pp.79–84 §§4.5.1.1–4.5.2 | Initial LH accommodation; nonfinal medial heavy foot after initial H; distinction between final feet and stress | Frozen pp.83–84 image checks reused. Full cyclic grammar and universal final-cund stress are not established. |
| Hogg1996, pp.8–11, especially11 n.7 | Tertiary-stress explanatory caution; labial-nasal retention versus ordinary dental -un > -on | Recorded text consultation reused; no new original-page check. No suffix, case or dental-nasal exemption. |
| MinkovaZhou2023, pp.86–90 | Metrical prominence does not directly certify speech-stress history | Earlier direct-reading receipt reused, not this pass's fresh reading. Distinct from existing key MinkovaZhou2022. |
| Campbell1959 §§388–393; RingeTaylor2014 pp.264–266 | Pre-liquid syncope and ending-history comparisons | Frozen consultation reused. Additional Oxford r-syncope is research, not this adoption; full dative history unresolved. |

## Recorded holdings, not new holdings

The frozen research's current inspected Hogg volume-1 PDF SHA256 is
`f8e6d35e5ff1c6ca3a4c26f425a8fb38462d7a96a5255d4f16f4f9337b28a773`;
Goering is
`e69164b4617639698ee544e06aed4f940265bcfa6b1dd771d9119158f083b312`.
The earlier McCully PDF identity is
`3028d92fd2a200038f92cdc3bdfe6078709e5ee95700deed73b4a5a17a2094c7`;
that copy was not recovered in the later research. These are reused
receipts, not this drafting pass's hash or image verification.
Historical searchable filenames `Hogg1996.txt` and `Goering2023.txt`
are not available holdings under those names in this worktree.
The actual extant bibliography-associated PDFs are
`docs/references/britton_1996_english_historical_linguistics.pdf`
and `docs/references/goering_2023_heafudu_problem.pdf`.
Source-table additions identify those real paths and retain
`verified_ledger` evidence with the tracked frozen dossier as basis.
The bibliography does not itself certify a freshly inspected original.

The local Bosworth–Toller scan is the Supplement, catalogued as
`Toller1921`; excluded survey key `BosworthToller1898` must not be
reactivated merely to ingest web quotations from the main dictionary.
The proposed main-dictionary evidence is retained in this scholarly
ledger and linked through the tracked census; the directly admissible
survey documentary rows use the included Supplement where appropriate.
The census's “original main dictionary” label for the legacy OCR file
was not corroborated during draft preparation: that file contains
Supplement Add entries and the bounded locator searches did not recover
the Genesis passage. No inference of universal absence follows from
those searches, but that filename cannot certify main-volume identity.
The independently recorded online quotations remain the Genesis
documentary basis. This limit does not claim that the inaccessible
manuscript or Thorpe's page image was read.

## Interpretation and the selected span

The whole weak input is CAPR's inference: combine the comparative
compound stem with Fulk's weak-adjective n-stem class and unaugmented
neuter singular bimoric nasal ending. No inserted `-an-`, consonantal
`-ōn`, trimoric input or later quantity repair is adopted.
Fulk's inherited account is preferred with the reported plural-analogy
alternative still open. `attested_variant` records the poetic
inflected target, not the cause of its history.

Frozen weak-neuter traces establish the experimental sequence:
`*érθa-kùnðǭ > *érθa-kùndǭ > *érθkùndǭ > *érθkundǭ >
*éorθkundǭ > *éorθkundæ > *éorθkunde`.
Current unmodified SC040 then gives `*eorþconde`; the frozen
earlier-prominence experiment instead gives `eorþcunde`.
The parent must verify that the final adopted implementation has this
same lexical span before presenting it as a production observation.

The general proposed condition is a nonfinal medial heavy head after
the initial foot has been accommodated. Initial H in eorþ.cun.de
differs from world's initial LH. Inherited SC038 stays at its accepted
position. The archived attempt02 proposal deliberately retains the original
all-five short-vowel temporary graves, a/e/i/o/u, and wraps the
calculation and lowering in FootCtx. Computed-headed `*ù` is also
excluded as a following-u licensing trigger, preventing a headed u
from licensing lowering of a subsequent u. An initial-boundary repair
makes the syllable boundary compulsory before initial-foot
accommodation. Snapshot02 was reported as compiling when this wording
was prepared; no outcome, forward-functionality result or production
validation is claimed here.
Temporary marks are computed protection inside SC040 and immediately
decoded, not inherited accent or a second dated loss. Existing FootCtx
protects a pretonic first syllable; it does not independently syllabify
or assign all OE feet. Parent owns the exact proposed definition and
negative controls.
No chronology edge is promoted from private insertion success.

Rainbow's lowered second root belongs to accepted early SC017.
Final uninflected godcund and Goering's qualified final-overheavy
-ing/-end discussion limit extrapolation of medial protection.
The prior in godcundum mægne example is dative singular, not evidence
for a plural merely because -um is syncretic.

The unattested genitive `*eorþcundes` remains a possible regular
fallback. Oxford `*eorþcundere > eorþcundre` requires separate
r-syncope research; dative `*-aimiz > *-em` remains unresolved against
attested -um. No ending repair, scope extension to final-overheavy
syllables, extra analogy or accepted-history reopening follows from
choosing Genesis.

## Bibliography and publication contract

Existing precise keys used are Orel2003, Kroonen2013, Fulk2018, Campbell1959,
HoggGrammar2011, Hogg1996, Goering2023, RingeTaylor2014,
BosworthToller1898 and Toller1921.
The proposed bibliography additions CiszekKiliszewska2015,
McCullyHogg1990 and MinkovaZhou2023 are explicitly declared in the
draft application package, with metadata from the frozen reference list.
They are not pre-existing keys or invented holding claims.
Boutkan1995b and Jasanoff2002 remain explicitly second-hand through
Fulk and are not silently added as directly consulted authorities.
Thorpe1832 is identified narratively by author, edition date and page,
not silently assigned an existing key.

The editorial case selects substantive qualified discussion with
`requires_extended_discussion=1` and
`publication_source=model_entries/2336-earthly-eorþcunde.model.md`.
No pilot/full report-manifest promotion or generated manifest edit
is implied. Actual article insertion, ledger provenance, final class
volume and combined-book certification require the parent's
controlled propagation, canonical regeneration and publication checks.
