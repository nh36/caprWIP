# UNAPPROVED / STOPPED BEFORE PRODUCTION

Final draft-only archival state, 2026-11-01.

The parent stopped adoption under the protocol after the failed epsilon
trial and two bounded repairs. MFoot and MLate still fail the formal
test (0). All390/380 sampled stages were conserved and the complete
weak-neuter/genitive witnesses succeeded; those sampled observations
do not establish formal functionality and do not authorise adoption.
No further repair, research, propagation or publication is initiated.

## Distinct failed proposals

- Attempt02: calculation wrapped in FootCtx; all-five temporary short
  graves; headed-ù excluded as a subsequent-u licensing trigger;
  compulsory initial-boundary repair. The article's detailed proposal
  paragraphs preserve this draft, not the later implementation.
- Rejected attempt03: MFoot uses SentenceCtx, not FootCtx, with
  `MPrefix [*ᶠ ᵇ MC* MV MC*|0]` and a compulsory nonempty
  initial-star rewrite restricted to raw segment initials. Lowering
  itself still uses FootCtx. Inventories are unchanged.
- Both are unapproved failed proposals. This summary records the
  parent's supplied findings; this drafting task ran no formal tests
  or runtime and independently certifies no implementation outcome.

## Preserved scholarly work

The mature-article proposal, source ledger, bounded Kroonen consultation,
three-locus attestation limits, inherited n-stem argument and reported
origin alternative remain research drafts. The exact table append rows
and full SOURCE-path previews are retained for archival inspection,
not current production application. Proposed identity2336 is not
allocated or reserved by this package.

`application_manifest.json` now explicitly records stopped archival
status and application_authorized=false. Its SOURCE mappings and
SHA256 values describe the archived draft bytes only.
`archival_manifest.json` additionally records all package-file hashes.
Neither is a scientific decision, propagation declaration, executed
validation receipt or generated-publication certificate.

The main-dictionary survey-ingestion restriction and the existing RT
conventions gate remain as documented; passing mechanical publication
requirements could not waive the failed scientific/formal gate.

All writes in this task stayed under this draft directory. Actual SOURCE,
parent-owned memos/tests/experiments, generated artifacts and other
worktrees were not edited. No commit, Foma/Docker, refresh, formal test
or further research was performed.
