# Bounded earthly-specific Kroonen consultation

Date: 2026-11-01. Worktree: earthly-sc040. Draft preparation only.
Included SOURCE identity: Kroonen2013. Directly consulted holding:
`docs/references/kroonen_etymological_dictionary_pgmc.vision.txt`.
The corresponding dictionary PDF exists but was not newly image-checked.

The literal case-insensitive whole-text searches were earthly, erþa,
kunþ and kund. They produced 0, 1, 5 and30 literal substring hits,
respectively; counts include irrelevant substrings/index/bibliography
hits and are not evidence counts. The erþa hit was not an earthly
compound. Relevant born/known entries and their local formation
context were read in full, printed310–312. The earth component was
followed through narrowly justified p/þ OCR variants to printed118–119.
No wider reconstruction survey or unrelated etymology was opened.

Results:

- Printed310 (text sheet marker350) gives *kunda- 'born', Gothic
  -kunds, Norse -kundr, OE -cund; identifies the old participle of
  'be born'. This supports the second constituent, not a whole
  earthly compound or a weak-neuter ending.
- Printed118–119 (sheet markers158–159) gives the feminine earth
  noun. Heading OCR has *erpō-; the local cross-reference on119
  explicitly has *erþō-. Preserve that textual distinction rather
  than claiming a fresh original thorn-image check. External
  etymology is qualified. The lexical earth noun does not establish
  the compound's linking *-a-.
- Printed311–312 gives kunnan 'know' and the distinct known
  adjective. The latter's heading is OCR-corrupted but the text
  and cross-reference identify *kunþa-. No diplomatic glyph claim
  is made from that heading; the draft records the formation
  distinction as process evidence.
- No complete earthly reconstruction was recovered by these
  bounded searches and entry readings. That is a bounded negative
  result, not proof of dictionary-wide author silence. The positive
  component evidence is recorded as evidence_found, not no_form_found.

Exact additions are in forms.append.tsv / analyses.append.tsv /
coverage.append.tsv with IDs earthly-2336-kroonen-earth-component,
earthly-2336-kroonen-born-component and
earthly-2336-kroonen-known-distinction. They are text_checked with
the actual tracked holding as basis, not verified_ledger reuse.
No changes to the original dictionary holding, source record or
historical alignment receipts were made.
