import hashlib
import json
from pathlib import Path
import subprocess
import sys

root = Path(sys.argv[1])
build = json.loads((root / "build.json").read_text())
controls = json.loads((root / "controls.json").read_text())
sys.path.insert(0, "/usr/app/tools")
from sound_change_order_sensitivity import batch_apply_down

report = {"source_sha256": hashlib.sha256((root / "source.txt").read_bytes()).hexdigest(),
          "components": {}, "controls": controls["inputs"]}
for key, binary in build["bins"].items():
    name = key.removeprefix("component:")
    result = subprocess.run(
        ["foma", "-q", "-e", "load stack " + binary, "-e", "test functional", "-e", "quit"],
        text=True, capture_output=True, check=True)
    assert result.stdout.strip() == "1 (1 = TRUE, 0 = FALSE)", (name, result.stdout)
    data = {"binary_sha256": hashlib.sha256(Path(binary).read_bytes()).hexdigest(),
            "functional_stdout": result.stdout, "functional_stderr": result.stderr}
    if name in ("MPFoot", "OEMedUnstressedULowering"):
        outputs = dict(zip(controls["inputs"], batch_apply_down(
            Path(binary), list(controls["inputs"].values()))))
        previous = "QFoot" if name == "MPFoot" else "QLate"
        assert outputs == controls["expected"][previous], (name, outputs)
        data["outputs"] = outputs
    report["components"][name] = data
(root / "production-closure.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({"source_sha256": report["source_sha256"], "formal": "all passing",
                  "equivalent_controls": len(controls["inputs"])}))
