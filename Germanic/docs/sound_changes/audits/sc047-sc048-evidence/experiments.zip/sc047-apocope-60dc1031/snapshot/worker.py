#!/usr/bin/env python3
"""Opt-in SC047/048 finite-domain assay; never writes production bins."""
import hashlib
import itertools
import json
import os
from pathlib import Path
import re
import shlex
import subprocess
import sys
import tempfile
import time
from unittest.mock import patch
import uuid

ROOT = Path("/usr/app") if Path("/usr/app/tools").is_dir() else Path.cwd()
sys.path.insert(0, str(ROOT / ("tools" if ROOT == Path("/usr/app") else "Germanic/tools")))
HELPERS = ["anglo_frisian_experiments.py", "oe_pipeline.py", "capr_runtime.py",
           "sound_change_order_sensitivity.py", "executable_facts.py"]
A, N, R = "OEHeavySyllableNasalApocope", "OESecondaryNasalization", "OEARestoration"
FRONT = "OEUnstressedFrontingEarly"
SCHEMAS = {
    "bindende": "bíndandī",
    "guma_nom": "gúmô", "guma_acc_RTaylor": "gúmanų",
    "guma_acc_Fulk": "gúmunų", "guma_gen": "gúminiz",
    "guma_dat": "gúmini", "guma_nompl": "gúmaniz",
    "guma_genpl": "gúmanǭ", "guma_datpl": "gúmammiz",
    "searu": "sárwą", "rice": "rḯkiją",
    "flask_long_stage_input": "fláskōn",
    "secondary_bake_probe": "régna-bàkaną",
}
LOCAL = [
    "*b*a*n", "*b*à*n", "*b*á*n", "*b*ā*n",
    "*b*a*n*d", "*b*a*n*d*ī", "*b*a*n*a",
    "*b*a*m", "*b*a*m*p", "*b*a*m*a",
    "*b*á*k*ą", "*b*á*s*t*ą", "*b*á*k*ā", "*b*á*k*á",
    "*s*á*r*w*ą", "*r*ḯ*k*i*j*ą", "*b*á*k*ą*n",
    "*b*í*n*d*a*n", "*b*í*n*d*a*n*d*ī",
    "*b*í*n*d*a*n*a", "*b*í*n*d*ā*n", "*b*í*n*d*á*n",
    "*b*í*n*d*à*n", "*b*í*n*d*a*m", "*b*í*n*d*a*m*p",
    "*b*í*n*d*a*m*a", "*f*l*á*s*k*ō*n",
    "*s*t*é*l*a*n", "*w*é*b*a*n", "*s*t*é*l*u*n",
]


def definitions(text):
    from executable_facts import parse_defines
    facts = parse_defines(text)
    wide = ("define SFN Ctx([{*a} -> {*ą} || _ EnglishStarNasal "
            "[OEAnyConsonant | .#.]]).o.Ctx([{*à} -> {*ą} || _ EnglishStarNasal "
            "[OEAnyConsonant | .#.]]);")
    consumer = ("define SFI Ctx([{*ą} -> {*æ} || _ EnglishIUmlautThroughU "
                "EnglishIUmlautTrigger]).o.OEIUmlaut;")
    onset = ("define SFO EAFBrighteningUnstressed.o.Ctx([{*a} -> {*æ} || _ "
             "EnglishStarNasal EnglishStarVocalic]);")
    direct = facts["OEUnstressedAFronting"].body
    old = "_ [EnglishStarConsonant | EnglishPalatalConsonant]"
    assert direct.count(old) == 1
    direct = direct.replace(
        old, "_ [[OEAnyConsonant - EnglishStarNasal] | "
        "[EnglishStarNasal EnglishStarVocalic]]")
    restore = facts[R].body
    excluded = "- OEARestorationIntervening OEARestorationWeakTailVowel"
    assert restore.count(excluded) == 2
    back = facts["OEBackMutation"].body
    assert back.count("{*u}") == 3
    return {
        "SFN": wide, "SFI": consumer, "SFO": onset,
        "SFD": "define SFD FootCtx(" + direct + ");",
        "SFR": "define SFR " + restore.replace(excluded, "") + ";",
        "SFB": "define SFB " + back.replace("{*u}", "[{*u}|{*a}]") + ";",
    }


def move(order, name, after):
    order.remove(name)
    order.insert(order.index(after) + 1, name)


def configurations(names):
    configs = {"identity": list(names)}
    for parts in itertools.permutations([R, A, N]):
        label = "-".join({R: "46", A: "47", N: "48"}[p] for p in parts)
        order = [n for n in names if n not in (R, A, N)]
        at = names.index(R)
        order[at:at] = parts
        configs[label] = order
    early = list(names)
    move(early, A, "PWGmcFinalBareALoss")
    configs["early_loss"] = early
    final = list(early)
    move(final, N, A)
    configs["early_final_n"] = final
    wide = ["SFN" if n == N else n for n in final]
    configs["early_coda"] = wide
    umlaut = ["SFI" if n == "OEIUmlaut" else n for n in wide]
    configs["early_coda_i"] = umlaut
    onset = ["SFO" if n == "EAFBrighteningUnstressed" else n for n in umlaut]
    configs["early_coda_i_onset"] = onset
    configs["early_coda_i_onset_restore"] = ["SFR" if n == R else n for n in onset]
    direct = [n for n in early if n != N]
    configs["early_direct_coda"] = ["SFD" if n == FRONT else n for n in direct]
    pre = list(names)
    move(pre, A, "PWGmcIjContraction")
    configs["before_gemination"] = pre
    joint = list(pre)
    move(joint, "EAFFinalZDeletion", "PWGmcIjContraction")
    move(joint, "PWGmcFinalBareALoss", "EAFFinalZDeletion")
    move(joint, A, "PWGmcFinalBareALoss")
    configs["before_gemination_oral_nasal"] = joint
    before_n = list(names)
    move(before_n, A, "PNWGmcLongELowering")
    configs["before_SC023_negative"] = before_n
    late = list(names)
    move(late, N, "OEBackMutation")
    configs["nasal_after_back_WS"] = late
    configs["nasal_after_back_a_trigger"] = ["SFB" if n == "OEBackMutation" else n for n in late]
    configs["nasal_before_back_a_trigger"] = ["SFB" if n == "OEBackMutation" else n for n in names]
    return configs


def worker(snapshot):
    import anglo_frisian_experiments as compiler
    from capr_runtime import check_build_manifest, layout
    import oe_pipeline
    from sound_change_order_sensitivity import batch_apply_down
    from executable_facts import parse_defines
    started = time.perf_counter()
    runtime = layout()
    plan = json.loads((snapshot / "plan.json").read_text())
    source = snapshot / "source.txt"
    assert source.read_bytes() == runtime.germanic_fst.read_bytes()
    assert (snapshot / "corpus.tsv").read_bytes() == runtime.corpus_tsv.read_bytes()
    for name, digest in plan["helpers"].items():
        assert hashlib.sha256((runtime.tools_dir / name).read_bytes()).hexdigest() == digest
    assert not check_build_manifest(oe_pipeline.expected_snapshot_bins() + ["old_english.bin"])
    rows = oe_pipeline.load_rows(runtime.corpus_tsv)
    raw = [r["fst_input"] for r in rows]
    names = [s.foma_identifier for s in oe_pipeline.stages()]
    configs = configurations(names)
    before = "PNWGmcLongELowering"
    at = names.index(before) + 1
    checkpoints = ["PNWGmcNStemNLoss", "PWGmcJGemination", "PNWGmcULowering",
                   "PWGmcFinalBareALoss", "EAFBrighteningUnstressed",
                   "EAFBrightening", "OEBreaking", R, A, N, "OEIUmlaut",
                   "OEBackMutation", "OENonHighSyn", FRONT, "OEWeakTailReduction"]
    live = {n: batch_apply_down(runtime.bin_dir / oe_pipeline.stage_for(n).snapshot_bin, raw)
            for n in [before, *checkpoints]}
    finals = batch_apply_down(runtime.bin_dir / "old_english.bin", raw)
    incoming = [v[0] for v in live[before]]
    assert all(len(v) == 1 for v in live[before])
    picked = [i for i, r in enumerate(rows) if r["concept"] in {
        "bake", "bind", "thatch", "horn", "do", "flask", "steal", "weave",
        "wade", "day", "craft", "rainbow", "earthly", "straw", "bast", "net", "hue"}]
    definitions_list = list(plan["variants"].values())
    queries = {}
    for label, order in configs.items():
        assert order[:at] == names[:at]
        queries[label + ":corpus"] = (order[at:], incoming)
        # Full raw-input controls are deliberately separate from stage forms.
        queries[label + ":heldout"] = (order, list(SCHEMAS.values()))
        if label in {"identity", "48-47-46", "47-46-48", "47-48-46",
                     "early_coda_i_onset_restore", "before_gemination_oral_nasal",
                     "early_direct_coda", "early_final_n", "early_loss"}:
            for stop in [R, A, N, "OEIUmlaut", "OEBackMutation", FRONT, "OENonHighSyn"]:
                alias = {"early_coda_i_onset_restore": {R: "SFR", N: "SFN", "OEIUmlaut": "SFI"},
                         "early_direct_coda": {FRONT: "SFD"}}.get(label, {}).get(stop, stop)
                if alias not in order:
                    continue
                queries[label + ":" + stop] = (order[at:order.index(alias) + 1],
                                                [incoming[i] for i in picked])
    for label, members in {
        "apocope": [A], "final_n": [N], "coda_n": ["SFN"],
        "front": [FRONT], "direct_front": ["SFD"],
        "coda_i": ["SFN", "SFI"], "back_WS": ["OEBackMutation"],
        "back_a_trigger": ["SFB"], "restoration": [R], "restoration_nasal": ["SFR"],
    }.items():
        queries["local:" + label] = (members, LOCAL)
    # Source-proposed intermediate bindandī: expose each mechanism without
    # treating the reconstruction as a newly admitted selected corpus item.
    intermediate = ["*b*í*n*d*a*n*d*ī", "*g*ú*m*a*n*ô", "*g*ú*m*i*n",
                    "*s*á*r*w*ą", "*r*ḯ*k*i*j*ą"]
    for label, members in {
        "final": [N, "OEIUmlaut", FRONT, "OEWeakTailReduction"],
        "wide": ["SFN", "OEIUmlaut", FRONT, "OEWeakTailReduction"],
        "wide_i": ["SFN", "SFI", FRONT, "OEWeakTailReduction"],
        "direct": ["OEIUmlaut", "SFD", "OEWeakTailReduction"],
    }.items():
        queries["staged:" + label] = (members, intermediate)
    labels = {}
    for i, (label, (members, inputs)) in enumerate(queries.items()):
        name = "SFQ" + str(i)
        definitions_list.append("define " + name + " [" + compiler.foma_domain(inputs)
                                + ".o." + ".o.".join(members) + "];")
        labels[label] = name
    recipe = {"definitions": "\n".join(definitions_list), "replace": {},
              "insert_rule": None, "insert_after": None,
              "component_checks": [{"component": n} for n in labels.values()]}
    costs = []

    def measured(script, directory):
        begun = time.perf_counter()
        with tempfile.TemporaryFile() as out, tempfile.TemporaryFile() as err:
            p = subprocess.Popen(["foma", "-q", "-f", script.name], cwd=directory,
                                 stdout=out, stderr=err)
            _, status, usage = os.wait4(p.pid, 0)
            p.returncode = os.waitstatus_to_exitcode(status)
            out.seek(0); err.seek(0)
            log = out.read().decode() + err.read().decode()
            costs.append({"script": script.name, "seconds": time.perf_counter() - begun,
                          "peak_rss_kib": usage.ru_maxrss, "returncode": p.returncode})
            if p.returncode or re.search(r"(?im)\b(error|syntax error|not defined)\b", log):
                raise RuntimeError(log[-8000:])

    with tempfile.TemporaryDirectory(prefix="capr_sc047_") as temporary:
        directory = Path(temporary)
        with patch.object(compiler, "_compile_foma", measured):
            image = compiler.prepare_definition_image(source, directory)
            assert image is not None
            with patch.dict(os.environ, {"CAPR_FOMA_DEFINITION_IMAGE": str(image)}):
                bins = compiler.compile_isolated(source, recipe, [], directory, components_only=True)
            assert (directory / "experiment.foma").read_text().startswith("load defined ")
        outputs = {label: batch_apply_down(bins["component:" + name], queries[label][1])
                   for label, name in labels.items()}
    corpus = {}
    for label in configs:
        observed = outputs[label + ":corpus"]
        corpus[label] = {
            "matches": sum(r["counterpart"] in v for r, v in zip(rows, observed)),
            "changed": sum(v != b for v, b in zip(observed, finals)),
            "rejected": sum(not v for v in observed),
            "ambiguous": sum(len(v) > 1 for v in observed),
            "rows": [{**r, "baseline": finals[i], "outputs": observed[i]}
                     for i, r in enumerate(rows)]}
    assert corpus["identity"]["changed"] == 0
    assert corpus["identity"]["matches"] == 386
    assert corpus["identity"]["rejected"] == corpus["identity"]["ambiguous"] == 0
    assert len(rows) == 394
    return {
        "source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
        "corpus_sha256": hashlib.sha256((snapshot / "corpus.tsv").read_bytes()).hexdigest(),
        "rows": [{**r, "final": finals[i],
                  "live": {stage: values[i] for stage, values in live.items()}}
                 for i, r in enumerate(rows)],
        "witness_row_ids": [rows[i]["row_id"] for i in picked],
        "configurations": configs, "corpus": corpus,
        "heldout_labels": list(SCHEMAS),
        "queries": {label: {"members": members, "inputs": inputs, "outputs": outputs[label]}
                    for label, (members, inputs) in queries.items()},
        "definitions": plan["variants"],
        "cost": {"networks": len(queries), "compiler": costs,
                 "variants": len(configs), "seconds": time.perf_counter() - started},
    }


def capture():
    import adjudication_run
    from adjudication_control import run_logged
    from capr_runtime import container_command
    from experiment_snapshot import create_snapshot
    work = ROOT / ".capr-work/sc047"
    source = ROOT / "Germanic/fsts/germanic.txt"
    plan = {"variants": definitions(source.read_text()),
            "helpers": {n: hashlib.sha256((ROOT / "Germanic/tools" / n).read_bytes()).hexdigest()
                        for n in HELPERS},
            "predictions": (work / "source-assessment.md").read_text()}
    plan_path = work / "plan.json"
    plan_path.write_text(json.dumps(plan, ensure_ascii=False, indent=2))
    snapshot = create_snapshot(
        "sc047-apocope-" + uuid.uuid4().hex[:8],
        "Distinguish historical apocope, late proxy, coda conditioning and chronology",
        {"source": source, "corpus": ROOT / "Germanic/data/germanic-aligned-final.tsv",
         "contexts": ROOT / "Germanic/data/entry_context_metadata.tsv",
         "worker": Path(__file__), "plan": plan_path,
         "assessment": work / "source-assessment.md",
         **{Path(n).stem: ROOT / "Germanic/tools" / n for n in HELPERS}},
        variants=plan["variants"], probes=LOCAL + list(SCHEMAS.values()),
        expected_outcomes={"assessment": plan["predictions"]},
        negative_controls=["long vowel", "onset nasal", "primary acute", "do SC023",
                           "protected flaskōn", "settled rainbow/earthly"])
    run = adjudication_run.load("SC047")
    run.complete_stage("SNAPSHOT", evidence={"snapshot_root": str(snapshot.root)})
    container = snapshot.stage_in_container()
    receipt = run_logged(
        container_command("cd /usr/app && python3 " + shlex.quote(container + "/worker.py")
                          + " --worker " + shlex.quote(container)),
        label="sc047-finite-matrix", log_dir=snapshot.root / "execution")
    if receipt["ok"]:
        (snapshot.staging_dir / "observed.json").write_bytes(Path(receipt["stdout_log"]).read_bytes())
    snapshot.complete("passed" if receipt["ok"] else "failed",
                      "Assay executed; acceptance requires source-based interpretation", [receipt])
    (work / "latest.json").write_text(json.dumps(
        {"snapshot_root": str(snapshot.root), "receipt": receipt}, indent=2))
    print(snapshot.root)
    if not receipt["ok"]:
        raise RuntimeError(Path(receipt["stderr_log"]).read_text())


if __name__ == "__main__":
    if sys.argv[1:] == ["--capture"]:
        capture()
    elif sys.argv[1:2] == ["--worker"]:
        print(json.dumps(worker(Path(sys.argv[2])), ensure_ascii=False))
    else:
        raise SystemExit("use --capture or --worker SNAPSHOT")
