#!/usr/bin/env python3
"""Replay the preserved four-cell assay with the authorized canonical parser."""
import argparse
import gzip
import json
from pathlib import Path
import re
import shutil

import experiment


PARSER = """define PGCellRaw [PGCellPlain | PGCellPrefixed];
# Ambiguous bare spellings require explicit primary stress, not parse priority.
define PGCellInput _unambpart(PGCellRaw);"""
INPUT = """define EnglishProtoInput [
    _unambpart(EnglishProtoNative) |
    _unambpart([[PGCellRaw.u - EnglishProtoNative.u] .o. PGCellRaw])
];"""


def canonical_source(source):
    for name, replacement in (("PGCellInput", PARSER), ("EnglishProtoInput", INPUT)):
        source, count = re.subn(r"(?ms)^define " + name + r"\b.*?;", replacement, source)
        if count != 1:
            raise ValueError("Expected exactly one candidate definition: " + name)
    return source


def worker(output):
    import adoption_assay

    output.mkdir()
    fst = adoption_assay.G / "fsts/germanic.txt"
    fst.write_text(canonical_source(fst.read_text()))
    shutil.copyfile(fst, output / "candidatefst.txt")
    shutil.copyfile(adoption_assay.G / "data/germanic-aligned-final.tsv",
                    output / "candidatecorpus.tsv")
    adoption_assay.worker(output / "integration-results.json.gz")
    report = json.loads(gzip.decompress((output / "integration-results.json.gz").read_bytes()))
    if not report["formal"]["EnglishProtoInput"]["stdout"].startswith("1 "):
        raise RuntimeError("The actual complete input parser did not pass the native gate")
    print(json.dumps(dict(
        canonical_unchanged=report["canonical_unchanged"],
        frozen_K_equal=report["frozen_K_equal"], formal=report["formal"],
        selected=report["candidate_baseline"]["summary"]), ensure_ascii=False))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--id")
    parser.add_argument("--worker", type=Path)
    args = parser.parse_args()
    if args.worker:
        worker(args.worker)
    else:
        experiment.host(args.id, entry=Path(__file__), extra_files=[Path(experiment.__file__)])
