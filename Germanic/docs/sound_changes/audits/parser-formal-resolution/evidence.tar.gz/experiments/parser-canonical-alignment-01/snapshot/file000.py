#!/usr/bin/env python3
"""Immutable pre-propagation comparison of production candidate and frozen K."""
import argparse
import csv
import gzip
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

ROOT = next(p for p in Path(__file__).resolve().parents if (p / "Germanic/tools").is_dir())
G = ROOT / "Germanic"
sys.path.insert(0, str(G / "tools"))
RESEARCH = G / "docs/sound_changes/audits/soul-lexical-reassessment"
spec = importlib.util.spec_from_file_location("research", RESEARCH / "experiment.py")
research = importlib.util.module_from_spec(spec)
spec.loader.exec_module(research)


def worker(output):
    import oe_pipeline
    import cascade_baseline as baseline
    from anglo_frisian_experiments import compile_isolated, prepare_definition_image
    from sound_change_order_sensitivity import batch_apply_down

    if not Path("/.dockerenv").exists():
        raise RuntimeError("Container-only native assay")
    old = json.loads(gzip.decompress((RESEARCH / "results.json.gz").read_bytes()))
    controls = json.loads(gzip.decompress((RESEARCH / "control-results.json.gz").read_bytes()))
    canonical = {p: research.resolution.sha(Path(p)) for p in old["protected_before"]}
    for relative in ("fsts/germanic.txt", "data/germanic-aligned-final.tsv"):
        key = "/usr/app/" + relative
        if canonical[key] != old["protected_before"][key]:
            raise RuntimeError("Baseline canonical scientific source differs: " + relative)
    rows = oe_pipeline.load_rows(G / "data/germanic-aligned-final.tsv")
    selected_inputs = [oe_pipeline.evaluation_input(r) for r in rows]
    malformed = ["fúnðánai", "sáiwalǭǭ", "fúnðaanai", "sáiwalq", "xámar az", "sáiwal**"]
    inputs = old["input_order"] + selected_inputs + malformed
    definitions = research.prior.DEFINITIONS + research.resolution.EXTRA + research.EXTRA
    names = ["OldEnglish", "EnglishProtoInput", "EnglishProtoNative", "PGCellInput",
             "OENonHighSyn", "RPosttonic"]
    sequence = [s.foma_identifier if s.kind == "named" else s.inline_text
                for s in oe_pipeline.stages()]
    names = sorted(set(names + sequence))
    recipe = dict(definitions=definitions, insert_after="", insert_rule="", replace={},
                  component_checks=[dict(component=n) for n in names])
    with tempfile.TemporaryDirectory(prefix="capr_adoption_") as temporary:
        directory = Path(temporary)
        image = prepare_definition_image(G / "fsts/germanic.txt", directory)
        if image:
            os.environ["CAPR_FOMA_DEFINITION_IMAGE"] = str(image)
        bins = compile_isolated(G / "fsts/germanic.txt", recipe, [], directory,
                                components_only=True)
        parsed = batch_apply_down(bins["component:EnglishProtoInput"], inputs)
        native = batch_apply_down(bins["component:EnglishProtoNative"], inputs)
        if any(len(v) > 1 for v in parsed):
            raise RuntimeError("New input ambiguity: " + json.dumps(
                [(a, b) for a, b in zip(inputs, parsed) if len(b) > 1], ensure_ascii=False))
        if any(a and a != b for a, b in zip(native, parsed)):
            raise RuntimeError("Existing native analysis changed")
        if any(parsed[-len(malformed):]):
            raise RuntimeError("Malformed input newly admitted")
        final, steps = research.prior.trace(sequence, bins, inputs)
        whole = batch_apply_down(bins["component:OldEnglish"], inputs)
        if final != whole:
            raise RuntimeError("Production composition/serial mismatch")
        if final[:len(old["input_order"])] != old["models"]["K-stress-aware"]["final"]:
            raise RuntimeError("Production candidate differs from frozen K")
        component = {}
        for rule in ("OENonHighSyn", "RPosttonic"):
            component[rule] = dict(zip(controls["controls"], batch_apply_down(
                bins["component:" + rule],
                [research.prior.star(v[0]) for v in controls["controls"].values()])))
        if component["OENonHighSyn"] != controls["component"]["RPosttonic"]:
            raise RuntimeError("Component differs from frozen K controls")
        formal = {}
        for rule in ("EnglishProtoNative", "EnglishProtoInput", "PGCellInput",
                     "OENonHighSyn", "OldEnglish"):
            p = subprocess.run(
                ["foma", "-q", "-e", "load stack " + bins["component:" + rule].name,
                 "-e", "test functional", "-e", "quit"], cwd=directory,
                text=True, capture_output=True, check=True)
            formal[rule] = dict(stdout=p.stdout, stderr=p.stderr)
        p = subprocess.run(
            ["foma", "-q", "-e", "load stack " + bins["component:OENonHighSyn"].name,
             "-e", "load stack " + bins["component:RPosttonic"].name,
             "-e", "test equivalent", "-e", "quit"],
            cwd=directory, text=True, capture_output=True, check=True)
        formal["kernel_equivalence"] = dict(stdout=p.stdout, stderr=p.stderr)
        for key in ("PGCellInput", "OENonHighSyn", "kernel_equivalence"):
            if not formal[key]["stdout"].startswith("1 "):
                raise RuntimeError("Native formal gate failed: " + key + str(formal[key]))
        offset = len(old["input_order"])
        by_id = {r["row_id"]: (r, final[offset + i]) for i, r in enumerate(rows)}
        previous = baseline.read_baseline(
            G / "docs/sound_changes/cascade_baseline/cascade_baseline_outputs.tsv",
            G / "docs/sound_changes/cascade_baseline/cascade_baseline_summary.json")
        migration_path = G / "docs/sound_changes/cascade_baseline/approved_input_migrations.tsv"
        with migration_path.open() as handle:
            reader = csv.DictReader(handle, delimiter="\t")
            fields = reader.fieldnames
            migrations = list(reader)
        for before in previous["records"]:
            if before["row_id"] not in ("2011", "2053", "2201", "2282"):
                continue
            row, values = by_id[before["row_id"]]
            migrations.append(dict(
                row_id=before["row_id"], concept=before["concept"],
                counterpart=before["counterpart"], new_counterpart=row["counterpart"],
                old_proto=before["proto"], new_proto=row["proto"],
                old_outputs=before["outputs"], new_outputs="|".join(values),
                adjudication_memo="Germanic/docs/sound_changes/audits/sc114-adjudication.md"))
        with migration_path.open("w", newline="") as handle:
            writer = csv.DictWriter(handle, fields, delimiter="\t", lineterminator="\n")
            writer.writeheader()
            writer.writerows(migrations)
        candidate = baseline.build_baseline(
            G / "data/germanic-aligned-final.tsv", bins["component:OldEnglish"])
        approved_fields = ("proto", "proto_norm", "fst_input", "counterpart", "outputs", "match")
        changes = [dict(row_id=r["row_id"],
                        before={k: next(p for p in previous["records"]
                                        if p["row_id"] == r["row_id"])[k] for k in approved_fields},
                        after={k: r[k] for k in approved_fields})
                   for r in candidate["records"] if r["row_id"] in ("2011", "2053", "2201", "2282")]
        approval = dict(
            adjudication="SC114",
            adjudication_memo="Germanic/docs/sound_changes/audits/sc114-adjudication.md",
            previous_summary={k: previous["summary"][k] for k in
                              ("outputs_sha256", "lexical_outputs_sha256", "legacy_subset_sha256")},
            legacy_archive_sha256=baseline.projection_sha256(old["immutable380"], "proto_norm"),
            transition_id="nonhigh_cells", changes=changes)
        baseline.validate_cell_transition(previous, candidate, approval)
    if canonical != {p: research.resolution.sha(Path(p)) for p in canonical}:
        raise RuntimeError("Canonical baseline changed")
    result = dict(
        research_sha256=research.resolution.sha(RESEARCH / "results.json.gz"),
        frozen_K_equal=True, formal=formal, rows=rows, input_order=inputs,
        malformed=malformed, parsed=parsed, native=native, final=final,
        component=component, order=sequence,
        transitions=[dict(stage=s["stage"], changes=[
            dict(index=i, before=a, after=b)
            for i, (a, b) in enumerate(zip(s["before"], s["after"])) if a != b])
            for s in steps],
        candidate_baseline=candidate, approval=approval, migrations=migrations,
        canonical_unchanged=True)
    with gzip.open(output, "wt", encoding="utf-8") as handle:
        json.dump(result, handle, ensure_ascii=False, sort_keys=True)


def launch():
    from experiment_snapshot import create_snapshot
    from adjudication_control import run_logged

    paths = sorted(set(
        list((G / "tools").glob("*.py")) +
        list((G / "docs/sound_changes/cascade_baseline").glob("*.tsv")) +
        list((G / "docs/sound_changes/cascade_baseline").glob("*.json")) +
        [G / "data/entry_context_metadata.tsv", G / "data/entry_stage_metadata.tsv",
         ROOT / "backend/compare_fst.py", ROOT / "backend/oe_input_context.py",
         RESEARCH / "experiment.py", RESEARCH / "results.json.gz",
         RESEARCH / "control-results.json.gz",
         RESEARCH.parent / "soul-syncope-resolution/experiment.py",
         RESEARCH.parent / "soul-fulk-oblique/experiment.py",
         RESEARCH.parent / "soul-syncope-resolution/controls.json", Path(__file__)]))
    mapping = {f"file{i:03d}": str(p.relative_to(ROOT)) for i, p in enumerate(paths)}
    inputs = {label: ROOT / relative for label, relative in mapping.items()}
    for label, relative in (("candidatefst", "Germanic/fsts/germanic.txt"),
                            ("candidatecorpus", "Germanic/data/germanic-aligned-final.tsv")):
        mapping[label] = relative
        inputs[label] = ROOT / ".capr-work/candidate" / relative
    layout = ROOT / ".capr-work/adoption-layout.json"
    layout.write_text(json.dumps(mapping))
    inputs["layout"] = layout
    snapshot = create_snapshot(
        "nonhigh-four-cells-01", "Production candidate equals frozen K with measured four-cell approval",
        inputs, expected_outcomes={"kernel": "functional and equivalent", "selected": "383/391"},
        negative_controls=["malformed", "primary-root", "light-final", "long-medial"],
        environment={"private_runtime": "capr-nonhigh-adoption"})
    container = snapshot.stage_in_container()
    bootstrap = """
import json,shutil,sys,tempfile,subprocess
from pathlib import Path
src=Path(sys.argv[1]); layout=json.loads((src/'layout.json').read_text())
root=Path(tempfile.mkdtemp(prefix='capr_adoption_source_'))
try:
    for label,relative in layout.items():
        files=list(src.glob(label+'.*'))
        if len(files)!=1: raise RuntimeError(label)
        dest=root/relative; dest.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(files[0],dest)
    for name in ('compare_fst.py','oe_input_context.py'):
        shutil.copyfile(root/'backend'/name,root/'Germanic'/name)
    subprocess.run(['python3',str(root/'.capr-work/adoption_assay.py'),'--worker',sys.argv[2]],check=True)
finally:
    shutil.rmtree(root)
"""
    destination = container + "/../nonhigh-four-cells-results.json.gz"
    receipt = run_logged(
        ["docker", "compose", "exec", "-T", "backend", "python3", "-c",
         bootstrap, container, destination], label="production-candidate", log_dir=snapshot.staging_dir)
    if receipt["ok"]:
        subprocess.run(["docker", "compose", "cp", "backend:" + destination,
                        str(snapshot.staging_dir / "results.json.gz")], check=True)
    snapshot.complete("passed" if receipt["ok"] else "failed",
                      "Native integration gate, not production propagation",
                      command_receipts=[receipt])
    (snapshot.root / "staging").symlink_to("results", target_is_directory=True)
    print(snapshot.root)
    if not receipt["ok"]:
        raise SystemExit(1)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--worker", type=Path)
    args = parser.parse_args()
    worker(args.worker) if args.worker else launch()
