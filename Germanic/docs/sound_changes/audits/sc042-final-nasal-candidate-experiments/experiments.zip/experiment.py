"""Pinned five-way Model B ablation; Foma runs only in the backend."""

import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
from datetime import datetime, timezone


def dump(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def host():
    root = Path.cwd()
    sys.path.insert(0, str(root / "Germanic/tools"))
    import adjudication_control as control
    import experiment_snapshot as snapshots
    import anglo_frisian_experiments as af
    import adjudication_run
    from executable_facts import parse_defines

    work = Path(__file__).resolve().parent
    source = root / "Germanic/fsts/germanic.txt"
    corpus = root / "Germanic/data/germanic-aligned-final.tsv"
    dump(work / "rows.json", af.corpus_rows(corpus))
    facts = parse_defines(source.read_text())
    merger = facts["PWGmcSurvivingBimoricOUnrounding"].body
    assert merger.count("{*ō} -> {*ā}") == 1
    merger = merger.replace("{*ō} -> {*ā}", "[{*ō}|{*ǭ}] -> {*ā}")
    stop = facts["OEVelarPalatalizationStops"].body
    old = "{*g} -> {*ʤ} || _ EnglishStarFrontVowel,"
    assert stop.count(old) == 1
    stop = stop.replace(old, "{*g} -> {*ʤ} || _ [{*i}|{*í}|{*ì}|{*ī}],")
    plain = {
        "id": "identity", "description": "Unchanged corrected lexical baseline.",
        "definitions": "", "insert_after": "", "insert_rule": "", "replace": {},
        "sources": [], "assumptions": "Exact current source and all 394 selections.",
        "limitations": "The selected nightmare target is mære; executable mare.",
    }
    recipes = [plain]
    for name, g, h in (
        ("merger", False, False), ("merger-g", True, False),
        ("merger-h", False, True), ("complete", True, True),
    ):
        definitions = "define AF0 [?*];\ndefine AF42N [" + merger + "];\n"
        replacements = {"PWGmcSurvivingBimoricOUnrounding": "AF0"}
        if g:
            definitions += "define AFG [Ctx([OEGFricativePalatal .o. (" + stop + ")])];\n"
            replacements["OEVelarPalatalization"] = "AFG"
        if h:
            definitions += (
                "define AFH [FootCtx([[{*x}|{*ç}] -> 0 || "
                "EnglishStarVocalic _ EnglishStarVocalic])];\n"
            )
            replacements["OEHLoss"] = "AFH"
        recipes.append({
            **plain, "id": name, "definitions": definitions,
            "insert_after": "NWGmcInStemNLoss", "insert_rule": "AF42N",
            "replace": replacements,
            "sources": [
                {"key": "RingeTaylor2014", "pages": "44,55,58-60,192,203-204,314"},
                {"key": "HoggGrammar2011", "pages": "254-260,271-275"},
            ],
            "assumptions": "Ablations of frozen Model B, not Model C.",
            "limitations": "No corpus admission, selection change, or production mutation.",
        })
    probes = [{"id": "unrounding", "stage": "PWGmcSurvivingBimoricOUnrounding",
               "side": "after"}]
    dump(work / "recipes.json", {"schema_version": 1, "recipes": recipes, "probes": probes})
    af.load_recipes(work / "recipes.json")
    predictions = {
        "base_commit": "d067bab941d69227652961999fb6b0961851c4d4",
        "raw": ["rátōz", "rátǭ", "gébōz", "gébǭ", "gébôz", "námô", "θánxōn"],
        "clay_entry": "*θ*á*n*x*ō*n", "clay_before": "PGmcNasalLossBeforeX",
        "full_finals": {"flask": ["flæsċe"], "nightmare": ["mære"],
                        "toe": ["tā"], "tongue": ["tunge"]},
        "glossaries": {
            "clay": "Sweet1885 pp36,41: Épinal3 thohae / Corpus207 thoae; "
                    "RingeTaylor2014 p314 thōhæ / thōæ. ae/e and h phonetics open.",
            "fringe": "Sweet1885 pp104,107: Épinal1066/Erfurt uulohum; "
                      "Corpus2122 uuloum; normalized wlōhum / wlōum, dative plural.",
        },
        "controls": [
            ["oral", "AF42N", "*r*á*t*ō", "*r*á*t*ā"],
            ["nasal", "AF42N", "*r*á*t*ǭ", "*r*á*t*ā"],
            ["trimoric", "AF42N", "*r*á*t*ô", "*r*á*t*ô"],
            ["monosyllabic-nasal-root", "AF42N", "*θ*ǭ", "*θ*ǭ"],
            ["internal-nasal-root", "AF42N", "*r*ǭ*t*e", "*r*ǭ*t*e"],
            ["nasal-low-root", "AF42N", "*θ*ã*x*ō*n", "*θ*ã*x*ō*n"],
            ["consonant-protected", "AF42N", "*r*á*t*ō*n", "*r*á*t*ō*n"],
            ["short-nasal", "AF42N", "*r*á*t*ą", "*r*á*t*ą"],
            ["low-front-stop", "AFG", "*t*u*n*g*ǣ", "*t*u*n*g*ǣ"],
            ["original-high-stop", "AFG", "*l*a*n*g*ī", "*l*a*n*ʤ*ī"],
            ["singleton-g", "AFG", "*b*e*g*e", "*b*e*ʝ*e"],
            ["initial-g", "AFG", "*g*æ", "*ʝ*æ"],
            ["fringe", "AFH", "*w*l*ō*x*u*m", "*w*l*ō*u*m"],
            ["front-h", "AFH", "*θ*ō*ç*æ", "*θ*ō*æ"],
            ["geminate-x", "AFH", "*a*x*x*a", "*a*x*x*a"],
            ["geminate-c", "AFH", "*a*ç*ç*a", "*a*ç*ç*a"],
            ["initial-h", "AFH", "*x*a", "*x*a"],
            ["protected-h", "AFH", "*a*x*t*a", "*a*x*t*a"],
            ["pretonic-h", "AFH", "*ᶠ*b*i*x*í*n*d*a*n", "*ᶠ*b*i*x*í*n*d*a*n"],
        ],
    }
    dump(work / "predictions.json", predictions)
    snapshot = snapshots.create_snapshot(
        "maere-candidate-" + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S"),
        "Corrected lexical baseline: five-way final-nasal merger ablation.",
        {"source": source, "corpus": corpus, "rows": work / "rows.json",
         "contexts": corpus.parent / af.METADATA_FILENAME,
         "context_helper": root / "backend/oe_input_context.py",
         "recipes": work / "recipes.json", "predictions": work / "predictions.json",
         "driver": Path(__file__).resolve()},
        variants={r["id"]: json.dumps(r, ensure_ascii=False, sort_keys=True) for r in recipes},
        probes=probes, expected_outcomes=predictions,
        negative_controls=[c[0] for c in predictions["controls"]],
    )
    dump(work / "snapshot.json", {"snapshot": str(snapshot.root)})
    run = adjudication_run.load("SC042")
    run.complete_stage("SNAPSHOT", note="Context-assembled corrected selections, source, recipes and controls pinned.",
                       evidence={"snapshot_root": str(snapshot.root)})
    with control.runtime_lock("SC042 source-supported candidate ablations"):
        directory = snapshot.stage_in_container()
        args = [directory + "/" + snapshot.input_path(k).name
                for k in ("driver", "source", "rows", "recipes", "predictions")]
        output = directory + "/observations.json"
        receipt = control.run_logged(
            ["docker", "compose", "exec", "-T", "backend", "python3", "-u", *args, output],
            label="maere-five-way-ablation", cwd=root, log_dir=work / "validation",
        )
    dump(work / "receipt.json", receipt)
    if receipt["ok"]:
        subprocess.run(["docker", "compose", "cp", "backend:" + output,
                        str(work / "observations.json")], check=True)
    snapshot.complete("passed" if receipt["ok"] else "failed",
                      "Five-way experiment; scientific interpretation remains separate.", [receipt])
    print(Path(receipt["stdout_log"]).read_text())
    print(Path(receipt["stderr_log"]).read_text())
    raise SystemExit(receipt["returncode"])


def container(source, rows_path, recipes_path, predictions_path, output):
    assert Path("/usr/app/tools").is_dir(), "Foma must run in backend"
    sys.path.insert(0, "/usr/app/tools")
    import anglo_frisian_experiments as af
    from sound_change_order_sensitivity import batch_apply_down

    recipes = af.load_recipes(recipes_path)["recipes"]
    predictions = json.loads(predictions_path.read_text())
    runtime = af.layout()
    protected = [runtime.germanic_fst, runtime.corpus_tsv, runtime.build_manifest,
                 runtime.bin_dir / "old_english.bin"]
    protected += [p for p in (runtime.docs_dir / "sound_changes/cascade_baseline").glob("*")
                  if p.is_file()]
    before = {str(p): af.digest(p) for p in protected if p.is_file()}
    rows = json.loads(rows_path.read_text())
    assert len(rows) == 394
    forms = [af.oe_pipeline.evaluation_input(r) for r in rows] + predictions["raw"]
    canonical = batch_apply_down(runtime.bin_dir / "old_english.bin", forms[:394])
    assert all(len(v) == 1 for v in canonical)
    assert sum(v == [r["counterpart"]] for r, v in zip(rows, canonical)) == 385
    assert next(v for r, v in zip(rows, canonical) if r["id"] == "2141") == ["mare"]
    image_dir = output.parent / "image"
    image_dir.mkdir()
    image = af.prepare_definition_image(source, image_dir)
    os.environ["CAPR_FOMA_DEFINITION_IMAGE"] = str(image)
    result = {"predictions": predictions, "protected_before": before, "variants": {}}
    for recipe in recipes:
        directory = output.parent / recipe["id"]
        directory.mkdir()
        order, _ = af.context_lifted_order(recipe, af.complete_variant_order(recipe))
        bins = af.compile_isolated(source, recipe, [], directory, diagnostic_stages=order)
        by_stage = {stage: bins["diagnostic:" + str(i)] for i, stage in enumerate(order)}
        finals = batch_apply_down(bins["final"], forms)
        states, stages = [[f] for f in forms], []
        for i, stage in enumerate(order):
            applied = iter(batch_apply_down(by_stage[stage], [v for s in states for v in s]))
            states = [sorted({v for _ in s for v in next(applied)}) for s in states]
            stages.append({"stage": stage, "outputs": states})
        assert states == finals, "Component trace differs from complete composition"
        assert all(len(v) == 1 for v in finals[:394]), "Corpus rejection/ambiguity"
        checks = []
        for name, stage, value, expected in predictions["controls"]:
            if stage in by_stage:
                actual = batch_apply_down(by_stage[stage], [value])[0]
                checks.append({"id": name, "stage": stage, "input": value,
                               "expected": expected, "outputs": actual})
                assert actual == [expected], checks[-1]
        clay, clay_trace = predictions["clay_entry"], []
        for stage in order[order.index(predictions["clay_before"]):]:
            values = batch_apply_down(by_stage[stage], [clay])[0]
            assert len(values) == 1, (recipe["id"], "clay", stage, values)
            clay = values[0]
            clay_trace.append({"stage": stage, "output": clay})
        record = {
            "order": order, "controls": checks, "clay": clay_trace,
            "matches": sum(v == [r["counterpart"]] for r, v in zip(rows, finals)),
            "changed": [r["id"] for r, v, b in zip(rows, finals, canonical) if v != b],
            "rows": [{**r, "outputs": v, "baseline_outputs": b,
                      "derivation": [{"stage": s["stage"], "outputs": s["outputs"][i]}
                                     for s in stages]}
                     for i, (r, v, b) in enumerate(zip(rows, finals, canonical))],
            "raw": [{"input": f, "outputs": finals[394+i],
                     "derivation": [{"stage": s["stage"], "outputs": s["outputs"][394+i]}
                                    for s in stages]}
                    for i, f in enumerate(predictions["raw"])],
            "binary_sha256": {k: af.digest(p) for k, p in bins.items()},
        }
        result["variants"][recipe["id"]] = record
        dump(output, result)
        print(recipe["id"], record["matches"], record["changed"], flush=True)
        if recipe["id"] == "identity":
            assert not record["changed"]
        if recipe["id"] == "complete":
            for concept, expected in predictions["full_finals"].items():
                assert next(r["outputs"] for r in record["rows"] if r["concept"] == concept) == expected
    result["protected_after"] = {p: af.digest(Path(p)) for p in before}
    assert result["protected_after"] == before, "Experiment mutated production"
    dump(output, result)


if __name__ == "__main__":
    if len(sys.argv) == 1:
        host()
    else:
        container(*map(Path, sys.argv[1:]))
