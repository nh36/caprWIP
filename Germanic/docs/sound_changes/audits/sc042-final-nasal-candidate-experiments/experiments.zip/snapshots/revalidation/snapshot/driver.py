"""Source-backed oblique hypotheses and ordering trials on pinned matrix bins."""

import hashlib
import json
from pathlib import Path
import subprocess
import sys


def dump(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def host():
    root = Path.cwd()
    sys.path.insert(0, str(root / "Germanic/tools"))
    import adjudication_control as control
    import adjudication_run
    import experiment_snapshot as snapshots

    work = Path(__file__).resolve().parent
    parent = json.loads((work / "receipt.json").read_text())
    assert parent["ok"]
    directory = Path(parent["argv"][-1]).parent
    hypotheses = {
        "parent_container": str(directory),
        "parent_observations_sha256": hashlib.sha256((work / "observations.json").read_bytes()).hexdigest(),
        "obliques": [
            {"id": "accusative-singular", "raw": "fláskōnų",
             "starred": "*f*l*á*s*k*ō*n*ų", "target": "flascan",
             "sources": "Hecht1900:66.8-10; Ringe2017:312; RingeTaylor2014:55-58"},
            {"id": "dative-singular", "raw": "fláskōni",
             "starred": "*f*l*á*s*k*ō*n*i", "target": "flascan",
             "sources": "Hecht1900:142.2-4; Ringe2017:312; RingeTaylor2014:55-58"},
        ],
        "entry_before": "PGmcNasalLossBeforeX",
        "limitations": "Generic paradigm applied to flask, not source quotations of complete forms. "
                       "A post-tokenization trace is not a successful ordinary input.",
        "h_controls": [
            ["fringe", "*w*l*ō*x*u*m", "*w*l*ō*u*m"],
            ["fixed-front-positive", "*t*ā*x*e", "*t*ā*e"],
            ["palatal-positive", "*t*ā*ç*e", "*t*ā*e"],
        ],
    }
    dump(work / "supplement-predictions.json", hypotheses)
    snapshot = snapshots.create_snapshot(
        "maere-candidate-supplement-20261113",
        "Bounded complete-oblique hypotheses and downstream falsification on authenticated matrix bins.",
        {"driver": Path(__file__).resolve(), "predictions": work / "supplement-predictions.json",
         "parent": work / "observations.json", "parent_receipt": work / "receipt.json",
         "source": root / "Germanic/fsts/germanic.txt"},
        variants={}, probes=[], expected_outcomes=hypotheses,
        negative_controls=["loss-contraction-reversal", "front-only-fringe"],
    )
    run = adjudication_run.load("SC042")
    archive = root / ".capr-work/runs/archive/SC042-initial-candidate-matrix-20261113"
    run.root.rename(archive)
    run = adjudication_run.start("SC042")
    adjudication_run.set_scientific_reference(
        run, "d067bab941d69227652961999fb6b0961851c4d4",
        "Corrected lexical baseline; replay every pinned matrix output under a stable worktree.")
    run.complete_stage("INSPECT", note="Original readings and initial matrix preserved; "
                       "independent migration helper edits during the first command changed its receipt identity, "
                       "not the pinned compilation inputs. Recheck all outputs, controls and bins.")
    preflight = control.preflight("SC042", probe_runner=False)
    assert not preflight.blocked, preflight.render()
    run.complete_stage("PREFLIGHT", note="Fresh investigation preflight.", evidence=preflight.to_json())
    run.complete_stage("SNAPSHOT", note="Matrix revalidation, oblique and falsification driver pinned.",
                       evidence={"snapshot_root": str(snapshot.root)})
    dump(work / "active-snapshot.json", {"snapshot": str(snapshot.root)})
    with control.runtime_lock("SC042 candidate oblique and downstream controls"):
        container = snapshot.stage_in_container()
        args = [container + "/" + snapshot.input_path(k).name
                for k in ("driver", "predictions", "parent", "source")]
        output = container + "/supplement-observations.json"
        receipt = control.run_logged(
            ["docker", "compose", "exec", "-T", "backend", "python3", "-u", *args, output],
            label="maere-obliques-and-falsification", log_dir=work / "validation", cwd=root)
        dump(work / "supplement-receipt.json", receipt)
        if receipt["ok"]:
            subprocess.run(["docker", "compose", "cp", "backend:" + output,
                            str(work / "supplement-observations.json")], check=True)
    snapshot.complete("passed" if receipt["ok"] else "failed",
                      "Assay execution and deliberate failures; oblique histories remain separately assessed.",
                      [receipt])
    print(Path(receipt["stdout_log"]).read_text())
    print(Path(receipt["stderr_log"]).read_text())
    raise SystemExit(receipt["returncode"])


def container(predictions_path, parent_path, source, output):
    assert Path("/usr/app/tools").is_dir()
    sys.path.insert(0, "/usr/app/tools")
    import anglo_frisian_experiments as af
    from sound_change_order_sensitivity import batch_apply_down

    predictions = json.loads(predictions_path.read_text())
    assert af.digest(parent_path) == predictions["parent_observations_sha256"]
    parent = json.loads(parent_path.read_text())
    assert af.digest(source) == parent["protected_before"]["/usr/app/fsts/germanic.txt"]
    assert all(af.digest(Path(p)) == digest for p, digest in parent["protected_before"].items())
    result = {"predictions": predictions, "variants": {}}
    for model, prior in parent["variants"].items():
        directory = Path(predictions["parent_container"]) / model
        order = prior["order"]
        bins = {}
        for i, stage in enumerate(order):
            path = directory / f"af_diagnostic_{i:03d}.bin"
            assert af.digest(path) == prior["binary_sha256"]["diagnostic:" + str(i)]
            bins[stage] = path
        final = directory / "old_english_variant.bin"
        assert af.digest(final) == prior["binary_sha256"]["final"]
        forms = [r["fst_input"] for r in prior["rows"]] + [r["input"] for r in prior["raw"]]
        assert batch_apply_down(final, forms) == [
            r["outputs"] for r in [*prior["rows"], *prior["raw"]]]
        states = [[value] for value in forms]
        for i, stage in enumerate(order):
            applied = iter(batch_apply_down(
                bins[stage], [v for alternatives in states for v in alternatives]))
            states = [sorted({v for _ in alternatives for v in next(applied)})
                      for alternatives in states]
            assert states == [r["derivation"][i]["outputs"]
                              for r in [*prior["rows"], *prior["raw"]]], (model, stage)
        for control in prior["controls"]:
            assert batch_apply_down(bins[control["stage"]], [control["input"]])[0] == control["outputs"]

        def trace(sequence, value):
            states, steps = [value], []
            for stage in sequence:
                states = sorted({v for group in batch_apply_down(bins[stage], states) for v in group})
                steps.append({"stage": stage, "outputs": states})
                if len(states) != 1:
                    break
            return {"outputs": states, "trace": steps}

        obliques = []
        for case in predictions["obliques"]:
            obliques.append({
                **case, "ordinary": trace(order, case["raw"]),
                "post_tokenization": trace(order[order.index(predictions["entry_before"]):], case["starred"]),
            })
        clay = trace(order[order.index(predictions["entry_before"]):], "*θ*á*n*x*ō*n")
        assert [(s["stage"], s["outputs"]) for s in clay["trace"]] == [
            (s["stage"], [s["output"]]) for s in prior["clay"]]
        record = {"obliques": obliques, "entire_matrix_replayed": True}
        if model == "complete":
            h = "AFH"
            before_h = next(s["output"] for s in reversed(prior["clay"])
                            if s["stage"] == order[order.index(h)-1])
            reversal = trace(["OEContraction", h], before_h)
            surface = trace(order[order.index("OEContraction")+1:], reversal["outputs"][0])
            assert "*x" in before_h or "*ç" in before_h
            assert reversal["trace"][0]["outputs"] == [before_h]
            assert surface["outputs"] != ["þō"]
            record["clay_reversal"] = {**reversal, "surface": surface}
            record["h_controls"] = []
            for name, value, expected in predictions["h_controls"]:
                actual = trace([h], value)
                assert actual["outputs"] == [expected]
                record["h_controls"].append({"id": name, "input": value, **actual})
            forms = [r["fst_input"] for r in prior["rows"]]
            reorders = {}
            for name, anchor, after in (
                ("merger-before-z", "EAFFinalZDeletion", False),
                ("merger-after-stressed-fronting", "EAFBrightening", True),
                ("merger-after-final-fronting", "EAFBrighteningLongFinal", True),
                ("sk-before-restoration", "OEARestoration", False),
            ):
                moved = "OESkPalatalization" if name.startswith("sk-") else "AF42N"
                reordered = [s for s in order if s != moved]
                i = reordered.index(anchor) + int(after)
                reordered.insert(i, moved)
                states, checkpoints = [[f] for f in forms], []
                for stage in reordered:
                    applied = iter(batch_apply_down(
                        bins[stage], [v for alternatives in states for v in alternatives]))
                    states = [sorted({v for _ in alternatives for v in next(applied)})
                              for alternatives in states]
                    assert all(len(s) == 1 for s in states), (name, stage, states)
                    checkpoints.append({"stage": stage, "outputs": states})
                changes = [
                    {"id": row["id"], "concept": row["concept"],
                     "before": row["outputs"], "outputs": values,
                     "trace": [{"stage": s["stage"], "outputs": s["outputs"][i]}
                               for s in checkpoints]}
                    for i, (row, values) in enumerate(zip(prior["rows"], states))
                    if values != row["outputs"]]
                reorders[name] = changes
            record["reorders"] = reorders
            import os
            os.environ["CAPR_FOMA_DEFINITION_IMAGE"] = str(
                Path(predictions["parent_container"]) / "image/defined.bin")
            trial = output.parent / "front-only"
            trial.mkdir()
            recipe = {
                "id": "front-only", "replace": {}, "insert_rule": "",
                "insert_after": "", "definitions":
                "define AFFrontH ["
                "{*x} -> 0 || EnglishStarFrontVowel _ EnglishStarVocalic,"
                "{*x} -> 0 || EnglishStarVocalic _ EnglishStarFrontVowel];",
                "component_checks": [{"component": "AFFrontH"}],
            }
            control = af.compile_isolated(source, recipe, [], trial, components_only=True)
            actual = batch_apply_down(
                control["component:AFFrontH"], ["*w*l*ō*x*u*m", "*t*ā*x*e"])
            assert actual == [["*w*l*ō*x*u*m"], ["*t*ā*e"]]
            record["front_only_trial"] = actual
            paired = batch_apply_down(
                bins["AF42N"], ["*r*ǭ*t*ǭ", "*θ*ã*x*ǭ"])
            assert paired == [["*r*ǭ*t*ā"], ["*θ*ã*x*ā"]]
            record["nasal_root_with_merging_ending"] = paired
        result["variants"][model] = record
        dump(output, result)
        print(model, [(c["id"], c["ordinary"]["outputs"], c["post_tokenization"]["outputs"])
                      for c in obliques], flush=True)
    assert all(af.digest(Path(p)) == digest for p, digest in parent["protected_before"].items())


if __name__ == "__main__":
    if len(sys.argv) == 1:
        host()
    else:
        container(*map(Path, sys.argv[1:]))
