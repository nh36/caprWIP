#!/usr/bin/env python3
"""Opt-in, snapshot-pinned finite-domain follow-up; no production writes."""
import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import subprocess
import sys
import tempfile
import time
from unittest.mock import patch
import uuid

ROOT = Path("/usr/app") if Path("/usr/app/tools").is_dir() else Path.cwd()
sys.path.insert(0, str(ROOT / ("tools" if ROOT == Path("/usr/app") else "Germanic/tools")))
HELPERS = ("anglo_frisian_experiments.py", "oe_pipeline.py", "capr_runtime.py",
           "sound_change_order_sensitivity.py", "executable_facts.py")


def orders(plan, names):
    result = {}
    for label, operations in plan["configurations"].items():
        order = list(names)
        for operation in operations:
            if "move" in operation:
                name = operation["move"]
                order.remove(name)
                order.insert(order.index(operation["after"]) + 1, name)
            elif "replace" in operation:
                order = [operation["with"] if n == operation["replace"] else n
                         for n in order]
            elif "insert" in operation:
                order.insert(order.index(operation["after"]) + 1, operation["insert"])
            elif "remove" in operation:
                order.remove(operation["remove"])
            else:
                raise ValueError(operation)
        result[label] = order
    return result


def worker(snapshot):
    import anglo_frisian_experiments as compiler
    from capr_runtime import check_build_manifest, layout
    import oe_pipeline
    from sound_change_order_sensitivity import batch_apply_down

    started = time.perf_counter()
    runtime = layout()
    plan = json.loads((snapshot / "plan.json").read_text())
    source = snapshot / "source.txt"
    assert source.read_bytes() == runtime.germanic_fst.read_bytes()
    assert (snapshot / "corpus.tsv").read_bytes() == runtime.corpus_tsv.read_bytes()
    for name, digest in plan["helpers"].items():
        assert hashlib.sha256((runtime.tools_dir / name).read_bytes()).hexdigest() == digest
    assert not check_build_manifest(oe_pipeline.expected_snapshot_bins() + ["old_english.bin"])
    rows = oe_pipeline.load_rows(runtime.corpus_tsv)
    raw = [r["fst_input"] for r in rows]
    names = [s.foma_identifier for s in oe_pipeline.stages()]
    configurations = orders(plan, names)
    first = names.index(plan["start_after"]) + 1
    stages = set(plan.get("live_stages", [])) | {plan["start_after"]}
    live = {name: batch_apply_down(
        runtime.bin_dir / oe_pipeline.stage_for(name).snapshot_bin, raw)
        for name in stages}
    finals = batch_apply_down(runtime.bin_dir / "old_english.bin", raw)
    incoming = [v[0] for v in live[plan["start_after"]]]
    assert all(len(v) == 1 for v in live[plan["start_after"]])
    definitions = list(plan.get("definitions", {}).values())
    queries = {}
    for label, order in configurations.items():
        assert order[:first] == names[:first], label
        queries[label + ":corpus"] = (order[first:], incoming)
        picked = [i for i, row in enumerate(rows)
                  if row["concept"] in plan.get("trace_concepts", [])]
        for stop in plan.get("trace_stages", []):
            aliases = plan.get("aliases", {}).get(label, {})
            target = aliases.get(stop, stop)
            if target in order:
                assert order.index(target) >= first
                queries[label + ":trace:" + stop] = (
                    order[first:order.index(target) + 1],
                    [incoming[i] for i in picked])
        if label in plan.get("complete_traces", []):
            for position in range(first, len(order)):
                stop = order[position]
                queries[label + ":all:" + stop] = (
                    order[first:position + 1], [incoming[i] for i in picked])
        for stop in plan.get("census_stages", []):
            aliases = plan.get("aliases", {}).get(label, {})
            target = aliases.get(stop, stop)
            at = order.index(target)
            assert at >= first
            for side, end in [("before", at), ("after", at + 1)]:
                queries[label + ":census:" + stop + ":" + side] = (
                    order[first:end], incoming)
    for label, query in plan.get("queries", {}).items():
        members = query.get("members")
        if "configuration" in query:
            order = configurations[query["configuration"]]
            begin = order.index(query["after"]) + 1 if query.get("after") else 0
            end = order.index(query["through"]) + 1 if query.get("through") else len(order)
            members = order[begin:end]
        queries[label] = (members, query["inputs"])
    labels = {}
    for i, (label, (members, inputs)) in enumerate(queries.items()):
        name = "FQ" + str(i)
        definitions.append("define " + name + " [" + compiler.foma_domain(inputs)
                           + (".o." + ".o.".join(members) if members else "") + "];")
        labels[label] = name
    recipe = {"definitions": "\n".join(definitions), "replace": {},
              "insert_rule": None, "insert_after": None,
              "component_checks": [{"component": name} for name in labels.values()]}
    costs = []

    def measured(script, directory):
        begun = time.perf_counter()
        with tempfile.TemporaryFile() as out, tempfile.TemporaryFile() as err:
            process = subprocess.Popen(
                ["foma", "-q", "-f", script.name], cwd=directory, stdout=out, stderr=err)
            _, status, usage = os.wait4(process.pid, 0)
            process.returncode = os.waitstatus_to_exitcode(status)
            out.seek(0)
            err.seek(0)
            log = out.read().decode() + err.read().decode()
            costs.append({"script": script.name, "seconds": time.perf_counter() - begun,
                          "peak_rss_kib": usage.ru_maxrss,
                          "returncode": process.returncode})
            if process.returncode or re.search(r"(?im)\b(error|syntax error|not defined)\b", log):
                raise RuntimeError(log[-8000:])

    with tempfile.TemporaryDirectory(prefix="capr_sc047_followup_") as temporary:
        directory = Path(temporary)
        with patch.object(compiler, "_compile_foma", measured):
            image = compiler.prepare_definition_image(source, directory)
            assert image is not None
            with patch.dict(os.environ, {"CAPR_FOMA_DEFINITION_IMAGE": str(image)}):
                bins = compiler.compile_isolated(
                    source, recipe, [], directory, components_only=True)
            assert (directory / "experiment.foma").read_text().startswith("load defined ")
        outputs = {label: batch_apply_down(bins["component:" + name], queries[label][1])
                   for label, name in labels.items()}
    corpus = {}
    for label in configurations:
        observed = outputs[label + ":corpus"]
        corpus[label] = {
            "matches": sum(r["counterpart"] in v for r, v in zip(rows, observed)),
            "changed": sum(v != b for v, b in zip(observed, finals)),
            "rejected": sum(not v for v in observed),
            "ambiguous": sum(len(v) > 1 for v in observed),
            "rows": [{**r, "baseline": finals[i], "outputs": observed[i]}
                     for i, r in enumerate(rows)]}
    assert len(rows) == 394 and corpus["identity"]["matches"] == 386
    assert corpus["identity"]["changed"] == 0
    return {
        "source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
        "corpus_sha256": hashlib.sha256((snapshot / "corpus.tsv").read_bytes()).hexdigest(),
        "rows": [{**r, "final": finals[i],
                  "live": {stage: values[i] for stage, values in live.items()}}
                 for i, r in enumerate(rows)],
        "witness_row_ids": [rows[i]["row_id"] for i in picked],
        "configurations": configurations, "corpus": corpus,
        "queries": {label: {"members": members, "inputs": inputs, "outputs": outputs[label]}
                    for label, (members, inputs) in queries.items()},
        "cost": {"networks": len(queries), "compiler": costs,
                 "variants": len(configurations), "seconds": time.perf_counter() - started}}


def capture(plan_path):
    from adjudication_control import run_logged
    from capr_runtime import container_command
    from experiment_snapshot import create_snapshot

    work = ROOT / ".capr-work/sc047-followup"
    plan = json.loads(plan_path.read_text())
    plan["helpers"] = {
        name: hashlib.sha256((ROOT / "Germanic/tools" / name).read_bytes()).hexdigest()
        for name in HELPERS}
    prepared = work / (plan_path.stem + "-pinned.json")
    prepared.write_text(json.dumps(plan, ensure_ascii=False, indent=2))
    snapshot = create_snapshot(
        "sc047-followup-" + uuid.uuid4().hex[:8], plan["purpose"],
        {"source": ROOT / "Germanic/fsts/germanic.txt",
         "corpus": ROOT / "Germanic/data/germanic-aligned-final.tsv",
         "contexts": ROOT / "Germanic/data/entry_context_metadata.tsv",
         "worker": Path(__file__), "plan": prepared,
         **{Path(name).stem: ROOT / "Germanic/tools" / name for name in HELPERS}},
        variants=plan.get("definitions", {}),
        probes=[form for query in plan.get("queries", {}).values() for form in query["inputs"]],
        expected_outcomes=plan["predictions"], negative_controls=plan["negative_controls"])
    if plan.get("journal_sc"):
        import adjudication_run
        adjudication_run.load(plan["journal_sc"]).complete_stage(
            "SNAPSHOT", evidence={"snapshot_root": str(snapshot.root)})
    container = snapshot.stage_in_container()
    receipt = run_logged(
        container_command("cd /usr/app && python3 " + shlex.quote(container + "/worker.py")
                          + " --worker " + shlex.quote(container)),
        label=plan_path.stem, log_dir=snapshot.root / "execution")
    if receipt["ok"]:
        (snapshot.staging_dir / "observed.json").write_bytes(
            Path(receipt["stdout_log"]).read_bytes())
    snapshot.complete("passed" if receipt["ok"] else "failed",
                      "Executed pinned assay; historical acceptance requires interpretation.",
                      [receipt])
    (work / (plan_path.stem + "-receipt.json")).write_text(json.dumps(
        {"snapshot_root": str(snapshot.root), "receipt": receipt}, indent=2))
    print(snapshot.root)
    if not receipt["ok"]:
        raise RuntimeError(Path(receipt["stderr_log"]).read_text())


if __name__ == "__main__":
    if sys.argv[1:2] == ["--worker"]:
        print(json.dumps(worker(Path(sys.argv[2])), ensure_ascii=False))
    elif sys.argv[1:2] == ["--capture"]:
        capture(Path(sys.argv[2]))
    else:
        raise SystemExit("use --capture PLAN or --worker SNAPSHOT")
