import hashlib
import json
from pathlib import Path
import shlex
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "Germanic/tools"))
from capr_runtime import container_command

code = """
import hashlib, json, sys
sys.path.insert(0, 'tools')
import oe_pipeline
from capr_runtime import check_build_manifest, layout
from sound_change_order_sensitivity import batch_apply_down
rt = layout()
assert not check_build_manifest(oe_pipeline.expected_snapshot_bins() + ['old_english.bin'])
rows = oe_pipeline.load_rows(rt.corpus_tsv)
outputs = batch_apply_down(rt.bin_dir / 'old_english.bin',
                           [row['fst_input'] for row in rows])
assert len(outputs) == len(rows) == 394
records = [{**row, 'accepted': str(int(bool(out))), 'output_count': str(len(out)),
            'match': str(int(row['counterpart'] in out)), 'outputs': '|'.join(out)}
           for row, out in zip(rows, outputs)]
print(json.dumps({'records': records,
                  'manifest': json.loads(rt.build_manifest.read_text()),
                  'source_sha256': hashlib.sha256(rt.germanic_fst.read_bytes()).hexdigest()},
                 ensure_ascii=False))
"""
raw = subprocess.check_output(
    container_command("cd /usr/app && python3 -c " + shlex.quote(code)), cwd=ROOT, text=True)
live = json.loads(raw)
control = json.loads((ROOT / ".capr-work/sc044/control-result.json").read_text())["corpus"]["records"]
current_by_id = {row["row_id"]: row for row in live["records"]}
control_by_id = {row["row_id"]: row for row in control}
assert len(current_by_id) == len(control_by_id) == len(control) == 394
assert current_by_id == control_by_id
live["comparison"] = {
    "compared": len(control), "all_complete_records_identical": True,
    "matches": sum(row["match"] == "1" for row in control),
    "rejected": sum(row["accepted"] != "1" for row in control),
    "ambiguous": sum(int(row["output_count"]) > 1 for row in control),
    "mismatches": [row for row in control if row["match"] != "1"],
    "control_sha256": hashlib.sha256(
        (ROOT / ".capr-work/sc044/control-result.json").read_bytes()).hexdigest(),
}
(ROOT / ".capr-work/sc044-followup/production-parity.json").write_text(
    json.dumps(live, ensure_ascii=False, indent=2))
print(json.dumps(live["comparison"], ensure_ascii=False, indent=2))
