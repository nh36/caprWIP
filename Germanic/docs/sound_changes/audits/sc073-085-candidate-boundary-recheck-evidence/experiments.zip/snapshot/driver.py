"""Commit-pinned toe boundary replay through the existing isolated compiler."""
import csv
import hashlib
import json
from pathlib import Path
import subprocess
import sys


def dump(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def host():
    root = Path.cwd()
    sys.path.insert(0, str(root / "Germanic/tools"))
    import adjudication_control as control
    import experiment_snapshot
    import oe_pipeline
    from anglo_frisian_experiments import corpus_rows

    work = Path(__file__).resolve().parent
    head = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
    assert head == "4b232d22ad3d55ecf0eb2111b736dcf4349a4bde"
    assert not subprocess.check_output(["git", "status", "--porcelain"], text=True)
    stages = oe_pipeline.stages()
    original = [s.inline_text if s.kind == "inline" else s.foma_identifier for s in stages]
    loss, merger = "OEHLoss", "OEUnstressedAEMerger"
    for name in (loss, merger, "OEContraction"):
        assert original.count(name) == 1
    earlier = list(original)
    earlier.remove(loss)
    earlier.insert(earlier.index(merger), loss)
    later = list(original)
    later.remove(merger)
    later.insert(later.index(loss) + 1, merger)
    variants = {"identity": original, "loss_before_merger": earlier,
                "merger_after_loss": later}
    definitions = []
    roots = {}
    for number, (name, order) in enumerate(variants.items()):
        roots[name] = "AFT" + str(number)
        definitions.append("define " + roots[name] + " " + " .o. ".join(order) + ";")
    recipe = {
        "id": "toe-reviewed-candidate", "insert_rule": None,
        "insert_after": None, "replace": {},
        "definitions": "\n".join(definitions),
        "component_checks": [{"component": s} for s in dict.fromkeys(
            original + list(roots.values()))],
    }
    corpus = root / "Germanic/data/germanic-aligned-final.tsv"
    rows = corpus_rows(corpus)
    payload = {"head": head, "orders": variants, "roots": roots, "rows": rows,
               "stage_metadata": [s.__dict__ for s in stages]}
    dump(work / "payload.json", payload)
    dump(work / "recipe.json", recipe)
    snapshot = experiment_snapshot.create_snapshot(
        "toe-boundary-4b232d22",
        "Identity and both SC073/SC085 displacements on the reviewed candidate; no production mutation.",
        {"source": root / "Germanic/fsts/germanic.txt", "corpus": corpus,
         "contexts": corpus.parent / "entry_context_metadata.tsv",
         "payload": work / "payload.json", "recipe": work / "recipe.json",
         "driver": Path(__file__).resolve(),
         "pipeline": root / "Germanic/tools/oe_pipeline.py",
         "compiler": root / "Germanic/tools/anglo_frisian_experiments.py",
         "baseline": root / "Germanic/docs/sound_changes/cascade_baseline/cascade_baseline_outputs.tsv"},
        variants={name: " .o. ".join(order) for name, order in variants.items()},
        expected_outcomes={"identity_toe": ["tā"], "identity_nightmare": ["mære"],
                           "identity_corpus_delta": []},
        negative_controls=["Both displacements preserve every component exactly once."])
    dump(work / "snapshot.json", {"root": str(snapshot.root)})
    compiled = snapshot.compile_isolated("source", "recipe", components_only=True)
    dump(work / "compile.json", compiled)
    payload_container = compiled["container_source"] + "/" + snapshot.input_path("payload").name
    driver = compiled["container_source"] + "/" + snapshot.input_path("driver").name
    baseline = compiled["container_source"] + "/" + snapshot.input_path("baseline").name
    output = compiled["container_output"] + "/observed.json"
    args = [driver, payload_container, json.dumps(compiled["bins"]), baseline, output]
    receipt = control.run_logged(
        ["docker", "compose", "exec", "-T", "backend", "python3", *args],
        label="toe-boundary-4b232d22-assay", log_dir=snapshot.staging_dir)
    dump(work / "assay-receipt.json", receipt)
    if not receipt["ok"]:
        raise RuntimeError(Path(receipt["stderr_log"]).read_text())
    subprocess.run(["docker", "compose", "cp", "backend:" + output,
                    str(snapshot.staging_dir / "observed.json")], check=True)
    dump(snapshot.staging_dir / "compile.json", compiled)
    snapshot.complete("passed", "Fresh current-source identity and both displacements measured.",
                      [compiled["receipt"], receipt])
    subprocess.run(["cp", str(snapshot.results_dir / "observed.json"),
                    str(work / "observed.json")], check=True)
    print((work / "observed.json").read_text())


def worker(payload_path, bins_json, baseline_path, output):
    sys.path.insert(0, "/usr/app/tools")
    from sound_change_order_sensitivity import batch_apply_down
    payload = json.loads(payload_path.read_text())
    bins = {key.removeprefix("component:"): Path(value)
            for key, value in json.loads(bins_json).items()}
    rows = payload["rows"]
    toe = next(r for r in rows if r["id"] == "2259")
    forms = [r["fst_input"] for r in rows]
    identity = batch_apply_down(bins[payload["roots"]["identity"]], forms)
    assert len(rows) == 394 and all(len(v) == 1 and v[0] != "+?" for v in identity)
    baseline = {r["row_id"]: r for r in csv.DictReader(baseline_path.open(), delimiter="\t")}
    delta = [{"row_id": r["id"], "before": baseline[r["id"]]["outputs"].split("|"),
              "after": values} for r, values in zip(rows, identity)
             if baseline[r["id"]]["outputs"].split("|") != values]
    assert not delta, delta
    result = {"tested_head": payload["head"], "toe": toe, "variants": {},
              "identity_corpus": {"accepted": len(rows),
                  "matched": sum(v == [r["counterpart"]] for r, v in zip(rows, identity)),
                  "output_delta_against_reviewed_candidate": delta}}
    for variant, order in payload["orders"].items():
        state = [toe["fst_input"]]
        trace = []
        for component in order:
            before = state
            state = batch_apply_down(bins[component], state)[0]
            assert len(state) == 1 and state[0] != "+?", (variant, component, state)
            trace.append({"stage": component, "before": before, "after": state})
        final = batch_apply_down(bins[payload["roots"][variant]], [toe["fst_input"]])[0]
        assert state == final, (variant, "component/full-composition disagreement")
        result["variants"][variant] = {"order": order, "trace": trace, "final": final}
    assert result["variants"]["identity"]["final"] == ["tā"]
    nightmare = next(v for r, v in zip(rows, identity) if r["id"] == "2141")
    assert nightmare == ["mære"]
    result["nightmare_identity_output"] = nightmare
    dump(output, result)


if __name__ == "__main__":
    if len(sys.argv) == 1:
        host()
    else:
        worker(Path(sys.argv[1]), sys.argv[2], Path(sys.argv[3]), Path(sys.argv[4]))
