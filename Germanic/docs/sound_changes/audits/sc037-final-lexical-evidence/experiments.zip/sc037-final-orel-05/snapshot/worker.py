import json
import sys
from pathlib import Path

sys.path.insert(0, "/usr/app/tools")
from anglo_frisian_experiments import compile_isolated
from sound_change_order_sensitivity import batch_apply_down

root, output = map(Path, sys.argv[1:3])
output.mkdir()
rows = json.loads((root / "candidates.json").read_text())
recipe = json.loads((root / "recipe.json").read_text())
suffix = json.loads((root / "suffix.json").read_text())
diagnostics = [stage["name"] for stage in suffix if stage["kind"] == "named"]
probes = [{"id": "before37", "stage": "OECompoundLinkingSyncope", "side": "before"}]
report = {"candidates": rows, "variants": {}}
for variant in ("adopted", "former"):
    directory = output / variant
    directory.mkdir()
    bins = compile_isolated(
        root / f"{variant}.txt", recipe, probes, directory,
        diagnostic_stages=diagnostics,
    )
    stage_bins = {name: bins[f"diagnostic:{i}"] for i, name in enumerate(diagnostics)}
    stage_bins.update({stage["name"]: bins[f"component:{stage['name']}"]
                       for stage in suffix if stage["kind"] == "inline"})
    forms = [row["fst_input"] for row in rows]
    parser = batch_apply_down(bins["component:EnglishProtoInput"], forms)
    canonical_final = batch_apply_down(bins["final"], forms)
    seeds = [row["hypothesis_seed"] for row in rows]
    records = []
    for row, parsed, initial in zip(rows, parser, [[s] for s in seeds]):
        assert not parsed, (row, parsed)
        current = initial
        changes = []
        immediate = None
        before37 = None
        for stage in suffix:
            if stage["name"] == "OECompoundLinkingSyncope":
                before37 = current
            results = batch_apply_down(stage_bins[stage["name"]], current)
            after = sorted({value for result in results for value in result})
            if stage["name"] == "OECompoundLinkingSyncope":
                immediate = after
            if after != current:
                changes.append({**stage, "before": current, "after": after})
            current = after
        records.append({
            "id": row["id"], "parser": parsed, "before37": before37,
            "after37": immediate, "changes": changes, "final": current,
            "path_status": "Explicit parser-bypassed conditional hypothesis; NOT canonical lexical validation",
        })
    assert canonical_final == [[], []]
    control = batch_apply_down(bins["component:EnglishProtoInput"], ["régna-bùgô"])
    assert control == [["*r*é*g*n*a*b*ù*g*ô"]]
    current = control[0]
    for stage in suffix:
        results = batch_apply_down(stage_bins[stage["name"]], current)
        current = sorted({value for result in results for value in result})
    assert current == sorted(batch_apply_down(bins["final"], ["régna-bùgô"])[0])
    report["canonical_positive_control"] = control
    report["variants"][variant] = records
assert [r["before37"] for r in report["variants"]["adopted"]] == [
    r["before37"] for r in report["variants"]["former"]
]
(output / "report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
print(json.dumps(report, ensure_ascii=False, indent=2))
