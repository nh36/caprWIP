"""Close the coordinated propagation using authentic owner/adopter receipts."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "Germanic/tools"))
from adjudication_run import Run

run = Run("SC001", ROOT / ".capr-work/runs/SC001")
state = run.state()
if run.frontier() != "PROPAGATE":
    raise ValueError("Only the existing active propagation may be completed")
revision = json.loads(
    (ROOT / ".capr-work/editorial-test-target-revision.json").read_text()
)
additions = []
for entry in revision["revisions"]:
    path = ROOT / entry["path"]
    if str(path) in state["propagation"]["before"]:
        continue
    original = subprocess.check_output(
        ["git", "show", f"HEAD:{entry['path']}"], cwd=ROOT
    )
    if hashlib.sha256(original).hexdigest() != entry["before"]:
        raise ValueError("Recorded pre-edit test hash does not match the committed ancestor")
    if hashlib.sha256(path.read_bytes()).hexdigest() != entry["after"]:
        raise ValueError("Reviewed test target changed")
    if state["propagation"]["targets"][str(path)] != entry["after"]:
        raise ValueError("Target revision is not pinned")
    state["propagation"]["before"][str(path)] = entry["before"]
    additions.append(entry)
if additions:
    run._event(
        "revision_hash_contract_completed",
        reason=(
            "The two pre-edit test hashes were preserved in the explicit amendment "
            "but not included in the propagation hash-map domain. Include only those "
            "verified original hashes; targets, scientific decisions and approvals "
            "are unchanged."
        ),
        additions=additions,
    )
    run._write_state(state)
receipts = []
for pattern in (
    "four-cells-SC114-actual-baseline-adoption-*.receipt.json",
    "four-cells-SC001-production-finalize-*.receipt.json",
    "four-cells-SC036-production-finalize-*.receipt.json",
    "four-cells-SC114-production-finalize-*.receipt.json",
):
    matches = list((ROOT / ".capr-work/command-logs").glob(pattern))
    if len(matches) != 1:
        raise ValueError(f"Expected one exact receipt: {pattern}")
    receipt = json.loads(matches[0].read_text())
    if receipt["returncode"] != 0:
        raise ValueError(f"Owner operation did not pass: {matches[0]}")
    receipts.append(receipt)
run.complete_stage(
    "PROPAGATE",
    note=(
        "Actual SC001 native/global proof and 1196 exact parser/production mappings "
        "passed; actual SC036 fires solely world and SC114 solely find/soul. The "
        "existing adopter certified 391/383/eight and conserved all earlier archives. "
        "All three current direct owner finalisations passed. Explicit annotation "
        "and regression amendments and the owner-verified generated sandbox effect "
        "are preserved without changing the original DECIDE."
    ),
    evidence={"receipts": receipts},
)
print("Coordinated protected-cell PROPAGATE complete; strict validation remains pending.")
