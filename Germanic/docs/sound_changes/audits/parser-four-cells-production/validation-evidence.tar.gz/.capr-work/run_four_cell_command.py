"""Record actual production operations with the existing receipt interface."""
import argparse
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "Germanic/tools"))
from adjudication_control import run_logged

parser = argparse.ArgumentParser()
parser.add_argument("--label", required=True)
parser.add_argument("--level")
parser.add_argument("--lane")
parser.add_argument("--cwd", type=Path, default=ROOT)
parser.add_argument("--timeout", type=float, default=7200)
parser.add_argument("argv", nargs=argparse.REMAINDER)
args = parser.parse_args()
argv = args.argv[1:] if args.argv[:1] == ["--"] else args.argv
if not argv:
    parser.error("an actual command is required")
receipt = run_logged(
    argv, label=args.label, log_dir=ROOT / ".capr-work/command-logs",
    cwd=args.cwd, timeout=args.timeout, level=args.level, lane=args.lane)
print(json.dumps({key: receipt.get(key) for key in
                 ("receipt_path", "returncode", "source_changed", "level", "lane")}))
for key in ("stdout_log", "stderr_log"):
    lines = Path(receipt[key]).read_text().splitlines()
    if lines:
        print(f"{key}: " + "\n".join(lines[-45:]))
sys.exit(receipt["returncode"] or 0)
