"""Record a five-attribute, non-scientific SOURCE target revision before edits."""
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "Germanic/tools"))
from adjudication_run import Run
from build_index_verborum import ALLOWED_FORM_ROLES
import artifact_graph

if "comparison_form" not in ALLOWED_FORM_ROLES or "intermediate_form" in ALLOWED_FORM_ROLES:
    raise ValueError("The expected canonical annotation vocabulary changed")
run = Run("SC001", ROOT / ".capr-work/runs/SC001")
state = run.state()
node = next(node for node in artifact_graph.nodes() if node.name == "oe_sandbox")
sandbox = ROOT / "Germanic/fsts/old_english_sandbox.txt"
if sandbox in node.outputs() and not node.verify():
    # The shared executable dependency domain includes this GENERATED file.
    # The existing source-delta check admits it, but the hash-delta check
    # requires an explicit pinned effect. Pin only the owner's verified bytes;
    # never hand-edit the sandbox or expand ordinary SOURCE permissions.
    digest = hashlib.sha256(sandbox.read_bytes()).hexdigest()
    effect = dict(path=str(sandbox), owner=node.authority,
                  before=state["propagation"]["before"][str(sandbox)], after=digest)
    state["propagation"]["targets"][str(sandbox)] = digest
    state["propagation"].setdefault("verified_generated_effects", []).append(effect)
    run._event("verified_generated_effect_pinned", **effect)
else:
    raise ValueError("The sandbox is not a fresh, graph-owned generated artifact")
if run.frontier() != "PROPAGATE" or not run._sanctioned_changes(state):
    raise ValueError("Only an active, otherwise sanctioned propagation can revise annotations")
paths = [
    "Germanic/docs/lexeme_reports/model_entries/2011-find-fundene.model.md",
    "Germanic/docs/lexeme_reports/model_entries/2053-hammer-hameres.model.md",
    "Germanic/docs/lexeme_reports/model_entries/2201-soul-sāwle.model.md",
]
revisions = []
contents = {}
for relative in paths:
    path = ROOT / relative
    before = path.read_bytes()
    after = (ROOT / ".capr-work/source-plan" / relative).read_bytes()
    old = hashlib.sha256(before).hexdigest()
    new = hashlib.sha256(after).hexdigest()
    if state["propagation"]["targets"][str(path)] != old:
        raise ValueError("Current SOURCE differs from its initially authorised target")
    if after != before.replace(b"role=intermediate_form", b"role=comparison_form"):
        raise ValueError("Revision changes more than the five unsupported role annotations")
    revisions.append(dict(path=relative, before=old, after=new))
    contents[path] = after
revision = dict(
    reason="Use the existing comparison_form index role for five reconstructed intermediate comparison forms. No prose, linguistic interpretation, selected cell, stage, FST, corpus, proof, formal gate or protected approval changes.",
    revisions=revisions,
)
(ROOT / ".capr-work/index-annotation-target-revision.json").write_text(
    json.dumps(revision, indent=2))
# Preserve the completed DECIDE record verbatim. Append this explicit
# annotation-only amendment to propagation, with new hashes pinned before edits.
run._event("propagation_source_annotation_revision", **revision)
state["propagation"].setdefault("source_target_revisions", []).append(revision)
for path, after in contents.items():
    state["propagation"]["targets"][str(path)] = hashlib.sha256(after).hexdigest()
run._write_state(state)
for path, after in contents.items():
    path.write_bytes(after)
print("Five index attributes corrected through an explicitly recorded, pre-edit target revision; the original DECIDE and all scientific/protected targets are unchanged.")
