"""Extract and render the actual final publications for direct page inspection."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import unicodedata

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / ".capr-work/publication-inspection-final"
OUT.mkdir(exist_ok=True)
publications = {
    "combined": ("Germanic/docs/assembly/capr_book_draft_alpha_01.pdf",
                 [72, 73, 74, 92, 93, 172, 173, 189, 206, 207, 263, 264,
                  314, 315, 316, 317, 318, 319, 320]),
    "lexical": ("Germanic/docs/assembly/lexical_volume_alpha_01.pdf",
                [47, 60, 75, 126, 127]),
    "reader": ("Germanic/docs/sound_changes/reader_facing/reader_facing_local_section_20.pdf",
               [68, 70, 88, 89]),
    "intro": ("Germanic/docs/assembly/capr_book_intro_alpha_01.pdf", [2]),
}
terms = ["hammer — OE", "find — OE", "soul — OE", "west — OE",
         "OENonHighSyn", "OEInterStressRaising", "Index verborum"]
inventory = {}
for name, (relative, selected) in publications.items():
    path = ROOT / relative
    info = subprocess.check_output(["pdfinfo", str(path)], text=True)
    pages = int(re.search(r"^Pages:\s+(\d+)", info, re.M).group(1))
    textpath = OUT / f"{name}.txt"
    subprocess.run(["pdftotext", "-layout", str(path), str(textpath)], check=True)
    text = unicodedata.normalize("NFC", textpath.read_text())
    sheets = text.split("\f")
    hits = {term: [i for i, sheet in enumerate(sheets, 1) if term in sheet]
            for term in terms}
    for number in selected:
        if number > pages:
            raise ValueError(f"Page inventory changed: {name} {number} > {pages}")
        subprocess.run(
            ["pdftoppm", "-f", str(number), "-l", str(number), "-singlefile",
             "-scale-to", "1500", "-png", str(path), str(OUT / f"{name}-{number}")],
            stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, check=True,
        )
    inventory[name] = {
        "path": relative, "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
        "pages": pages, "hits": hits, "rendered_sheets": selected,
        "text_sha256": hashlib.sha256(textpath.read_bytes()).hexdigest(),
    }
(OUT / "pdf-inventory.json").write_text(
    json.dumps(inventory, indent=2, ensure_ascii=False) + "\n"
)
print(json.dumps(inventory, indent=2, ensure_ascii=False))
