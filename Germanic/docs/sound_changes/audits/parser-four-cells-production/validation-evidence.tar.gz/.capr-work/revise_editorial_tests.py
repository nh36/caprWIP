"""Pin reviewed, directly coupled test updates before changing actual SOURCE."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "Germanic/tools"))
from adjudication_run import Run

run = Run("SC001", ROOT / ".capr-work/runs/SC001")
state = run.state()
if run.frontier() != "PROPAGATE" or not run._sanctioned_changes(state):
    raise ValueError("Propagation is not active and otherwise sanctioned")
paths = [
    "Germanic/tests/test_pgmc_lexical_integration.py",
    "Germanic/tests/test_lexical_editorial_publication.py",
]
contents = {}
revisions = []
for relative in paths:
    path = ROOT / relative
    before = path.read_bytes()
    committed = subprocess.check_output(
        ["git", "show", f"HEAD:{relative}"], cwd=ROOT
    )
    if before != committed:
        raise ValueError(f"Unreviewed existing edits in {relative}")
    after = (ROOT / ".capr-work/source-plan" / relative).read_bytes()
    if before == after:
        raise ValueError(f"No correction in {relative}")
    revisions.append(dict(
        path=relative,
        before=hashlib.sha256(before).hexdigest(),
        after=hashlib.sha256(after).hexdigest(),
    ))
    contents[path] = after
revision = dict(
    reason=(
        "Update only the independently measured four-cell editorial populations, "
        "explicit authorised find/hammer preservation transitions, and new soul/west "
        "publication expectations; reuse the existing Roman-page citation recogniser. "
        "All 39 isolated tests passed using fresh actual graph-owned artifacts and "
        "the existing protected-cell adopter. No scientific SOURCE, FST, corpus, "
        "parser mapping, protected target or completed DECIDE changes."
    ),
    revisions=revisions,
)
(ROOT / ".capr-work/editorial-test-target-revision.json").write_text(
    json.dumps(revision, indent=2) + "\n"
)
run._event("propagation_source_regression_revision", **revision)
state["propagation"].setdefault("source_target_revisions", []).append(revision)
for path, after in contents.items():
    state["propagation"]["targets"][str(path)] = hashlib.sha256(after).hexdigest()
run._write_state(state)
for path, after in contents.items():
    path.write_bytes(after)
print("Two reviewed regression files updated; original DECIDE and protected targets preserved.")
