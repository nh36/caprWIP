"""Renew only invalidated propagation after final publication annotation changes."""
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "Germanic/tools"))
from adjudication_run import Run

run = Run("SC001", ROOT / ".capr-work/runs/SC001")
if run.frontier() != "PROPAGATE":
    raise ValueError("Only the explicitly invalidated propagation may be renewed")
receipts = []
for label in (
    "four-cells-SC114-actual-baseline-adoption",
    "four-cells-SC001-final02-finalize",
    "four-cells-SC036-final02-finalize",
    "four-cells-SC114-final02-finalize",
):
    matches = list((ROOT / ".capr-work/command-logs").glob(f"{label}-*.receipt.json"))
    if len(matches) != 1:
        raise ValueError(f"Expected one receipt for {label}")
    receipts.append(json.loads(matches[0].read_text()))
run.complete_stage(
    "PROPAGATE",
    note=(
        "Renewed after bounded current-state/historical-state test corrections "
        "and completion of the source stage-audit synchronization, in addition "
        "to the preserved publication annotation amendments. Final actual "
        "publication passes and direct current-SOURCE owner finalisations pass. "
        "The original DECIDE, protected adoption receipt, old completion and "
        "all protected bytes remain preserved; no baseline was re-adopted."
    ),
    evidence={"receipts": receipts},
)
print("Final-publication PROPAGATE renewed; final strict validation remains required.")
