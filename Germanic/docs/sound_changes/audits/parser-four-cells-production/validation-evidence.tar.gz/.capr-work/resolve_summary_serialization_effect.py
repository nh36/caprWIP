"""Account for the existing adopter's JSON-order-only byte effect."""
import hashlib
import json
from pathlib import Path
import shutil
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "Germanic/tools"))
import artifact_graph
import cascade_baseline as baseline
from adjudication_run import Run

run = Run("SC001", ROOT / ".capr-work/runs/SC001")
state = run.state()
if run.frontier() != "PROPAGATE" or not run._sanctioned_changes(state):
    raise ValueError("Only the otherwise sanctioned existing propagation may be reconciled")
transition = state["stages"]["DECIDE"]["evidence"]["cell_transition"]
base = artifact_graph.BASELINE_DIR
actual = baseline.read_baseline(
    base / "cascade_baseline_outputs.tsv", base / "cascade_baseline_summary.json"
)
if actual != transition["candidate"]:
    raise ValueError("Actual adopted scientific records or summary differ from DECIDE")
approval = transition["approval"]
suffix = approval["adjudication"].lower() + "_" + approval["transition_id"]
summary_path = base / "cascade_baseline_summary.json"
planned_hash = state["propagation"]["targets"][str(summary_path)]
actual_hash = hashlib.sha256(summary_path.read_bytes()).hexdigest()
if planned_hash == actual_hash:
    raise ValueError("No unaccounted serialization effect")
with tempfile.TemporaryDirectory(prefix="capr_summary_effect_") as temporary:
    for label, candidate in (("frozen", transition["candidate"]), ("live", actual)):
        isolated = Path(temporary) / label
        isolated.mkdir()
        for kind, extension in (("outputs", "tsv"), ("summary", "json")):
            shutil.copyfile(
                base / f"cascade_baseline_{kind}_pre_{suffix}.{extension}",
                isolated / f"cascade_baseline_{kind}.{extension}",
            )
        for name in ("cascade_baseline_outputs_legacy380.tsv", "approved_input_migrations.tsv"):
            shutil.copyfile(base / name, isolated / name)
        baseline.adopt_cell_baseline(candidate, isolated, approval)
        data = (isolated / summary_path.name).read_bytes()
        expected = planned_hash if label == "frozen" else actual_hash
        if hashlib.sha256(data).hexdigest() != expected:
            raise ValueError("Existing shared adopter does not reproduce the precise byte effect")
        if json.loads(data) != transition["candidate"]["summary"]:
            raise ValueError("Scientific summary changed")
        for name in (
            "cascade_baseline_outputs.tsv",
            f"cascade_baseline_outputs_pre_{suffix}.tsv",
            f"cascade_baseline_summary_pre_{suffix}.json",
        ):
            if (isolated / name).read_bytes() != (base / name).read_bytes():
                raise ValueError(f"An effect other than summary JSON ordering occurred: {name}")
effect = dict(
    path=str(summary_path),
    before=planned_hash,
    after=actual_hash,
    reason=(
        "The frozen DECIDE JSON sorts dictionary keys, whereas the fresh actual "
        "evaluator constructs its summary in field order. The existing adopter's "
        "writer preserves insertion order. Independent shared-interface rehearsals "
        "reproduce both exact hashes; every record, summary value, approval and "
        "pre-transition archive is identical. Pin the actual approved adopter bytes "
        "without editing any protected file or original DECIDE. Canonical future "
        "serialization will be fixed separately."
    ),
)
(ROOT / ".capr-work/summary-serialization-target-revision.json").write_text(
    json.dumps(effect, indent=2) + "\n"
)
run._event("protected_adopter_serialization_effect_verified", **effect)
state["propagation"].setdefault("verified_serialization_effects", []).append(effect)
state["propagation"]["targets"][str(summary_path)] = actual_hash
run._write_state(state)
print("Approved adopter's JSON-order-only effect verified and recorded; protected bytes untouched.")
