"""Archive exact operational records, without PDFs, binaries or overwrites."""
import argparse
import hashlib
import io
import json
from pathlib import Path
import tarfile

ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument("output", type=Path)
args = parser.parse_args()
output = args.output.resolve()
manifest_path = output.with_suffix("").with_suffix(".manifest.json")
if output.exists() or manifest_path.exists():
    raise ValueError("Evidence packages are immutable; choose a new phase filename")
files = set()
for relative in (
    ".capr-work/actual-production-parser-certification",
    ".capr-work/runs/SC001",
    ".capr-work/publication-inspection-final",
):
    files.update(p for p in (ROOT / relative).rglob("*") if p.is_file())
for pattern in (
    ".capr-work/command-logs/four-cells-*",
    ".capr-work/*target-revision.json",
    ".capr-work/production-parser-export-*.json",
    ".capr-work/production-four-cell-complete-derivations.json",
    ".capr-work/four-cell-decision.json",
    ".capr-work/four-cell-source.patch",
    ".capr-work/focused-selector-correction.json",
    ".capr-work/complete_four_cell_propagation.py",
    ".capr-work/resolve_summary_serialization_effect.py",
    ".capr-work/certify_actual_production_parser.py",
    ".capr-work/start_four_cell_propagation.py",
    ".capr-work/revise_index_annotations.py",
    ".capr-work/revise_editorial_tests.py",
    ".capr-work/run_four_cell_command.py",
    ".capr-work/package_four_cell_evidence.py",
    ".capr-work/reconcile_publication_targets.py",
    ".capr-work/renew_publication_propagation.py",
    ".capr-work/inspect_final_publication.py",
    ".capr-work/complete_final_validation.py",
    ".capr-work/post-propagation-publication-state.json",
    ".capr-work/strict-correction-plan.json",
    ".capr-work/final-journal-closeout-diagnostic.json",
):
    files.update(p for p in ROOT.glob(pattern) if p.is_file())
if any(p.suffix in {".pdf", ".bin"} or p.is_symlink() for p in files):
    raise ValueError("Excluded holdings, runtime binaries or links entered the package")
members = {}
output.parent.mkdir(parents=True, exist_ok=True)
with tarfile.open(output, "w:gz") as archive:
    for path in sorted(files):
        data = path.read_bytes()
        name = str(path.relative_to(ROOT))
        members[name] = dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
        info = tarfile.TarInfo(name)
        info.size = len(data)
        info.mode = 0o644
        archive.addfile(info, io.BytesIO(data))
with tarfile.open(output, "r:gz") as archive:
    if set(archive.getnames()) != set(members):
        raise ValueError("Incomplete archive")
    for name, expected in members.items():
        data = archive.extractfile(name).read()
        if len(data) != expected["bytes"] or hashlib.sha256(data).hexdigest() != expected["sha256"]:
            raise ValueError(f"Archive corruption: {name}")
manifest = dict(
    archive=output.name,
    archive_sha256=hashlib.sha256(output.read_bytes()).hexdigest(),
    tested_source=json.loads(
        (ROOT / ".capr-work/runs/SC001/state.json").read_text()
    )["stages"].get("VALIDATE", {}).get("source_identity"),
    members=members,
)
manifest_path.write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n")
print(json.dumps(dict(archive=str(output), members=len(members),
                      sha256=manifest["archive_sha256"])))
