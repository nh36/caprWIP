"""Preserve and explicitly reconcile the bounded post-adoption publication edits."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "Germanic/tools"))
from adjudication_run import Run

run = Run("SC001", ROOT / ".capr-work/runs/SC001")
state = run.state()
archive = ROOT / ".capr-work/post-propagation-publication-state.json"
if archive.exists():
    raise ValueError("The original post-propagation checkpoint must not be overwritten")
archive.write_text(json.dumps(state, indent=2, ensure_ascii=False) + "\n")
decision = json.dumps(state["stages"]["DECIDE"], sort_keys=True)
paths = [
    "Germanic/docs/lexeme_reports/model_entries/2011-find-fundene.model.md",
    "Germanic/docs/lexeme_reports/model_entries/2201-soul-sāwle.model.md",
    "Germanic/tests/test_lexical_editorial_publication.py",
]
changes = []
for relative in paths:
    path = ROOT / relative
    before = subprocess.check_output(["git", "show", f"aedb54eb:{relative}"], cwd=ROOT)
    after = path.read_bytes()
    before_sha = hashlib.sha256(before).hexdigest()
    after_sha = hashlib.sha256(after).hexdigest()
    if state["propagation"]["targets"][str(path)] != before_sha:
        raise ValueError(f"The preserved propagated target differs: {relative}")
    if relative.endswith(".model.md"):
        normalise = lambda b: re.sub(rb"sort=[A-Za-z0-9_-]+", b"sort=KEY", b)
        if normalise(before) != normalise(after):
            raise ValueError("Only explicit index sort values may differ in the articles")
    else:
        method = (
            b"    def test_selected_find_and_soul_have_one_printed_entry_with_all_sites(self):\n"
            b'        path = ROOT / "Germanic/docs/book/index_verborum_book_print_unique.tsv"\n'
            b"        with path.open() as handle:\n"
            b'            rows = list(csv.DictReader(handle, delimiter="\\t"))\n'
            + '        for display in ("*fúnðanai", "*sáiwalǭ"):\n'.encode()
            + b"            with self.subTest(display=display):\n"
            b'                selected = [r for r in rows if r["language"] == "pgmc"\n'
            b'                            and r["display"] == display and not r["printed_variety"]]\n'
            b"                self.assertEqual(len(selected), 1)\n"
            b'                self.assertGreaterEqual(int(selected[0]["occurrence_count"]), 3)\n\n'
        )
        if after.count(method) != 1 or after.replace(method, b"") != before:
            raise ValueError("Only the exact printed-identity regression may be added")
    changes.append({"path": relative, "before": before_sha, "after": after_sha})

run._event(
    "post_propagation_publication_target_revision",
    reason=(
        "Actual rendered index inspection exposed duplicate canonical entries. "
        "Git and the immutable propagation archive preserve the original targets "
        "and completion. Two articles change only seven explicit sort attributes; "
        "the third target adds only the exact printed-identity/site-conservation "
        "regression. No prose, form, role, stage, corpus, FST, approved baseline "
        "or scientific DECIDE changes. Renew propagation completion through fresh "
        "direct finalisation receipts; do not re-adopt protected outputs."
    ),
    original_completion=state["stages"]["PROPAGATE"],
    preserved_state=str(archive),
    preserved_state_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),
    revisions=changes,
)
for change in changes:
    state["propagation"]["targets"][str(ROOT / change["path"])] = change["after"]
if json.dumps(state["stages"]["DECIDE"], sort_keys=True) != decision:
    raise ValueError("The scientific decision must remain unchanged")
run._write_state(state)
invalidated = run.refresh_validity()
if invalidated != ["PROPAGATE"] or run.frontier() != "PROPAGATE":
    raise ValueError(f"Unexpected invalidation: {invalidated}; frontier {run.frontier()}")
(ROOT / ".capr-work/publication-target-revision.json").write_text(
    json.dumps({"original_commit": "aedb54eb", "revisions": changes},
               indent=2, ensure_ascii=False) + "\n"
)
print("Three bounded publication targets reconciled; fresh owner finalisation required.")
