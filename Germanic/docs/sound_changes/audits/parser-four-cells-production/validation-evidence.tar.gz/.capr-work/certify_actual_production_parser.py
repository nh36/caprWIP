"""Export and certify the actual adopted parser; replay the frozen1196 inputs."""
import gzip
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import uuid

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "Germanic/docs/sound_changes/audits/parser-formal-resolution"))
import alignment
import canonical_experiment
import functionality

RESULTS = ROOT / ".capr-work/experiments/parser-four-cells-certified-candidate-06/results"
expected = json.loads(gzip.decompress((RESULTS / "integration-results.json.gz").read_bytes()))
output = ROOT / ".capr-work/actual-production-parser-certification"
if output.exists():
    raise ValueError("Preserve previous certifications; do not overwrite an output directory")
remote = "/tmp/capr-actual-parser-" + uuid.uuid4().hex
worker = r'''
import hashlib,json,subprocess,sys,tempfile
from pathlib import Path
sys.path.insert(0,"/usr/app/tools")
from capr_runtime import layout,check_build_manifest
import oe_pipeline
payload=json.load(sys.stdin);out=Path(payload["output"]);out.mkdir()
rt=layout()
errors=check_build_manifest(oe_pipeline.expected_snapshot_bins()+["old_english.bin"],rt)
if errors:raise ValueError("; ".join(errors))
source=Path("/usr/app/fsts/germanic.txt");production=rt.bin_dir/"old_english.bin"
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=dict(fst_sha256=sha(source),production_bin_before=sha(production))
(out/"actual-germanic.txt").write_bytes(source.read_bytes())
with tempfile.TemporaryDirectory(prefix="capr_actual_parser_compile_") as tmp:
 directory=Path(tmp);(directory/"germanic.txt").write_bytes(source.read_bytes())
 commands=["source germanic.txt"]
 for name in ["EnglishProtoInput","PGCellInput"]:
  commands += ["clear stack","regex "+name+";","save stack "+name+".bin"]
 commands+=["quit"]
 argv=["foma","-q"]
 for command in commands:argv+=["-e",command]
 compiled=subprocess.run(argv,cwd=directory,text=True,capture_output=True,timeout=1200)
 (out/"compile.stdout").write_text(compiled.stdout);(out/"compile.stderr").write_text(compiled.stderr)
 if compiled.returncode:raise RuntimeError("Actual-source compilation failed: "+compiled.stderr)
 checks={}
 for name in ["EnglishProtoInput","PGCellInput","OldEnglish"]:
  path=production if name=="OldEnglish" else directory/(name+".bin")
  commands=["load stack "+str(path),"test functional"]
  if name!="OldEnglish":commands+=["test unambiguous"]
  if name!="OldEnglish":commands+=["write att > "+str(out/(name+".att"))]
  argv=["foma","-q"]
  for command in commands+["quit"]:argv+=["-e",command]
  result=subprocess.run(argv,text=True,capture_output=True,check=True,timeout=180)
  checks[name]=dict(stdout=result.stdout,stderr=result.stderr)
 (out/"native.json").write_text(json.dumps(checks,indent=2))
 inputs=payload["inputs"]
 if any("\n" in item or "\r" in item for item in inputs):raise ValueError("Invalid assay input")
 for name,path in [("parser",directory/"EnglishProtoInput.bin"),("production",production)]:
  result=subprocess.run(["flookup","-i","-x",str(path)],input="\n".join(inputs)+"\n",
    text=True,capture_output=True,check=True,timeout=600)
  (out/(name+".lookup")).write_text(result.stdout)
  blocks=result.stdout.split("\n\n")
  if blocks and not blocks[-1].strip():blocks.pop()
  values=[sorted(set(line for line in block.splitlines() if line and line!="+?")) for block in blocks]
  if len(values)!=len(inputs):raise ValueError("Lookup result count differs")
  (out/(name+"-outputs.json")).write_text(json.dumps(values,ensure_ascii=False))
manifest["production_bin_after"]=sha(production)
if manifest["production_bin_before"]!=manifest["production_bin_after"]:raise ValueError("Production bin changed during replay")
manifest["fst_sha256_after"]=sha(source)
if manifest["fst_sha256"]!=manifest["fst_sha256_after"]:raise ValueError("Canonical source changed during replay")
(out/"provenance.json").write_text(json.dumps(manifest,indent=2))
print(json.dumps(dict(output=str(out),provenance=manifest)))
'''
result = subprocess.run(
    ["docker", "compose", "exec", "-T", "backend", "python3", "-c", worker],
    input=json.dumps(dict(output=remote, inputs=expected["input_order"]), ensure_ascii=False),
    text=True, capture_output=True, timeout=1800)
(ROOT / (".capr-work/production-parser-export-" + remote.rsplit("-", 1)[1] + ".json")).write_text(
    json.dumps(dict(remote_output=remote, returncode=result.returncode,
                    stdout=result.stdout, stderr=result.stderr), indent=2))
if result.returncode:
    print(result.stderr, file=sys.stderr)
    raise SystemExit(result.returncode)
print(result.stdout.strip(), flush=True)
container = subprocess.check_output(
    ["docker", "compose", "ps", "-q", "backend"], text=True).strip()
subprocess.run(["docker", "cp", container + ":" + remote, str(output)], check=True)
subprocess.run(
    ["docker", "compose", "exec", "-T", "backend", "python3", "-c",
     "from pathlib import Path;import shutil,sys;p=Path(sys.argv[1]);"
     "assert p.parent==Path('/tmp') and p.name.startswith('capr-actual-parser-');shutil.rmtree(p)",
     remote], check=True)

provenance = json.loads((output / "provenance.json").read_text())
if provenance["fst_sha256"] != hashlib.sha256((ROOT / "Germanic/fsts/germanic.txt").read_bytes()).hexdigest():
    raise ValueError("Actual source provenance mismatch")
checks = json.loads((output / "native.json").read_text())
for name in ("EnglishProtoInput", "PGCellInput"):
    text = (output / (name + ".att")).read_text()
    proof = functionality.analyze(text)
    functionality.verify(text, proof)
    (output / (name + "-global-proof.json")).write_text(json.dumps(proof))
    if not proof["functional"] or not checks[name]["stdout"].startswith("1 "):
        raise ValueError("Actual production parser did not pass: " + name)

actual = (output / "EnglishProtoInput.att").read_text()
reference = (RESULTS / "EnglishProtoInput.att").read_text()
union = canonical_experiment.relation_union(reference, actual)
proof = functionality.analyze(union)
functionality.verify(union, proof)
domain = alignment.domain_check([reference, actual], lambda values: values[0] == values[1])
if not proof["functional"] or not domain["valid"]:
    raise ValueError("Actual parser differs from the globally certified relation")
(output / "actual-candidate-equivalence.att").write_text(union)
(output / "actual-candidate-equivalence-proof.json").write_text(json.dumps(proof))
(output / "actual-candidate-domain-equivalence.json").write_text(json.dumps(domain))

normalise = lambda values: [sorted(set(value for value in row if value and value != "+?"))
                            for row in values]
for name, key in [("parser", "parsed"), ("production", "final")]:
    values = json.loads((output / (name + "-outputs.json")).read_text())
    reference_values = normalise(expected[key])
    differences = [dict(index=i, input=expected["input_order"][i], expected=b, actual=a)
                   for i, (a, b) in enumerate(zip(values, reference_values)) if a != b]
    (output / (name + "-candidate-differences.json")).write_text(
        json.dumps(differences, ensure_ascii=False, indent=2))
    if differences:
        raise ValueError("Fresh actual replay differs from the certified candidate: " + name)
print("Actual native/global parser gate, exact relation equivalence and all1196 fresh production/internal mappings pass.")
print("Complete OldEnglish native diagnostic (independent full-domain question remains unresolved):", checks["OldEnglish"]["stdout"].strip())
