"""Close the current-source journal only with authentic final A/B/C receipts."""
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "Germanic/tools"))
from adjudication_run import Run, record_validation_level

run = Run("SC001", ROOT / ".capr-work/runs/SC001")
labels = (
    "four-cells-final02-level-A",
    "four-cells-final02-level-B-refresh",
    "four-cells-final02-level-B-status",
    "four-cells-final02-level-C-serial",
    "four-cells-final02-level-C-exclusive",
)
receipts = []
for label in labels:
    matches = list((ROOT / ".capr-work/command-logs").glob(f"{label}-*.receipt.json"))
    if len(matches) != 1:
        raise ValueError(f"Expected exactly one final receipt: {label}")
    receipt = json.loads(matches[0].read_text())
    if receipt["returncode"] != 0:
        raise ValueError(f"Final command did not pass: {label}")
    receipts.append(receipt)
for level in ("A", "B", "C"):
    record_validation_level(run, level, [r for r in receipts if r["level"] == level])
run.complete_stage(
    "VALIDATE",
    note=(
        "Final current-SOURCE semantic A, clean integrated refresh/status B, "
        "full strict serial C with explicit historical-replay skips, then "
        "exclusive fresh-runtime C all passed. Actual final publication "
        "page images, index identities and retained sites were inspected."
    ),
    evidence={"receipts": receipts},
)
run.complete_stage(
    "COMPLETE",
    note=(
        "Certified four-cell adoption and parser formal gate. Full-cascade "
        "global functionality/totality remains a separate unresolved task. "
        "Final evidence-only archival commits do not retrospectively change "
        "the recorded tested scientific/publication commit."
    ),
)
print(json.dumps({
    "frontier": run.frontier(),
    "completed": [
        name for name, stage in run.state()["stages"].items()
        if stage.get("completed_at")
    ],
}, sort_keys=True))
