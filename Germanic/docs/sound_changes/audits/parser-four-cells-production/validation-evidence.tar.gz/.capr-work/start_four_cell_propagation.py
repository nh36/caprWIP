"""Freeze the reviewed SOURCE proposal, record DECIDE, then propagate it."""
import gzip
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "Germanic/tools"))
from adjudication_run import Run, _cell_transition_files
import artifact_graph

sys.path.insert(0, str(ROOT / "Germanic/docs/sound_changes/audits/parser-formal-resolution"))
import functionality

proposal = ROOT / ".capr-work/source-plan"
results = ROOT / ".capr-work/experiments/parser-four-cells-certified-candidate-06/results"
for name in ("EnglishProtoInput", "PGCellInput"):
    proof = json.loads((results / (name + "-proof.json")).read_text())
    functionality.verify((results / (name + ".att")).read_text(), proof)
gate = json.loads((results / "parser-gate.json").read_text())
if (not gate["same_outputs"] or not gate["same_domain"]["valid"]
        or any(not gate[name]["independent"] or not gate[name]["stdout"].startswith("1 ")
               for name in ("EnglishProtoInput", "PGCellInput"))):
    raise ValueError("Actual parser formal gate is not certified")
measured = json.loads(gzip.decompress((results / "integration-results.json.gz").read_bytes()))
if not measured["canonical_unchanged"] or not measured["frozen_K_equal"]:
    raise ValueError("Protected candidate or frozen K did not pass")
for source, target in [
    ("candidatefst.txt", "Germanic/fsts/germanic.txt"),
    ("candidatecorpus.tsv", "Germanic/data/germanic-aligned-final.tsv"),
]:
    if (results / source).read_bytes() != (proposal / target).read_bytes():
        raise ValueError("The SOURCE proposal changed the certified artifact: " + target)

subprocess.run(["git", "-C", str(proposal), "diff", "--check"], check=True)
subprocess.run(["git", "-C", str(proposal), "add", "--all"], check=True)
names = subprocess.check_output(
    ["git", "-C", str(proposal), "diff", "--cached", "--name-only", "-z"]
).decode().split("\0")
hashes = {name: hashlib.sha256((proposal / name).read_bytes()).hexdigest()
          for name in names if name}
generated = {path.resolve() for node in artifact_graph.nodes() for path in node.outputs()}
for name in hashes:
    if artifact_graph.propagation_path_kind(ROOT / name, generated=generated) != "SOURCE":
        raise ValueError("Undeclared ordinary SOURCE: " + name)

transition = dict(
    approval_filename="approved_nonhigh_cells_migration.json",
    approval=measured["approval"], candidate=measured["candidate_baseline"],
    migrations=measured["migrations"],
)
protected = _cell_transition_files(transition, artifact_graph.BASELINE_DIR)
decision = dict(
    verdict="REFORMULATE",
    coordinated_adjudications=["SC001", "SC036", "SC114"],
    historical_phenomenon="SC001 is technical canonical input, not historical change; coordinated SC114 implements the already source-supported bounded open-posttonic nonhigh syncope, while SC036 retires only its provisional soul proxy.",
    conditioning="SC114: plain short a/ae/e in an open posttonic syllable before a final heavy syllable after a positively identified primary root, light or heavy. Existing one-pretonic FootCtx limit; no lexical or grammatical sound-law conditioning.",
    executable_implementation="Exact certified candidate06 FST, independently equivalent to frozen K; actual EnglishProtoInput and PGCellInput native functional/unambiguous and independently globally certified. Whole parser retains the direct canonical union; helper retains the equivalent star-erasure factorisation.",
    selected_input_assumptions=[
        "2011 strong masculine nominative plural *fúnðanai > fundne",
        "2053 citation masculine nominative singular *xámaraz > hamer",
        "2201 feminine o-stem accusative singular *sáiwalǭ > sāwle",
        "2282 inherited neuter base used adverbially *wéstą > west",
        "Preserve every unique inherited parser mapping; genuinely ambiguous bare spellings require user-approved explicit stress; no word-specific allowlist.",
    ],
    firing_census="Complete candidate391 SC114 census: find2011 and soul2201 only. Retained SC036 weak-LH raising: world2302 only. Complete parser799-input mappings, selected391 and original380 are recorded in the verified manifested experiment.",
    positive_witnesses=[
        "find: *f*ú*n*d*a*n*ē -> *f*ú*n*d*n*ē -> fundne",
        "soul: *s*ā*w*a*l*ǭ -> *s*ā*w*l*ǭ -> sāwle",
        "*þéudanas > þēodnes; *fágenas > fæġnes; *gōdanǭ > gōdne; *blíndanǭ > blindne",
    ],
    negative_controls=[
        dict(description="Actual native and independent global parser gate, including epsilon alignment and productive cycles", passed=True),
        dict(description="All799 frozen K internal mappings conserved; every uniquely interpreted native-domain mapping conserved", passed=True),
        dict(description="Hammer citation and west are SC114 nonapplications; world, earthly, rainbow stage traces unchanged", passed=True),
        dict(description="Malformed controls rejected; retained high-vowel witnesses and eight standing mismatches conserved", passed=True),
        dict(description="Protected candidate source hashes unchanged; no fifth original380 final change", passed=True),
    ],
    counterfactual_results="Original380 only: find fundene->fundne, hammer hameres->hamres, soul sāwol->sāwel, west westene->westne. Full unsuccessful fundan/fynden/fundenne and wider high-vowel probes remain explicitly qualified, not claimed attestations.",
    literature_support="Preserved lexical reassessment and three soul dossiers; HoggGrammar1992 pp220-222 §§6.14-18, Luick1914 pp279-280 §303, Fulk2010 pp133-139, Fulk2018 pp146/209/284; verified Strunk1904 pp15/82, WrightWuelcker1884 I258/272.36, Skeat1874 p130, Toller1921 pp219/505 and west entry, Orel2003 pp158/459.",
    historical_vs_modelling="Historical OE stage and English scope are independently source-led. Following-final weight, inherited quantity-carrier lifetime and immediate pre-SC063 placement are bounded model commitments, not newly demonstrated historical edges. SC001 has no historical stage/scope/confidence.",
    unresolved=[
        dict(description="Independent full-cascade global functionality and totality failure", acknowledged_in="Germanic/docs/sound_changes/audits/sc001-adjudication.md#residue"),
        dict(description="Four wider paradigms, source-attested variants and early high-vowel retention gaps", acknowledged_in="Germanic/docs/sound_changes/audits/sc114-adjudication.md#residue"),
        dict(description="Broader lexical well-formedness and unrestricted multiprefix/light-final prosody", acknowledged_in="Germanic/docs/sound_changes/audits/sc001-adjudication.md#residue"),
    ],
    intended_source_modifications=hashes,
    cell_transition=transition,
)
(ROOT / ".capr-work/four-cell-decision.json").write_text(
    json.dumps(decision, ensure_ascii=False, indent=2))
patch = ROOT / ".capr-work/four-cell-source.patch"
patch.write_bytes(subprocess.check_output(
    ["git", "-C", str(proposal), "diff", "--cached", "--binary"]))
subprocess.run(["git", "apply", "--check", str(patch)], cwd=ROOT, check=True)
run = Run("SC001", ROOT / ".capr-work/runs/SC001")
print(run.report(), flush=True)
run.complete_stage("DECIDE", note="Explicit user-authorised coordinated adoption after unchanged native and independent global parser gates pass; exact SOURCE targets and six protected effects reviewed.", evidence=decision)
run.begin_propagation(hashes)
subprocess.run(["git", "apply", str(patch)], cwd=ROOT, check=True)
for name, digest in hashes.items():
    if hashlib.sha256((ROOT / name).read_bytes()).hexdigest() != digest:
        raise ValueError("Applied SOURCE does not match authorised hash: " + name)
for path, data in protected.items():
    if path.name in {"approved_nonhigh_cells_migration.json", "approved_input_migrations.tsv"}:
        path.write_bytes(data)
print("Authorised ordinary SOURCE propagated. Exact approval and migration inputs staged.")
print("Protected baseline outputs are NOT written: use the actual SC114 adopter after fresh production evidence.")
