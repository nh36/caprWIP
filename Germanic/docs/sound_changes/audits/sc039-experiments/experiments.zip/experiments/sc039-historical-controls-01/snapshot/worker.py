import hashlib
import json
import sys
from pathlib import Path

sys.path.insert(0, "/usr/app/tools")
from anglo_frisian_experiments import compile_isolated
from sound_change_order_sensitivity import batch_apply_down

source, output = Path(sys.argv[1]), Path(sys.argv[2])
output.mkdir()
bins = compile_isolated(
    source / "source.txt", json.loads((source / "recipe.json").read_text()),
    [{"id": "before39", "stage": "OEWICombinativeUUmlaut", "side": "before"},
     {"id": "after39", "stage": "OEWICombinativeUUmlaut", "side": "after"}],
    output,
)
rows = json.loads((source / "rows.json").read_text())
finals = batch_apply_down(bins["final"], [r["fst_input"] for r in rows])
assert finals == [[r["outputs"]] for r in rows]
controls = json.loads((source / "controls.json").read_text())
for row in controls:
    actual = batch_apply_down(bins["component:OEWICombinativeUUmlaut"], [row["input"]])[0]
    row["actual"] = actual
    assert actual == [row["expected"]], row
historical = []
for form in ["*wíduwōn", "*wíduz", "*wítun", "*wítaną"]:
    historical.append({
        "input": form,
        "parser": batch_apply_down(bins["component:EnglishProtoInput"], [form])[0],
        "before": batch_apply_down(bins["before39"], [form])[0],
        "after": batch_apply_down(bins["after39"], [form])[0],
        "final": batch_apply_down(bins["final"], [form])[0],
    })
report = {
    "fst_sha256": hashlib.sha256((source / "source.txt").read_bytes()).hexdigest(),
    "selected_count": len(rows),
    "selected_final_changes": 0,
    "controls": controls,
    "historical_controls": historical,
}
(output / "report.json").write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n")
print(json.dumps(report, indent=2, ensure_ascii=False))
