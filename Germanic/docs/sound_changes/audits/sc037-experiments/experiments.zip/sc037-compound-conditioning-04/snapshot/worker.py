import hashlib
import json
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, "/usr/app/tools")
from anglo_frisian_experiments import compile_isolated
from sound_change_order_sensitivity import batch_apply_down

source, output = Path(sys.argv[1]), Path(sys.argv[2])
output.mkdir()
recipe = json.loads((source / "recipe.json").read_text())
bins = compile_isolated(
    source / "candidate.txt", recipe,
    [{"id": "before37", "stage": "OECompoundLinkingSyncope", "side": "before"}],
    output,
)
rows = json.loads((source / "rows.json").read_text())
forms = [r["fst_input"] for r in rows]
before = batch_apply_down(bins["before37"], forms)
assert all(len(r) == 1 for r in before)
old = batch_apply_down(bins["component:SC37Old"], [r[0] for r in before])
new = batch_apply_down(bins["component:SC37Fix"], [r[0] for r in before])
assert old == new
finals = batch_apply_down(bins["final"], forms)
assert finals == [[r["outputs"]] for r in rows]
controls = json.loads((source / "controls.json").read_text())
for control in controls:
    actual = batch_apply_down(bins["component:SC37Fix"], [control["input"]])[0]
    previous = batch_apply_down(bins["component:SC37Old"], [control["input"]])[0]
    control.update(actual=actual, previous=previous)
    assert actual == [control["expected"]], control
historical_inputs = ["*wíni-frìθuz", "*dúru-wàrðaz", "*xándu-klàθaz"]
historical = []
for form in historical_inputs:
    parsed = batch_apply_down(bins["component:EnglishProtoInput"], [form])[0]
    stage = batch_apply_down(bins["before37"], [form])[0]
    historical.append({"input": form, "parser": parsed, "before37": stage})
    if len(stage) == 1:
        historical[-1]["old"] = batch_apply_down(bins["component:SC37Old"], stage)[0]
        historical[-1]["new"] = batch_apply_down(bins["component:SC37Fix"], stage)[0]
checks = {}
for component in ["SC37Old", "SC37Fix"]:
    p = subprocess.run(
        ["foma", "-q", "-e", f"load stack {bins['component:' + component]}",
         "-e", "test functional", "-e", "quit"],
        capture_output=True, text=True, check=True,
    )
    checks[component] = {"stdout": p.stdout, "stderr": p.stderr}
report = {
    "source_sha256": hashlib.sha256((source / "source.txt").read_bytes()).hexdigest(),
    "candidate_sha256": hashlib.sha256((source / "candidate.txt").read_bytes()).hexdigest(),
    "compiler_sha256": hashlib.sha256(Path("/usr/local/bin/foma").read_bytes()).hexdigest(),
    "selected_count": len(rows), "selected_rule_changes": 0, "selected_final_changes": 0,
    "firings": [dict(row_id=r["row_id"], concept=r["concept"], before=a, after=b)
                for r, a, b in zip(rows, before, old) if a != b],
    "controls": controls, "historical_controls": historical, "functionality": checks,
}
(output / "report.json").write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n")
print(json.dumps(report, indent=2, ensure_ascii=False))
