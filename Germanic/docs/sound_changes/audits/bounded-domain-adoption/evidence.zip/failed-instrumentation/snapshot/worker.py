import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

sys.path.insert(0, "/usr/app/tools")
from executable_facts import parse_defines
from probe import native


def lookup(path, words):
    result = subprocess.run(
        ["flookup", "-i", str(path)], input="\n".join(words) + "\n",
        capture_output=True, text=True, check=True)
    found = {word: set() for word in words}
    for line in result.stdout.splitlines():
        if "\t" in line:
            word, value = line.split("\t", 1)
            if value != "+?":
                found[word].add(value)
    return {word: sorted(values) for word, values in found.items()}


def export(expression, label):
    return ["clear stack", f"regex {expression};", f"save stack {label}.bin",
            f"write att > {label}.att"]


snapshot, output = map(Path, sys.argv[1:3])
output.mkdir()
source = (snapshot / "candidate.txt").read_text()
before = (snapshot / "before.txt").read_text()
facts, old = parse_defines(source), parse_defines(before)
assert {n for n in old if facts[n].body != old[n].body} == {
    "pgrmStrongPlainHeavy", "pgrmSimpleWord", "OldEnglishOrthography"}
definitions = re.sub(
    r"(?m)^\s*(?:clear stack|save stack [^\n;]+|regex [A-Za-z][A-Za-z0-9_]*\s*;)\s*$",
    "", source)
(output / "definitions.txt").write_text(definitions)
commands = [f"source {output / 'definitions.txt'}"]
commands += export("EnglishProtoInput", "parser")
commands += ["test functional", "test unambiguous"]
commands += export("EnglishProtoNative", "native-parser")
commands += export("PGCellInput", "productive-parser")
commands += export("OldEnglish", "full")
commands += export("[EnglishProtoInput.u - OldEnglish.u]", "totality-difference")
commands += ["define PreviousOrthography " + old["OldEnglishOrthography"].body + ";",
             "define GammaMap [{*ɣ} -> g];",
             "define Tier [EnglishStarAlphabet | EnglishPalatalConsonant]*;",
             "define CandidateTier [Tier .o. OldEnglishOrthography];",
             "define Factored [Tier .o. PreviousOrthography .o. GammaMap];"]
commands += export("[[CandidateTier - Factored] | [Factored - CandidateTier]].u",
                   "factorization-difference")
commands += export("[Tier .o. GammaMap]", "gamma-map")
commands += export("OldEnglishOrthography", "orthography")
result = native(commands, output, timeout=1800)
(output / "native.json").write_text(json.dumps(result, ensure_ascii=False))
assert result["returncode"] == 0
assert not any(s in result["stdout"] + result["stderr"] for s in (
    "***Unknown", "Syntax error", "***Error", "not defined"))
answers = re.findall(r"^([01]) \(1 = TRUE, 0 = FALSE\)$",
                     result["stdout"], re.MULTILINE)
assert answers == ["1", "1"], answers
rows = json.loads((snapshot / "rows.json").read_text())
words = [row["fst_input"] for row in rows]
old_parser = lookup(snapshot / "baseline-parser.bin", words)
new_parser = lookup(output / "parser.bin", words)
old_full = lookup(snapshot / "baseline-full.bin", words)
new_full = lookup(output / "full.bin", words)
assert len(rows) == 391
assert old_parser == new_parser and all(len(v) == 1 for v in new_parser.values())
assert old_full == new_full and all(len(v) == 1 for v in new_full.values())
selected = [{"row_id": row["row_id"], "fst_input": row["fst_input"],
             "analysis": old_parser[row["fst_input"]], "outputs": old_full[row["fst_input"]]}
            for row in rows]
(output / "selected391.json").write_text(json.dumps(selected, ensure_ascii=False, indent=2))
controls = ["", "p", "s", "-", "ḗô", "à", "é-ìwi", "ɣò-oxun",
            "ɣó", "gó", "ɣú", "gú", "ɣrá", "grá",
            "ɣá", "gá", "ɣí", "gí", "ɣé", "gé", "ɣjó", "gjó",
            "á-ɣa", "á-ɣan"]
tier = ["*ɣ*o", "*ɣ*i", "*a*ɣ*a", "*a*ɣ", "*a*ɣ*t",
        "*a*ɣ*r", "*n*ɣ*a", "*n*g*a", "*ɣ*ɣ*i", "*g*g*i",
        "*ʝ*i", "*j*i", "*ʒ*i", "*ʤ*i", "*ç*i", "*x*a", "*ɔ̆"]
checks = {label: lookup(output / (label + ".bin"), controls)
          for label in ("parser", "native-parser", "productive-parser", "full")}
checks["orthography"] = lookup(output / "orthography.bin", tier)
assert all(checks[label][""] == [] for label in (
    "parser", "native-parser", "productive-parser"))
assert checks["full"]["é-ìwi"] == ["iī", "īi"]
assert checks["full"]["ɣó"] == ["go"]
assert checks["full"]["ḗô"] == [] and checks["full"]["à"] == []
(output / "controls.json").write_text(json.dumps(checks, ensure_ascii=False, indent=2))
(output / "compiler.json").write_text(json.dumps({
    "version": subprocess.check_output(["foma", "-v"], text=True).strip(),
    "sha256": hashlib.sha256(Path("/usr/local/bin/foma").read_bytes()).hexdigest(),
    "before_sha256": hashlib.sha256(before.encode()).hexdigest(),
    "candidate_sha256": hashlib.sha256(source.encode()).hexdigest(),
    "parser_native_functional": True, "parser_native_unambiguous": True,
    "population": len(rows), "changed_analyses": 0, "changed_finals": 0,
}, indent=2))
print("Bounded joint candidate: canonical native gates pass; epsilon rejected on both branches; all391 analyses and finals conserved; broad negative diagnostics retained.")
