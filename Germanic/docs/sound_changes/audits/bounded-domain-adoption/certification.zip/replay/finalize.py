import hashlib
import json
import os
from pathlib import Path
import sys

ROOT = Path.cwd()
WORK = ROOT / ".capr-work/final-bounded-adoption"
sys.path.insert(0, str(ROOT / "Germanic/tools"))
from adjudication_control import run_logged
from adjudication_run import load

os.environ.update(COMPOSE_PROJECT_NAME="capr-cascade-formal",
                  COMPOSE_FILE="docker-compose.yml:.capr-work/compose.yml")
decision = json.loads((WORK / "decision.json").read_text())
for name, expected in decision["intended_source_modifications"].items():
    actual = hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
    assert actual == expected, (name, actual, expected)
receipts = []
for sc in ("SC001", "SC092"):
    receipt = run_logged(
        [sys.executable, "Germanic/tools/adjudicate.py", sc, "--finalize"],
        label=sc + "-bounded-finalize", log_dir=WORK / "logs", cwd=ROOT, timeout=3600)
    receipts.append(receipt)
    (WORK / "finalization.json").write_text(json.dumps(receipts, indent=2))
    print(sc, receipt["ok"], receipt["stdout_log"], receipt["stderr_log"], flush=True)
    assert receipt["ok"], Path(receipt["stderr_log"]).read_text() + Path(receipt["stdout_log"]).read_text()[-5000:]
load("SC001").complete_stage("PROPAGATE", evidence={"receipts": receipts})
print("Both coordinated source-bound finalizations accepted.", flush=True)
