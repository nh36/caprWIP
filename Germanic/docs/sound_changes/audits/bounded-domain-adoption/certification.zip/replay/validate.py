import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path.cwd()
WORK = ROOT / ".capr-work/final-bounded-adoption"
sys.path.insert(0, str(ROOT / "Germanic/tools"))
from adjudication_control import run_logged
from adjudication_run import load, record_validation_level

os.environ.update(COMPOSE_PROJECT_NAME="capr-cascade-formal",
                  COMPOSE_FILE="docker-compose.yml:.capr-work/compose.yml")
receipts = []
commands = [
    ("A", None, ROOT / "Germanic/tests",
     [sys.executable, "-m", "pytest", "-q", "test_bounded_domain_adoption.py",
      "test_lexical_witness_input_gate.py", "test_sc036_adjudication.py",
      "test_parser_functionality_proof.py",
      "test_sc035_prosody.py::test_context_lifting_preserves_the_other_segmental_rule_kernels"]),
    ("B", None, ROOT, [sys.executable, "Germanic/tools/adjudicate.py", "--refresh"]),
    ("B", None, ROOT, [sys.executable, "Germanic/tools/adjudicate.py", "--status"]),
    ("C", "serial", ROOT / "Germanic/tests",
     [sys.executable, "-m", "pytest", "-q", "--ignore=test_evidence_interface.py"]),
    ("C", "exclusive", ROOT / "Germanic/tests",
     [sys.executable, "-m", "pytest", "-q", "test_evidence_interface.py"]),
]
for level, lane, cwd, argv in commands:
    receipt = run_logged(
        argv, label="bounded-adoption-" + level + "-" + (lane or str(len(receipts))),
        log_dir=WORK / "logs", cwd=cwd, level=level, lane=lane, timeout=7200)
    receipts.append(receipt)
    (WORK / "validation.json").write_text(json.dumps(receipts, indent=2))
    print(level, lane, receipt["ok"], receipt["stdout_log"], receipt["stderr_log"], flush=True)
    assert receipt["ok"], Path(receipt["stdout_log"]).read_text()[-12000:] + Path(receipt["stderr_log"]).read_text()[-5000:]
old = subprocess.check_output(
    ["git", "show", "7e6023eda8a52df8916181aa98bbd935f331d069:Germanic/docs/debug_snapshots/oe_full_trace_report.txt"],
    cwd=ROOT, text=True)
current = (ROOT / "Germanic/docs/debug_snapshots/oe_full_trace_report.txt").read_text()
assert "=== BUCKET:" in old and "=== BUCKET:" in current
assert old.split("=== BUCKET:", 1)[1] == current.split("=== BUCKET:", 1)[1]
trace_receipt = {
    "before_commit": "7e6023eda8a52df8916181aa98bbd935f331d069",
    "after_source_sha256": "c51c3f440e48c320968dd7a12c3b9995c2b16f5e766ef075f16f7af8eba76d3d",
    "file": "Germanic/docs/debug_snapshots/oe_full_trace_report.txt",
    "comparison": "Entire391-row trace body byte-identical after provenance header",
    "selected": 391, "stages": 110, "stage_comparisons": 43010,
    "matches": 383, "inherited_mismatches": 8, "changed_stage_outputs": 0}
(WORK / "trace-conservation.json").write_text(json.dumps(trace_receipt, indent=2) + "\n")
run = load("SC001")
for level in ("A", "B", "C"):
    record_validation_level(run, level, [r for r in receipts if r["level"] == level])
run.complete_stage("VALIDATE", evidence={"receipts": receipts, "trace_conservation": trace_receipt})
run.complete_stage("COMPLETE", note="Coordinated SC001/SC092 bounded adoption;391 full histories conserved; no SC086 ordering adopted or broad totality claim.")
print("COMPLETE: exact approved source, both finalizations, A/B/C and391 full-history conservation.", flush=True)
