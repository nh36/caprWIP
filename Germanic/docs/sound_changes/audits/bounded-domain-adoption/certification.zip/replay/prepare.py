import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path.cwd()
sys.path.insert(0, str(ROOT / "Germanic/tools"))
from adjudication_control import run_logged
from adjudication_run import load
from experiment_snapshot import create_snapshot

os.environ.update(COMPOSE_PROJECT_NAME="capr-cascade-formal",
                  COMPOSE_FILE="docker-compose.yml:.capr-work/compose.yml")
work = ROOT / ".capr-work/final-bounded-adoption"
previous = ROOT / ".capr-work/experiments/post-sc052-domain-03"
snapshot = create_snapshot(
    "final-bounded-adoption-02",
    "Coordinated SC001 lexical-nucleus repair and SC092 surviving-gamma spelling; no contraction adoption.",
    {"candidate": work / "target-germanic.txt",
     "before": ROOT / "Germanic/fsts/germanic.txt",
     "worker": work / "worker.py",
     "probe": previous / "snapshot/probe.py",
     "rows": previous / "snapshot/rows.json",
     "baseline-parser": previous / "results/outputs/EnglishProtoInput.bin",
     "baseline-full": previous / "snapshot/accepted.bin"},
    negative_controls=["epsilon, vowelless roots and surviving front-palatal reflexes",
                       "retain synthetic SC086 branching and historical-domain partiality"],
    expected_outcomes={"parser_native_functional": True,
                       "parser_native_unambiguous": True,
                       "selected391_analysis_changes": 0, "selected391_final_changes": 0},
    environment=json.loads((previous / "results/outputs/compiler.json").read_text()))
load("SC001").complete_stage("SNAPSHOT", evidence={"snapshot_root": str(snapshot.root)})
container = snapshot.stage_in_container()
output = container + "-outputs"
receipt = run_logged(
    ["docker", "compose", "exec", "-T", "backend", "python3",
     container + "/worker.py", container, output],
    label="bounded-parser-and-orthography-candidate", log_dir=snapshot.staging_dir,
    cwd=ROOT, timeout=1800)
(work / "execution.json").write_text(json.dumps({
    "container": container, "output": output, "receipt": receipt}, indent=2))
subprocess.run(["docker", "compose", "cp", "backend:" + output,
                str(snapshot.staging_dir / "outputs")], check=True, capture_output=True)
print(json.dumps(receipt, indent=2))
assert receipt["ok"], Path(receipt["stderr_log"]).read_text()
