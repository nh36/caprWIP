from collections import defaultdict, deque
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import sys

ROOT = Path.cwd()
WORK = ROOT / ".capr-work/final-bounded-adoption"
sys.path.insert(0, str(ROOT / "Germanic/tools"))
from experiment_snapshot import Snapshot
from adjudication_run import load

spec = importlib.util.spec_from_file_location(
    "proof", ROOT / "Germanic/docs/sound_changes/audits/parser-formal-resolution/functionality.py")
proof = importlib.util.module_from_spec(spec)
spec.loader.exec_module(proof)
snapshot = Snapshot(ROOT / ".capr-work/experiments/final-bounded-adoption-02")
outputs = snapshot.staging_dir / "outputs"
paths = {}
for label, cases in {
    "parser": [("", None), ("ḗô", "*ḗ*ô"), ("é-ìwi", "*é*ì*w*i")],
    "native-parser": [("", None)],
    "productive-parser": [("", None)],
    "full": [("", None), ("ḗô", None), ("à", None),
             ("é-ìwi", "iī"), ("é-ìwi", "īi"),
             ("ɣò-oxun", "goōn"), ("ɣò-oxun", "gōon"), ("ɣó", "go")],
}.items():
    path = outputs / (label + ".att")
    arcs, finals = proof.read_att(path.read_text())
    adjacent = defaultdict(list)
    for index, (source, target, upper, lower) in enumerate(arcs):
        adjacent[source].append(index)
    checks = []
    for word, expected in cases:
        start = (0, 0, 0)
        pending, parent, accepted = deque([start]), {start: None}, None
        while pending:
            node = pending.popleft()
            state, i, j = node
            if state in finals and i == len(word) and (expected is None or j == len(expected)):
                accepted = node
                break
            for index in adjacent[state]:
                _, target, upper, lower = arcs[index]
                a = "" if upper == proof.EPSILON else upper
                b = "" if lower == proof.EPSILON else lower
                if not word.startswith(a, i) or (expected is not None and not expected.startswith(b, j)):
                    continue
                next_node = target, i + len(a), 0 if expected is None else j + len(b)
                if next_node not in parent:
                    parent[next_node] = node, index
                    pending.append(next_node)
        assert (accepted is not None) == (expected is not None), (label, word, expected)
        item = {"input": word, "output": expected, "accepted": accepted is not None,
                "complete_reachable_configurations": len(parent)}
        if accepted is not None:
            indices, node = [], accepted
            while parent[node] is not None:
                node, index = parent[node]
                indices.append(index)
            item.update(arc_path=list(reversed(indices)), final_state=accepted[0])
        checks.append(item)
    paths[label] = {"att_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                    "checks": checks}
    print(label, "complete accepting-path checks passed", flush=True)
(snapshot.staging_dir / "complete-paths.json").write_text(json.dumps(paths, ensure_ascii=False, indent=2))
shutil.copytree(WORK / "proofs", snapshot.staging_dir / "proofs")
execution = json.loads((WORK / "execution.json").read_text())
snapshot.complete(
    "passed", "Exact source c51c3f44: independent canonical and gamma-map certificates; native reloaded parser gates; actual complete epsilon/path checks;391 conserved analyses/finals. Builder-context native false negative and failed predecessor retained.",
    [execution["receipt"]], {"source_sha256": "c51c3f440e48c320968dd7a12c3b9995c2b16f5e766ef075f16f7af8eba76d3d"})
snapshot.staging_dir.symlink_to("results", target_is_directory=True)
load("SC001").complete_stage("INVESTIGATE", evidence={
    "experiments": [{"snapshot_root": str(snapshot.root), "receipt": execution["receipt"]}],
    "complete_graphs": str(snapshot.results_dir / "proofs/summary.json"),
    "complete_paths": str(snapshot.results_dir / "complete-paths.json"),
    "source_assessment": "post-sc052-domain-and-contraction/adoption-recommendations.md",
    "failed_instrumentation_preserved": "final-bounded-adoption-01",
})
