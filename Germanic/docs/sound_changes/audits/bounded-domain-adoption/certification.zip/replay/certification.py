import hashlib
import json
from pathlib import Path
import subprocess
import sys
import zipfile

ROOT = Path.cwd()
WORK = ROOT / ".capr-work/final-bounded-adoption"
sys.path.insert(0, str(ROOT / "Germanic/tools"))
from adjudication_run import load

commit = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
run = load("SC001")
assert run.state()["stages"]["COMPLETE"]["status"] == "complete"
decision = json.loads((WORK / "decision.json").read_text())
for name, expected in decision["intended_source_modifications"].items():
    actual = subprocess.check_output(["git", "show", f"{commit}:{name}"])
    assert hashlib.sha256(actual).hexdigest() == expected, name
tested = json.loads((WORK / "validation.json").read_text())[-1]["source_identity_after"]["worktree_changes"]
for name, expected in tested.items():
    actual = subprocess.check_output(["git", "show", f"{commit}:{name}"])
    assert hashlib.sha256(actual).hexdigest() == expected, name
binding = {
    "scientific_commit": commit,
    "source_sha256": "c51c3f440e48c320968dd7a12c3b9995c2b16f5e766ef075f16f7af8eba76d3d",
    "verified_committed_source_targets": decision["intended_source_modifications"],
    "verified_all_tested_worktree_files": tested,
    "research_reports_commit": "7e6023eda8a52df8916181aa98bbd935f331d069",
    "certified_domain": "Functional canonical parser; deterministic surviving-gamma map; selected391 unique outputs. No global complete-cascade functionality or totality claim.",
}
binding["immutable_evidence_commit"] = subprocess.check_output(
    ["git", "rev-parse", "0625660d"], text=True).strip()
(WORK / "source-commit-binding.json").write_text(json.dumps(binding, indent=2) + "\n")
members = {}
for name in ["decision.json", "decision-before-memo-schema-repair.json",
             "execution.json", "failed-execution-01.json",
             "finalization.json", "failed-finalization.json", "validation.json",
             "validation-before-orthography-inventory-repair.json",
             "decision-before-orthography-inventory-repair.json",
             "trace-conservation.json", "source-commit-binding.json",
             "memo-repair-preflight.json"]:
    members[name] = (WORK / name).read_bytes()
for name in ["prepare.py", "worker.py", "audit.py", "bundle.py",
             "decide.py", "finalize.py", "validate.py", "certification.py"]:
    members["replay/" + name] = (WORK / name).read_bytes()
for path in sorted((WORK / "logs").glob("*")):
    if path.is_file():
        members["logs/" + path.name] = path.read_bytes()
for directory in [run.root,
                  run.root.parent / "archive/SC001-before-machine-verdict-line-repair",
                  run.root.parent / "archive/SC001-before-orthography-inventory-repair",
                  run.root.parent / "archive/SC001-before-native-context-instrumentation-repair"]:
    for path in sorted(directory.iterdir()):
        if path.is_file():
            members["journals/" + directory.name + "/" + path.name] = path.read_bytes()
destination = WORK / "certification.zip"
with zipfile.ZipFile(destination, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, data in sorted(members.items()):
        archive.writestr(name, data)
manifest = {"scientific_commit": commit, "source_sha256": binding["source_sha256"],
            "certification_zip_sha256": hashlib.sha256(destination.read_bytes()).hexdigest(),
            "members": {name: {"sha256": hashlib.sha256(data).hexdigest(), "bytes": len(data)}
                        for name, data in sorted(members.items())}}
(WORK / "CERTIFICATION_MANIFEST.json").write_text(json.dumps(manifest, indent=2) + "\n")
with zipfile.ZipFile(destination) as archive:
    assert set(archive.namelist()) == set(manifest["members"])
    for name, expected in manifest["members"].items():
        assert hashlib.sha256(archive.read(name)).hexdigest() == expected["sha256"]
print("Scientific commit", commit)
print("Verified certification", len(members), "text members,", destination.stat().st_size, "bytes")
