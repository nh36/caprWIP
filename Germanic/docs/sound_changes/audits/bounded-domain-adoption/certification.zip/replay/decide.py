import hashlib
import json
from pathlib import Path
import sys

ROOT = Path.cwd()
WORK = ROOT / ".capr-work/final-bounded-adoption"
sys.path.insert(0, str(ROOT / "Germanic/tools"))
import adjudication_run
import artifact_graph

targets = json.loads((WORK / "decision.json").read_text())["intended_source_modifications"]
for path in (WORK / "targets").rglob("*"):
    if path.is_file() and path.suffix in {".md", ".py", ".tsv"}:
        targets[str(path.relative_to(WORK / "targets"))] = hashlib.sha256(path.read_bytes()).hexdigest()
targets["Germanic/fsts/germanic.txt"] = hashlib.sha256((WORK / "target-germanic.txt").read_bytes()).hexdigest()
generated = {path.resolve() for node in artifact_graph.nodes() for path in node.outputs()}
for path in targets:
    assert artifact_graph.propagation_path_kind(ROOT / path, generated=generated) == "SOURCE", path
decision = {
    "historical_phenomenon": "SC001 technical lexical-nucleus repair; SC092 late spelling projection of surviving velar fricatives to g, not phonetic stops or a contraction ordering.",
    "conditioning": "Mandatory nucleus in six native grouping pairs; surviving starred velar fricative at terminal orthography after independently owned palatalization.",
    "executable_implementation": "Twelve grouping punctuation substitutions in pgrmStrongPlainHeavy/pgrmSimpleWord and one literal replacement clause in OldEnglishOrthography; no other define changes.",
    "selected_input_assumptions": "Unchanged391 context-bearing inputs/targets, accepted four cells, original380 and frozen protections.",
    "firing_census": "All391 old/new analyses and final outputs uniquely identical; selected full-stage history comparison required during refresh. Existing SC086 five-row census retained.",
    "positive_witnesses": [
        "Canonical parser complete certificate:8116 arcs,2986 reachable twins,2914 live,delay1; epsilon rejected on actual canonical/native/productive ATT.",
        "Gamma map complete certificate:106 arcs,13 reachable twins,11 live,delay0; factorization difference empty; gamma-o -> go, gamma-u -> gu, gamma-ra -> græ."],
    "negative_controls": [{"description": "Complete epsilon/vowelless checks, all391 analysis/final equalities, preserved palatal/stop/x/ç classes and empty deterministic-factor path difference.", "passed": True}],
    "counterfactual_results": "Both partial parser repairs retain epsilon; combined graph independently proved strict vowel-bearing subdomain. Raw SC086 branching and exact totality failure remain, not masked by input filtering.",
    "literature_support": "SC001 technical construction, not a historical law. Campbell1959 p21 §50(4),p180 §446; RingeTaylor2014 p4. Preserved SC086 assessment: Campbell pp98,100; RingeTaylor pp259,318.",
    "historical_vs_modelling": "No historical node/chronology/contraction change or directional historical ordering; terminal g is a general spelling policy with final g/h qualifications.",
    "unresolved": [
        {"description": "Current broad source still branches on artificial SC086 input and remains partial on à/ḗô; exact paths and domain difference preserved.",
         "acknowledged_in": "Germanic/docs/sound_changes/audits/sc001-lexical-nucleus-adoption.md#residue"},
        {"description": "Builder-context native functional0 versus fresh-loaded functional1/unambiguous1 and complete certified identical ATT; failed first assertion and both transcripts preserved.",
         "acknowledged_in": "Germanic/docs/sound_changes/audits/sc001-lexical-nucleus-adoption.md#diagnosis"},
        {"description": "Preexisting decomposed-o-breve orthography ambiguity is not repaired by deterministic factor.",
         "acknowledged_in": "Germanic/docs/sound_changes/audits/sc092-adjudication.md#residue"}],
    "verdict": "REFORMULATE/RESTRICT",
    "coordinated_adjudications": ["SC001", "SC092"],
    "intended_source_modifications": targets,
    "validation_control_decision": "Only independently pinned heavy parser and orthography identifiers added to historical inventories; only mandatory simple-root brackets normalized for historical comparison; four focused source/proof/runtime tests added. The first strict pass found one further inventory in test_sc035_prosody.py; add only OldEnglishOrthography, independently pinned by test_bounded_domain_adoption.py. No SC035 rule, context, stage, source or verdict changes. Preserve the actual failed strict receipt,1913 passes,5 skips and9635 subtests. Native diagnostics, frozen baselines, original380 and replay skips retained. Complete graph and fresh-loaded native gates certify parser; builder false negative preserved without changing the domain to satisfy it.",
}
(WORK / "decision.json").write_text(json.dumps(decision, ensure_ascii=False, indent=2) + "\n")
run = adjudication_run.load("SC001")
run.complete_stage("DECIDE", evidence=decision)
run.begin_propagation(targets)
print(run.report())
