import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path.cwd()
WORK = ROOT / ".capr-work/final-bounded-adoption"
destination = WORK / "targets/Germanic/docs/sound_changes/audits/bounded-domain-adoption"
destination.mkdir(parents=True, exist_ok=True)
members, omitted = {}, {}
for identifier, prefix in [("final-bounded-adoption-02", ""),
                            ("final-bounded-adoption-01", "failed-instrumentation/")]:
    root = ROOT / ".capr-work/experiments" / identifier
    for subdir in ["snapshot", "results"]:
        for path in sorted((root / subdir).rglob("*")):
            if not path.is_file():
                continue
            name = prefix + str(path.relative_to(root))
            if subdir == "results":
                name = prefix + str(path.relative_to(root / subdir))
            data = path.read_bytes()
            if path.suffix == ".bin":
                omitted[name] = {"sha256": hashlib.sha256(data).hexdigest(),
                                 "bytes": len(data), "reason": "native compiled binary; text graph retained"}
            else:
                members[name] = data
    for name in ["receipt.json", "completion.json"]:
        members[prefix + name] = (root / name).read_bytes()
members["operational-notes.json"] = json.dumps({
    "native_context_discrepancy": "Builder0/unambiguous1; fresh process loading identical saved parser1/1; complete independent graph certificate positive. Failed assertion preserved.",
    "receipt_location_preservation": "After atomic promotion, task-owned staging symlink points to results so original authentic absolute receipt/log paths remain resolvable; no receipt bytes edited.",
    "restricted_holdings": "No scholarly originals, page images or scans included.",
    "source_sha256": "c51c3f440e48c320968dd7a12c3b9995c2b16f5e766ef075f16f7af8eba76d3d",
    "omitted_native_binaries": omitted,
}, indent=2).encode()
with zipfile.ZipFile(destination / "evidence.zip", "w", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, data in sorted(members.items()):
        archive.writestr(name, data)
manifest = {"source_sha256": "c51c3f440e48c320968dd7a12c3b9995c2b16f5e766ef075f16f7af8eba76d3d",
            "evidence_zip_sha256": hashlib.sha256((destination / "evidence.zip").read_bytes()).hexdigest(),
            "members": {name: {"sha256": hashlib.sha256(data).hexdigest(), "bytes": len(data)}
                        for name, data in sorted(members.items())}}
(destination / "MANIFEST.json").write_text(json.dumps(manifest, indent=2) + "\n")
with zipfile.ZipFile(destination / "evidence.zip") as archive:
    assert set(archive.namelist()) == set(manifest["members"])
    for name, expected in manifest["members"].items():
        assert hashlib.sha256(archive.read(name)).hexdigest() == expected["sha256"]
print("Verified", len(members), "text members;", (destination / "evidence.zip").stat().st_size, "bytes")
