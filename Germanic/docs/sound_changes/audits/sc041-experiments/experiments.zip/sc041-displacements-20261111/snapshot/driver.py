import hashlib
import json
import os
from pathlib import Path
import sys
import time

sys.path.insert(0, "/usr/app/tools")
import anglo_frisian_experiments as af
from sound_change_order_sensitivity import batch_apply_down, outputs_match_expected

source, recipes_path, rows_path, output_path = map(Path, sys.argv[1:5])
data = af.load_recipes(recipes_path)
rows = json.loads(rows_path.read_text())
forms = [row["fst_input"] for row in rows]
out = output_path.parent
out.mkdir(parents=True, exist_ok=True)
result = {
    "source_sha256": af.digest(source),
    "recipes_sha256": af.digest(recipes_path),
    "rows_sha256": af.digest(rows_path),
    "canonical_contexts_preserved": True,
    "accepted": len(rows),
    "variants": {},
}


def save():
    output_path.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")


image_dir = out / "image"
image_dir.mkdir()
start = time.monotonic()
image = af.prepare_definition_image(source, image_dir)
if image is None:
    raise RuntimeError("The pinned source did not support verified definition-image reuse")
os.environ["CAPR_FOMA_DEFINITION_IMAGE"] = str(image)
result["definition_image"] = {
    "path": str(image), "sha256": af.digest(image),
    "identity": json.loads(image.with_suffix(".json").read_text()),
    "elapsed_seconds": time.monotonic() - start,
}
print("Verified definition image prepared", flush=True)
identity_bin = image_dir / "old_english.bin"
identity = batch_apply_down(identity_bin, forms)
differences = [
    {"concept": row["concept"], "expected": row["baseline_outputs"], "actual": actual}
    for row, actual in zip(rows, identity)
    if actual != row["baseline_outputs"]
]
result["identity_control"] = {
    "full_source_compilation": True,
    "different_from_canonical_trace": differences,
    "matches": sum(outputs_match_expected(actual, row["counterpart"])
                   for row, actual in zip(rows, identity)),
}
save()
if differences or result["identity_control"]["matches"] != 386:
    raise RuntimeError("The fresh isolated identity control differs from the certified cascade")

for recipe in data["recipes"]:
    if recipe["id"] == "identity":
        continue
    directory = out / recipe["id"]
    directory.mkdir()
    start = time.monotonic()
    prefix = af.definition_image_source(source.read_text(), directory)
    if not prefix.startswith("load defined "):
        raise RuntimeError("Verified common-definition reuse unexpectedly declined")
    print("START", recipe["id"], flush=True)
    bins = af.compile_isolated(source, recipe, data["probes"], directory)
    actual = batch_apply_down(bins["final"], forms)
    intermediates = af.intermediate_outputs(bins, forms)
    checks = af.check_component_predictions(recipe, bins)
    record = {
        "elapsed_seconds": time.monotonic() - start,
        "definition_image_reused": True,
        "order": af.complete_variant_order(recipe),
        "bins": {name: {"path": str(path), "sha256": af.digest(path)}
                 for name, path in bins.items()},
        "matches": sum(outputs_match_expected(value, row["counterpart"])
                       for row, value in zip(rows, actual)),
        "no_output": sum(not value for value in actual),
        "multiple_output": sum(len(value) > 1 for value in actual),
        "component_checks": checks,
        "rows": [],
    }
    for i, (row, value) in enumerate(zip(rows, actual)):
        record["rows"].append({
            **row, "outputs": value,
            "changed": value != row["baseline_outputs"],
            "baseline_match": outputs_match_expected(row["baseline_outputs"], row["counterpart"]),
            "variant_match": outputs_match_expected(value, row["counterpart"]),
            "intermediates": {key: values[i] for key, values in intermediates.items()},
        })
    record["changed"] = sum(row["changed"] for row in record["rows"])
    record["newly_failing"] = sum(row["baseline_match"] and not row["variant_match"]
                                 for row in record["rows"])
    result["variants"][recipe["id"]] = record
    save()
    print("END", recipe["id"],
          json.dumps({key: record[key] for key in
                      ("elapsed_seconds", "matches", "changed", "newly_failing",
                       "no_output", "multiple_output")}), flush=True)

before = result["variants"]["before-restoration"]["rows"]
after = result["variants"]["after-restoration"]["rows"]
result["local_restoration_difference"] = [
    {"concept": a["concept"], "selected_input": a["proto"],
     "before_restoration_variant": a["outputs"],
     "after_restoration_variant": b["outputs"],
     "before_variant_intermediates": a["intermediates"],
     "after_variant_intermediates": b["intermediates"]}
    for a, b in zip(before, after) if a["outputs"] != b["outputs"]
]
save()
print("COMPLETE local restoration differences:",
      [row["concept"] for row in result["local_restoration_difference"]], flush=True)
