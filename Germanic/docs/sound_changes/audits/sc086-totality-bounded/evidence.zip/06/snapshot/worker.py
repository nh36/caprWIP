import json
from pathlib import Path
import sys

from probe import native

snapshot, output = map(Path, sys.argv[1:3])
output.mkdir()
commands = []
for label in ("full", "mapped"):
    commands += ["clear stack", f"load stack {snapshot / (label + '.bin')}",
                 f"write att > {label}.att"]
receipt = native(commands, output)
(output / "native.json").write_text(json.dumps(receipt, ensure_ascii=False))
assert receipt["returncode"] == 0
assert not any(message in receipt["stdout"] + receipt["stderr"]
               for message in ("***Unknown", "Syntax error", "***Error"))
print("Actual original and mapped complete native relations exported unchanged.")
