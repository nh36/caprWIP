import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

from executable_facts import define_facts
from probe import native


def lookup(bin_path, words):
    result = subprocess.run(["flookup", "-i", str(bin_path)],
                            input="\n".join(words) + "\n",
                            capture_output=True, text=True, check=True)
    outputs = {word: [] for word in words}
    for line in result.stdout.splitlines():
        if "\t" in line:
            word, output = line.split("\t", 1)
            if output != "+?" and output not in outputs[word]:
                outputs[word].append(output)
    return outputs


snapshot, output = map(Path, sys.argv[1:3])
output.mkdir()
source = (snapshot / "fst.txt").read_text()
sequence = json.loads((snapshot / "sequence.json").read_text())
assert sequence[98]["name"] != "OEContraction"
assert sequence[99]["name"] == "OEContraction"
facts = define_facts(snapshot / "fst.txt")
clauses = re.findall(
    r"\{\*([^}]+)\}\s+\{\*([^}]+)\}\s+->\s+\{\*([^}]+)\}",
    facts["OEContraction"].body)
assert len(clauses) == 27
triples = ["*" + a + "*" + b + "*" + b for a, b, _ in clauses]
(output / "clause-inventory.json").write_text(json.dumps(clauses, ensure_ascii=False))
commands = [f"source {snapshot / 'fst.txt'}", "clear stack",
            "regex [[EnglishStarAlphabet | EnglishPalatalConsonant]* .o. OEContraction];",
            "save stack contraction.bin", "write att > contraction.att",
            "test functional", "clear stack",
            "regex [[{*o}|{*ō}]* .o. [{*o} {*o} -> {*ō}]];",
            "save stack binary.bin", "write att > binary.att", "test functional"]
for index, stage in enumerate(sequence[:100]):
    body = stage["expression"] if index == 0 else (
        f"Cp{index - 1} .o. {stage['expression']}")
    commands.append(f"define Cp{index} [{body}];")
    if index in (98, 99):
        commands += ["clear stack", f"regex Cp{index};",
                     f"save stack broad-{index}.bin"]
commands += [
    "define PrimaryRaw [á|é|í|ó|ú|ḗ|ḯ|{ái}|{áu}|{éu}|{íu}];",
    "define OnePrimary [[?* PrimaryRaw ?*] - [?* PrimaryRaw ?* PrimaryRaw ?*]];",
    "define HeadMask [[pgrmPrefix.u|0] pgrmOnset.u PrimaryRaw ?*];",
    "define HMarked [EnglishProtoInput.u & HeadMask & OnePrimary];",
    "define HeadLongMask [[pgrmPrefix.u|0] pgrmOnset.u "
    "[ā|ē|ī|ō|ǭ|ū|ô|ą|ę|ų|{ai}|{au}|{eu}|{iu}] ?*];",
    "define HLong [[EnglishProtoInput.u & HeadLongMask] - [?* PrimaryRaw ?*]];",
    "define HGeneral [HMarked | HLong];",
    "clear stack", "regex EnglishProtoInput;", "save stack parser.bin",
    "clear stack", "regex OldEnglish;", "save stack accepted-full.bin",
]
for label in ("HMarked", "HGeneral"):
    commands += ["clear stack", f"regex {label};",
                 f"save stack {label}.bin", f"write att > {label}.att"]
    for index in (98, 99):
        commands += ["clear stack", f"regex [{label} .o. Cp{index}];",
                     f"save stack {label}-{index}.bin",
                     f"write att > {label}-{index}.att", "test functional"]
commands += ["clear stack", "regex [EnglishProtoInput.u - OldEnglish.u];",
             "write att > accepted-domain-difference.att", "test empty"]
receipt = native(commands, output)
(output / "native.json").write_text(json.dumps(receipt, ensure_ascii=False, indent=2))
assert receipt["returncode"] == 0
(output / "critical-triples.json").write_text(json.dumps(
    lookup(output / "contraction.bin", triples), ensure_ascii=False, indent=2))
heads = ["á", "é", "í", "ó", "ú", "ái", "áu", "éu", "íu",
         "ā", "ē", "ī", "ō", "ū", "ḗ", "ḯ", "ǭ", "ô"]
seconds = ["axun", "àxun", "oxun", "òxun", "exaną", "èxaną",
           "uxaną", "ùxaną", "axaną", "àxaną", "exun", "èxun",
           "oxaną", "òxaną", "ixaną", "ìxaną"]
words = [head + "-" + second for head in heads for second in seconds]
words += ["ò-oxun", "o-òxun", "ó-oxun", "ó-óxun", "ɣó", "mánxst"]
data = {label: lookup(output / name, words) for label, name in (
    ("parser", "parser.bin"), ("before", "broad-98.bin"),
    ("after", "broad-99.bin"), ("full", "accepted-full.bin"),
    ("marked_head", "HMarked.bin"), ("general_head", "HGeneral.bin"))}
(output / "head-controls.json").write_text(json.dumps(data, ensure_ascii=False, indent=2))

mapping = source.replace("define OldEnglishOrthography [",
                         "define OldEnglishOrthography [\n    {*ɣ} -> g,", 1)
assert mapping != source and mapping.count("{*ɣ} -> g,") == 1
(output / "mapping-candidate.txt").write_text(mapping)
commands = [f"source {output / 'mapping-candidate.txt'}", "clear stack",
            "regex OldEnglish;", "save stack mapping-full.bin",
            "clear stack", "regex [EnglishProtoInput.u - OldEnglish.u];",
            "write att > mapping-domain-difference.att", "test empty",
            "clear stack", "regex [HGeneral - OldEnglish.u];",
            "write att > mapping-head-domain-difference.att", "test empty",
            "clear stack",
            "regex [[EnglishStarAlphabet | EnglishPalatalConsonant]* "
            ".o. OldEnglishOrthography];",
            "save stack mapping-orthography.bin",
            "write att > mapping-orthography.att", "test functional"]
receipt = native(commands, output)
(output / "mapping-native.json").write_text(json.dumps(receipt, ensure_ascii=False, indent=2))
assert receipt["returncode"] == 0
rows = json.loads((snapshot / "rows.json").read_text())
selected = [row["fst_input"] for row in rows]
old = lookup(output / "accepted-full.bin", selected)
new = lookup(output / "mapping-full.bin", selected)
(output / "mapping-regression.json").write_text(json.dumps({
    "population": len(rows), "changes": {
        word: {"old": old[word], "new": new[word]}
        for word in selected if old[word] != new[word]},
    "controls": lookup(output / "mapping-full.bin", words[-6:]),
    "orthography": lookup(output / "mapping-orthography.bin",
                         ["*ɣ", "*g", "*j", "*ʝ", "*ʤ", "*ʧ", "*x", "*ç",
                          "*n*ɣ", "*ɣ*i", "*ɣ*a"])
}, ensure_ascii=False, indent=2))
(output / "source-identity.json").write_text(json.dumps({
    "accepted_fst_sha256": hashlib.sha256(source.encode()).hexdigest(),
    "candidate_fst_sha256": hashlib.sha256(mapping.encode()).hexdigest(),
    "compiler": subprocess.check_output(["foma", "-v"], text=True).strip()
}, indent=2))
print("Exported actual27-clause overlap controls, marked/general head-domain "
      "relations, and separate general starred-ɣ mapping inclusion differences.",
      flush=True)
