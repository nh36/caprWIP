import json
import hashlib
from pathlib import Path
import re
import sys

sys.path.insert(0, "Germanic/tools")
from executable_facts import define_facts

facts = define_facts(Path("Germanic/fsts/germanic.txt"))
reachable, pending = set(), ["OldEnglish"]
while pending:
    name = pending.pop()
    if name in reachable:
        continue
    reachable.add(name)
    pending.extend(set(re.findall(r"\b[A-Za-z][A-Za-z0-9_]*\b",
                                  facts[name].body)) & facts.keys() - reachable)

inventory = []
for name in sorted(reachable):
    body = facts[name].body
    stack, groups = [], []
    for index, char in enumerate(body):
        if char == "[":
            stack.append([index, []])
        elif char == "]":
            start, arrows = stack.pop()
            if len(arrows) > 1:
                groups.append((start, index, arrows))
        elif body[index:index + 2] in ("->", "=>") and stack:
            stack[-1][1].append(index)
    for start, end, arrows in groups:
        text, depth, split = body[start + 1:end], 0, [0]
        separators = []
        for index, char in enumerate(text):
            if char in "[(":
                depth += 1
            elif char in "])":
                depth -= 1
            elif char == "," and depth == 0:
                separators.append(index)
        sets, clauses = [], []
        previous = 0
        for index in separators:
            if index > 0 and text[index - 1] == ",":
                continue
            clauses.append(text[previous:index].strip())
            if text[index:index + 2] == ",,":
                sets.append(clauses)
                clauses = []
                previous = index + 2
            else:
                previous = index + 1
        clauses.append(text[previous:].strip())
        sets.append(clauses)
        for number, clauses in enumerate(sets):
            if len(clauses) < 2:
                continue
            centers, contexts, widths, codepoint_widths = [], [], [], []
            for clause in clauses:
                arrow = re.search(r"->|=>", clause)
                assert arrow, (name, clause)
                center = clause[:arrow.start()].strip()
                centers.append(center)
                contexts.append(clause.split("||", 1)[1].strip() if "||" in clause else "")
                tokens = re.findall(r"\{[^}]*\}", center)
                widths.append(len(tokens) if re.sub(r"\{[^}]*\}", "", center).strip() == "" else None)
                codepoint_widths.append(sum(len(token[1:-1]) for token in tokens)
                                       if widths[-1] is not None else None)
            if len(set(centers)) < 2:
                kind = "same_center_deliberate_context_union"
            elif not any(contexts):
                kind = "unconditional_distinct_centers"
            elif sum(bool(context) for context in contexts) == 1 and contexts[-1]:
                kind = "single_trailing_shared_context"
            elif len(set(contexts)) == 1:
                kind = "identical_shared_context"
            elif len({frozenset(context for center, context in zip(centers, contexts)
                                if center == unique)
                      for unique in set(centers)}) == 1:
                kind = "equal_context_unions_per_center"
            else:
                kind = "distinct_centers_distinct_contexts_review"
            inventory.append({
                "define": name, "source_line": facts[name].line,
                "ruleset": number, "classification": kind,
                "centers": centers, "contexts": contexts, "literal_segment_widths": widths,
                "literal_codepoint_widths": codepoint_widths,
                "mixed_known_widths": len({w for w in codepoint_widths if w is not None}) > 1,
            })
output = Path(".capr-work/sc086-totality/replacement-block-inventory.json")
output.write_text(json.dumps({"root": "OldEnglish", "reachable_definitions": len(reachable),
                             "fst_sha256": hashlib.sha256(Path("Germanic/fsts/germanic.txt").read_bytes()).hexdigest(),
                             "rulesets": inventory}, ensure_ascii=False, indent=2))
print("Reachable definitions", len(reachable), "single-comma rulesets", len(inventory))
for entry in inventory:
    if entry["mixed_known_widths"] or entry["classification"].endswith("_review"):
        print(entry["define"], entry["source_line"], entry["classification"],
              entry["literal_segment_widths"], entry["centers"], entry["contexts"])
