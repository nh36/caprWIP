import hashlib
import json
from pathlib import Path
import subprocess
import sys

from probe import native


def lookup(path, words):
    result = subprocess.run(["flookup", "-i", str(path)],
                            input="\n".join(words) + "\n", text=True,
                            capture_output=True, check=True)
    values = {word: set() for word in words}
    for line in result.stdout.splitlines():
        if "\t" in line:
            word, value = line.split("\t", 1)
            if value != "+?":
                values[word].add(value)
    return {word: sorted(outputs) for word, outputs in values.items()}


snapshot, output = map(Path, sys.argv[1:3])
output.mkdir()
sequence = json.loads((snapshot / "sequence.json").read_text())
domains = json.loads((snapshot / "domains.json").read_text())
rows = json.loads((snapshot / "rows.json").read_text())
commands = [f"source {snapshot / 'fst.txt'}"] + domains
for label in ("HMarked", "HGeneral", "HProsodic"):
    commands += ["clear stack", f"regex {label};", f"save stack {label}.bin"]
commands += ["clear stack", "regex OldEnglish;", "save stack original-full.bin"]
for index, stage in enumerate(sequence):
    commands += ["clear stack", f"regex [{stage['expression']}];",
                 f"save stack step-{index:03}.bin"]
receipt = native(commands, output)
(output / "native.json").write_text(json.dumps(receipt, ensure_ascii=False))
assert receipt["returncode"] == 0
assert not any(message in receipt["stdout"] + receipt["stderr"]
               for message in ("***Unknown", "Syntax error", "***Error"))
words = ["", "ɣó", "ɣí", "gí", "gá", "ggí", "ngí", "ággi", "ángi",
         "ô", "ḗô", "é-ìwi", "éu-òxun", "ái-èxun", "ò-oxun"]
traces = {word: [] for word in words}
current = {word: [word] for word in words}
for index, stage in enumerate(sequence):
    inputs = sorted({value for values in current.values() for value in values})
    values = lookup(output / f"step-{index:03}.bin", inputs) if inputs else {}
    for word in words:
        after = sorted({result for value in current[word] for result in values[value]})
        traces[word].append({"physical_stage": index + 1, "name": stage["name"],
                             "before": current[word], "after": after})
        current[word] = after
direct = lookup(output / "original-full.bin", words)
assert current == direct, "Component trace must reproduce the actual complete relation"
(output / "complete-traces.json").write_text(json.dumps(
    {"traces": traces, "direct_complete_outputs": direct,
     "mapped_complete_outputs": lookup(snapshot / "mapping.bin", words)},
    ensure_ascii=False, indent=2))
selected = [row["fst_input"] for row in rows]
membership = {}
for label in ("HMarked", "HGeneral", "HProsodic"):
    values = lookup(output / (label + ".bin"), selected)
    membership[label] = {
        "population": len(rows),
        "included": [row for row in rows if values[row["fst_input"]]],
        "excluded": [row for row in rows if not values[row["fst_input"]]],
    }
(output / "selected-domain-membership.json").write_text(
    json.dumps(membership, ensure_ascii=False, indent=2))
old = lookup(output / "original-full.bin", selected)
new = lookup(snapshot / "mapping.bin", selected)
(output / "mapping-regression.json").write_text(json.dumps({
    "population": len(rows), "changes": [
        {"row": row, "original": old[row["fst_input"]],
         "mapped": new[row["fst_input"]]}
        for row in rows if old[row["fst_input"]] != new[row["fst_input"]]]
}, ensure_ascii=False, indent=2))
(output / "component-bin-hashes.json").write_text(json.dumps({
    path.name: hashlib.sha256(path.read_bytes()).hexdigest()
    for path in sorted(output.glob("step-*.bin"))
}, indent=2))
print("Complete native component traces agree with actual full relation; "
      "selected-domain membership and general mapping regression recorded.")
