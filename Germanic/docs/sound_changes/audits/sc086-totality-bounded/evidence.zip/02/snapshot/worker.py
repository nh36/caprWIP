import json
from pathlib import Path
import re
import subprocess
import sys

from executable_facts import _blank_comments, define_facts
from probe import native


def lookup(path, words):
    result = subprocess.run(["flookup", "-i", str(path)],
                            input="\n".join(words) + "\n",
                            text=True, capture_output=True, check=True)
    data = {word: [] for word in words}
    for line in result.stdout.splitlines():
        if "\t" in line:
            word, value = line.split("\t", 1)
            if value != "+?" and value not in data[word]:
                data[word].append(value)
    return data


def run(commands, name):
    receipt = native(commands, output)
    (output / (name + ".json")).write_text(json.dumps(receipt, ensure_ascii=False, indent=2))
    assert receipt["returncode"] == 0
    assert not any(error in receipt["stdout"] + receipt["stderr"]
                   for error in ("***Unknown", "Syntax error", "***Error"))


def domains():
    return [
        "define PrimaryRaw [á|é|í|ó|ú|ḗ|ḯ|{ái}|{áu}|{éu}|{íu}];",
        "define SecondaryRaw [à|è|ì|ò|ù];",
        "define OnePrimary [[?* PrimaryRaw ?*] - [?* PrimaryRaw ?* PrimaryRaw ?*]];",
        "define HeadMask [[pgrmPrefix.u|0] pgrmOnset.u PrimaryRaw ?*];",
        "define HMarked [EnglishProtoInput.u & HeadMask & OnePrimary];",
        "define HeadLongMask [[pgrmPrefix.u|0] pgrmOnset.u "
        "[ā|ē|ī|ō|ǭ|ū|ô|ą|ę|ų|{ai}|{au}|{eu}|{iu}] ?*];",
        "define HLong [[EnglishProtoInput.u & HeadLongMask] - [?* PrimaryRaw ?*]];",
        "define HGeneral [HMarked | HLong];",
        "define SimpleHead [[[? - {-}]*] - [?* SecondaryRaw ?*]];",
        "define CompoundHeads [[? - {-}]* {-} pgrmOnset.u SecondaryRaw "
        "[? - [SecondaryRaw | {-}]]*];",
        "define HProsodic [HMarked & [SimpleHead | CompoundHeads]];",
    ]


def prefix():
    commands = []
    for index, stage in enumerate(sequence[:100]):
        body = stage["expression"] if index == 0 else f"Cp{index - 1} .o. {stage['expression']}"
        commands.append(f"define Cp{index} [{body}];")
    return commands


snapshot, output = map(Path, sys.argv[1:3])
output.mkdir()
source = (snapshot / "fst.txt").read_text()
sequence = json.loads((snapshot / "sequence.json").read_text())
facts = define_facts(snapshot / "fst.txt")
commands = [f"source {snapshot / 'fst.txt'}"] + domains() + prefix()
commands += ["clear stack", "regex EnglishProtoInput;", "save stack parser.bin",
             "write att > parser.att", "clear stack", "regex OldEnglish;",
             "save stack original-full.bin", "clear stack",
             "regex EnglishProtoInput.u;", "write att > parser-domain.att",
             "clear stack", "regex [EnglishProtoInput.u - OldEnglish.u];",
             "write att > accepted-domain-difference.att",
             "clear stack", "regex [HProsodic - EnglishProtoInput.u];",
             "write att > heads-subset-difference.att",
             "clear stack", "regex HProsodic;", "save stack HProsodic.bin",
             "write att > HProsodic.att"]
for index in (98, 99):
    commands += ["clear stack", f"regex [HProsodic .o. Cp{index}];",
                 f"save stack HProsodic-{index}.bin",
                 f"write att > HProsodic-{index}.att", "test functional"]
commands += ["clear stack", "regex Cp99;", "write att > broad-99.att"]
names = ["OEBackMutation", "OEBreakingA", "OEHighVowelApocope",
         "OEDiphthongLeveling", "OldEnglishOrthography"]
for name in names:
    for version in ("original", "scoped"):
        body = facts[name].body if version == "original" else facts[name].body.replace(",", ",,")
        commands += ["clear stack",
                     f"regex [[EnglishStarAlphabet | EnglishPalatalConsonant]* .o. [{body}]];",
                     f"save stack {name}-{version}.bin",
                     f"write att > {name}-{version}.att", "test functional"]
run(commands, "original-and-audit-native")
words = ["", "ɣó", "ą", "à", "áxa-àn", "éu-òxun", "ái-èxun", "ó-òxun", "ā-òxun"]
data = {name: lookup(output / (name + ".bin"), words) for name in
        ("parser", "original-full", "HProsodic", "HProsodic-98", "HProsodic-99")}
controls = ["*e*r*a", "*e*r*u", "*æ*r*a", "*a*r*t", "*á*r*t",
            "*a*x*a", "*é*x*a", "*u*u", "*ū*u", "*x*u",
            "*e*u", "*eu", "*éu", "*ɔ̆", "*ɣ"]
data["audit"] = {name + "-" + version: lookup(
    output / (name + "-" + version + ".bin"), controls)
    for name in names for version in ("original", "scoped")}
(output / "controls.json").write_text(json.dumps(data, ensure_ascii=False, indent=2))

match = re.search(r"\bdefine\s+OEContraction\b.*?;", _blank_comments(source), re.S)
end = source.rfind("]", match.start(), match.end())
guarded = source[:end] + " || _ [{*} | .#.]\n" + source[end:]
(output / "guarded-candidate.txt").write_text(guarded)
commands = [f"source {output / 'guarded-candidate.txt'}"] + domains() + prefix()
commands += ["clear stack", "regex OldEnglish;", "save stack guarded-full.bin",
             "clear stack", "regex [HProsodic .o. Cp99];",
             "save stack guarded-HProsodic-99.bin",
             "write att > guarded-HProsodic-99.att", "test functional"]
run(commands, "guarded-native")
selected = [row["fst_input"] for row in json.loads((snapshot / "rows.json").read_text())]
old = lookup(output / "original-full.bin", selected)
new = lookup(output / "guarded-full.bin", selected)
(output / "guarded-regression.json").write_text(json.dumps({
    "population": len(selected), "changes": {
        word: {"old": old[word], "new": new[word]}
        for word in selected if old[word] != new[word]},
    "controls": lookup(output / "guarded-full.bin", words)
}, ensure_ascii=False, indent=2))

mapping = source.replace("define OldEnglishOrthography [",
                         "define OldEnglishOrthography [\n    {*ɣ} -> g,", 1)
(output / "mapping-candidate.txt").write_text(mapping)
commands = [f"source {output / 'mapping-candidate.txt'}"] + domains()
commands += ["clear stack", "regex OldEnglish;", "save stack mapping-full.bin",
             "clear stack", "regex [EnglishProtoInput.u - OldEnglish.u];",
             "write att > mapping-domain-difference.att"]
for label in ("HMarked", "HGeneral", "HProsodic"):
    commands += ["clear stack", f"regex [{label} - OldEnglish.u];",
                 f"write att > mapping-{label}-difference.att"]
run(commands, "mapping-native")
data = {name: lookup(output / (name + ".bin"), words)
        for name in ("parser", "mapping-full")}
(output / "mapping-controls.json").write_text(json.dumps(data, ensure_ascii=False, indent=2))
print("Checked typed domains, both compound heads, complete-token guard, "
      "actual broad stage100, and original/scoped risky components; "
      "all unsupported native emptiness commands removed.", flush=True)
