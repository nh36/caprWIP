import hashlib
import json
from pathlib import Path
import subprocess
import sys


def lookup(path, words):
    result = subprocess.run(["flookup", "-i", str(path)],
                            input="\n".join(words) + "\n", text=True,
                            capture_output=True, check=True)
    values = {word: set() for word in words}
    for line in result.stdout.splitlines():
        if "\t" in line:
            word, value = line.split("\t", 1)
            if value != "+?":
                values[word].add(value)
    return {word: sorted(outputs) for word, outputs in values.items()}


snapshot, output = map(Path, sys.argv[1:3])
output.mkdir()
sequence = json.loads((snapshot / "sequence.json").read_text())
words = json.loads((snapshot / "words.json").read_text())
trace = {word: [] for word in words}
current = {word: [word] for word in words}
for index, stage in enumerate(sequence):
    inputs = sorted({value for values in current.values() for value in values})
    values = lookup(snapshot / f"s{index:03}.bin", inputs) if inputs else {}
    for word in words:
        after = sorted({result for value in current[word] for result in values[value]})
        trace[word].append({"physical_stage": index + 1, "name": stage["name"],
                            "before": current[word], "after": after})
        current[word] = after
direct = lookup(snapshot / "full.bin", words)
assert current == direct
heads = lookup(snapshot / "heads.bin", words)
(output / "source-directed-probes.json").write_text(json.dumps({
    "qualification": "Finite source-directed diagnostics, not attested triple-hiatus histories "
                     "or a global functionality certificate. Each component binary is pinned "
                     "in the immutable snapshot.",
    "traces": trace, "direct_full_outputs": direct,
    "marked_both_heads_membership": heads,
    "binary_hashes": {path.name: hashlib.sha256(path.read_bytes()).hexdigest()
                      for path in sorted(snapshot.glob("*.bin"))},
}, ensure_ascii=False, indent=2))
print("Source-directed real-form/phonotactic probes agree with the actual full relation.")
