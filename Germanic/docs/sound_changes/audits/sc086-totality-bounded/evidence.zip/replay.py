#!/usr/bin/env python3
"""Replay the preserved bounded investigation without Foma or corpus sampling."""
from collections import defaultdict, deque
import gc
import hashlib
import importlib.util
import json
from pathlib import Path
import sys


def graph(path):
    text = path.read_text()
    arcs, finals = proof.read_att(text)
    return text, arcs, finals


def path_labels(arcs, finals, indices):
    state, upper, lower = 0, [], []
    for index in indices:
        source, target, a, b = arcs[index]
        assert source == state
        state = target
        if a != proof.EPSILON:
            upper.append(a)
        if b != proof.EPSILON:
            lower.append(b)
    assert state in finals
    return upper, lower


def reachable(arcs, finals, word=None):
    adjacent = defaultdict(list)
    for source, target, a, b in arcs:
        if word is None:
            assert a == b
        adjacent[source].append((target, a))
    start = (0, 0)
    seen, pending = {start}, deque([start])
    while pending:
        state, position = pending.popleft()
        if state in finals and (word is None or position == len(word)):
            return True, seen
        for target, symbol in adjacent[state]:
            if word is None or symbol == proof.EPSILON:
                next_position = position
            elif position < len(word) and symbol == word[position]:
                next_position = position + 1
            else:
                continue
            item = (target, next_position)
            if item not in seen:
                seen.add(item)
                pending.append(item)
    return False, seen


root = Path(sys.argv[1])
spec = importlib.util.spec_from_file_location("preserved_functionality", root / "functionality.py")
proof = importlib.util.module_from_spec(spec)
spec.loader.exec_module(proof)
checks = {"functionality_certificates": 0, "language_certificates": 0, "complete_paths": 0}
for directory in ("01", "02"):
    for certificate in sorted((root / directory / "analysis").glob("*.proof.json")):
        stored = json.loads(certificate.read_text())
        att = root / directory / "outputs" / certificate.name.replace(".proof.json", ".att")
        text, arcs, finals = graph(att)
        assert hashlib.sha256(att.read_bytes()).hexdigest() == stored["att_sha256"]
        if stored["functional"]:
            proof.verify(text, stored)
        else:
            witness = stored["witness"]
            for side, indices in enumerate(witness["arc_paths"]):
                upper, lower = path_labels(arcs, finals, indices)
                assert upper == witness["input"]
                assert lower == witness["outputs"][side]
            assert witness["outputs"][0] != witness["outputs"][1]
        checks["functionality_certificates"] += 1
        del text, arcs, finals, stored
        gc.collect()
    for certificate in sorted((root / directory / "analysis").glob("*.language.json")):
        stored = json.loads(certificate.read_text())
        att = root / directory / "outputs" / certificate.name.replace(".language.json", ".att")
        text, arcs, finals = graph(att)
        assert hashlib.sha256(att.read_bytes()).hexdigest() == stored["att_sha256"]
        if stored["empty"]:
            accepted, seen = reachable(arcs, finals)
            assert not accepted
            assert sorted({state for state, _ in seen}) == stored["reachable_states"]
        else:
            upper, lower = path_labels(arcs, finals, stored["accepting_arc_path"])
            assert upper == lower == stored["witness"]
        checks["language_certificates"] += 1
        del text, arcs, finals, stored
        gc.collect()

for name, data in json.loads((root / "complete-paths.json").read_text()).items():
    att = root / ("02/outputs/parser.att" if name == "parser" else f"06/outputs/{name}.att")
    text, arcs, finals = graph(att)
    assert hashlib.sha256(att.read_bytes()).hexdigest() == data["att_sha256"]
    for check in data["checks"]:
        stored = check["path"]
        if stored["accepted"]:
            upper, lower = path_labels(arcs, finals, stored["arc_path"])
            assert upper == list(check["input"]) == stored["input"]
            assert lower == list(check["requested_output"]) == stored["output"]
        else:
            accepted, seen = reachable(arcs, finals, list(check["input"]))
            assert not accepted
            assert len(seen) == stored["explored_states"]
        checks["complete_paths"] += 1
    del text, arcs, finals
    gc.collect()
print(json.dumps({"passed": True, **checks}, sort_keys=True))
