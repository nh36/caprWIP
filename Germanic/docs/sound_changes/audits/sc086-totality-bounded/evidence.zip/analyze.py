from collections import defaultdict, deque
import gc
import importlib.util
import json
from pathlib import Path
import sys

root = Path(sys.argv[1])
output = Path(sys.argv[2])
output.mkdir(exist_ok=True)
spec = importlib.util.spec_from_file_location("bounded_proof", Path(sys.argv[3]))
proof = importlib.util.module_from_spec(spec)
spec.loader.exec_module(proof)
summary = {}
for path in sorted(root.glob("*.att")):
    if "difference" in path.stem or path.stem in ("HMarked", "HGeneral"):
        continue
    text = path.read_text()
    result = proof.analyze(text)
    if result["functional"]:
        proof.verify(text, result)
    else:
        arcs, finals = proof.read_att(text)
        for side, indices in enumerate(result["witness"]["arc_paths"]):
            state, upper, lower = 0, [], []
            for index in indices:
                source, target, a, b = arcs[index]
                assert state == source
                state = target
                if a != proof.EPSILON:
                    upper.append(a)
                if b != proof.EPSILON:
                    lower.append(b)
            assert state in finals
            assert upper == result["witness"]["input"]
            assert lower == result["witness"]["outputs"][side]
        assert result["witness"]["outputs"][0] != result["witness"]["outputs"][1]
    (output / (path.stem + ".proof.json")).write_text(json.dumps(result, ensure_ascii=False))
    summary[path.stem] = {k: v for k, v in result.items() if k != "delays"}
    (output / "proof-summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2))
    print(path.stem, json.dumps(summary[path.stem], ensure_ascii=False), flush=True)
    del result, text
    gc.collect()

for path in sorted(root.glob("*difference.att")):
    if path.stem == "mapping-head-domain-difference":
        continue
    arcs, finals = proof.read_att(path.read_text())
    adjacent = defaultdict(list)
    for index, (source, target, a, b) in enumerate(arcs):
        assert a == b, "Expected a language acceptor, not a transducer"
        adjacent[source].append((index, target, a))
    parent, pending, found = {0: None}, deque([0]), None
    while pending:
        state = pending.popleft()
        if state in finals:
            found = state
            break
        for index, target, symbol in adjacent[state]:
            if target not in parent:
                parent[target] = (state, index, symbol)
                pending.append(target)
    result = {"empty": found is None, "arcs": len(arcs),
              "att_sha256": proof.hashlib.sha256(path.read_bytes()).hexdigest()}
    if found is None:
        result["reachable_states"] = sorted(parent)
    else:
        indices, symbols, state = [], [], found
        while parent[state] is not None:
            state, index, symbol = parent[state]
            indices.append(index)
            if symbol != proof.EPSILON:
                symbols.append(symbol)
        result["witness"] = list(reversed(symbols))
        result["accepting_arc_path"] = list(reversed(indices))
        result["accepting_state"] = found
    (output / (path.stem + ".language.json")).write_text(json.dumps(result, ensure_ascii=False))
    print(path.stem, {k: v for k, v in result.items()
                      if k != "reachable_states"}, flush=True)
