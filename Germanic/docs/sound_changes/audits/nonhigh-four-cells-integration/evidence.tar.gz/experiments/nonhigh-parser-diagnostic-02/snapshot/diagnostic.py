import argparse
import json
import os
from pathlib import Path
import subprocess
import tempfile

import adoption_assay as assay


def worker(output):
    from anglo_frisian_experiments import compile_isolated, prepare_definition_image
    from sound_change_order_sensitivity import batch_apply_down

    definitions = """
define PGNew [[PGCellInput.u - EnglishProtoNative.u] .o. PGCellInput];
define PGPlain [pgrmStrongPlainHeavy PGCellStem* PGCellEnd];
define PGPrefixed [pgrmStrongPlainHeavyPrefixed PGCellStem* PGCellEnd];
"""
    names = ["EnglishProtoInput", "EnglishProtoNative", "PGCellInput", "PGNew",
             "PGPlain", "PGPrefixed", "OENonHighSyn"]
    recipe = dict(definitions=definitions, insert_after="", insert_rule="", replace={},
                  component_checks=[dict(component=n) for n in names])
    probes = ["gailanai", "gailanananai", "biulanai", "biulanananai",
              "gafúnðanai", "sáiwalǭ", "fúnðanai"]
    with tempfile.TemporaryDirectory(prefix="capr_parser_diagnostic_") as temporary:
        directory = Path(temporary)
        image = prepare_definition_image(assay.G / "fsts/germanic.txt", directory)
        if image:
            os.environ["CAPR_FOMA_DEFINITION_IMAGE"] = str(image)
        bins = compile_isolated(assay.G / "fsts/germanic.txt", recipe, [], directory,
                                components_only=True)
        parses = {n: dict(zip(probes, batch_apply_down(bins["component:" + n], probes)))
                  for n in names if n != "OENonHighSyn"}
        formal = {}
        for n in names:
            p = subprocess.run(
                ["foma", "-q", "-e", "load stack " + bins["component:" + n].name,
                 "-e", "test functional", "-e", "quit"], cwd=directory,
                capture_output=True, text=True, check=True)
            formal[n] = dict(stdout=p.stdout, stderr=p.stderr)
            if n in ("PGPlain", "PGPrefixed", "EnglishProtoNative"):
                p = subprocess.run(
                    ["foma", "-q", "-e", "load stack " + bins["component:" + n].name,
                     "-e", "ambiguous upper", "-e", "print shortest-string", "-e", "quit"],
                    cwd=directory, capture_output=True, text=True, check=True)
                formal[n]["shortest_ambiguous_upper"] = p.stdout
    output.write_text(json.dumps(dict(parses=parses, formal=formal), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--worker", type=Path, required=True)
    worker(parser.parse_args().worker)
