import json
from pathlib import Path
import sys

sys.path.insert(0, "/usr/app/tools")
from executable_facts import define_facts
sys.path.insert(0, "/usr/app/docs/sound_changes/audits/full-cascade-functionality")
from probe import native

directory = Path("/tmp/capr-cascade-formal-01")
facts = define_facts(Path("/usr/app/fsts/germanic.txt"))
pieces = facts["OEVelarPalatalizationStops"].body.split(".o.")
assert len(pieces) == 3
commands = ["source germanic.txt", "clear stack",
            "load stack prefix-061.bin", "define R61;",
            "regex [[?* [á|é|í|ó|ú] ?*] .o. R61];",
            "save stack explicit-stress.bin", "write att > explicit-stress.att",
            "clear stack", "regex [[?* [á|é|í|ó|ú] ?*] .o. EnglishProtoInput];",
            "write att > explicit-stress-parser.att", "clear stack"]
for i, body in enumerate(pieces):
    commands.append(f"define Gp{i} [{body}];")
components = ["OEGFricativePalatal", "OEVelarPalatalizationKFront",
              "Gp0", "Gp1", "Gp2", "OEVelarPalatalizationStops",
              "OEVelarPalatalization"]
for name in components:
    commands += ["clear stack", f"regex [{{*g*g*ē}} .o. {name}];",
                 f"write att > component-{name}.att"]
result = native(commands, directory)
(directory / "followup-native.json").write_text(json.dumps(result, indent=2))
assert result["returncode"] == 0
print("Closed-alphabet component counterexample and explicit-stress exports complete")
