# Class-distinct velar palatalization and fricative merger

## Historical discussion

Singleton g, including initial g, was a fricative when palatalization
occurred; gg and postnasal g were stops. Palatal articulation, productive
cutoff, merger and later affrication are therefore separate questions
[@Fulk2018, pp. 130--132; @Laker2007, pp. 166--168, 175--184].
The dotted spelling in *dæġ* 'day' cannot establish an early affricate or
identify every palatal consonant with inherited j.

The adopted working account keeps a palatal fricative ʝ distinct from j
during mutation, then merges it with j. Ringe and Taylor explicitly propose
this chronology [@RingeTaylor2014, pp. 203--204]. It is not unanimous:
Hogg objects to the phonetic plausibility of delayed merger and leaves the
key/day contradiction unresolved [@Hogg1979, pp. 102--111].
We prefer the regular class-distinct account because it explains the
contrasting mutation triggers without lexical or grammatical conditions.
The objection remains substantive, not silently superseded by a matching
final spelling.

Fulk's earlier comparison treats reversible palatal articulation and later
assibilation separately, but does not establish the particular delayed
singleton-fricative merger used here [@Fulk1998, pp. 145--149].
That merger remains the attributed Ringe--Taylor working account, with
Hogg's objection retained.

Eligibility also requires attribution. Ringe and Taylor's medial-g table
is narrower than Fulk's before-front-vowel description
[@RingeTaylor2014, pp. 203--204; @Fulk2018, pp. 130--132].
The present fricative implementation retains its broader domain; this
merger decision is not a covert adoption of the narrower table.

Barrack's cascade distributes the velar material over several rules:
palatalization proper as rule 170a [@Barrack1975, p. 57], the
palatal/velar alternations of the written period as rule 428, with
\emph{streccan} 'stretch' among the cited forms [@Barrack1975, p. 109], and
the back-and-forth adjustments between palatals and velars as rules
432--435, including the \emph{hwilic} 'which' type and
\emph{ortgeard}/\emph{feccan} [@Barrack1975, pp. 110--112]. His
decomposition is finer than the class-distinct account adopted here and is
keyed to Campbell's paragraphs rather than to the fricative/stop class
distinction; it corroborates the breadth of the palatalization zone without
bearing on the disputed merger chronology, since his orderings are formal,
not chronological [@Barrack1975, p. 34].

## SC052. Singleton-fricative articulation (`OEGFricativePalatal`) {#rule-OEGFricativePalatal}

```foma
define OEGFricativePalatal [
    [{*g}|{*ɣ}] -> {*ʝ} ||
        [.#.|[EnglishStarAlphabet - [{*g}|{*n}|{*ŋ}]]]
        _ EnglishStarFrontVowel,
    [{*g}|{*ɣ}] -> {*ʝ} || EnglishStarFrontVowel _ .#.,
    [{*g}|{*ɣ}] -> {*ʝ} || EnglishStarFrontVowel
        _ [EnglishStarConsonant - [{*j}|{*g}]]
] .o. [
    [{*g}|{*ɣ}] -> {*ʝ} ||
        [.#.|[EnglishStarAlphabet - [{*g}|{*n}|{*ŋ}]]] _ {*j}
];
```

The guards keep gg/ng in their stop paths. The value ʝ is a real phonetic
class, not a tag recording a consonant's ancestry. It is transparent to a
following mutation trigger, but is not itself j at that date.
The source comparison normalizes older fricative notation to modern ɣ/ʝ,
never to the digit 3 [@Hogg1979, p. 105; @RingeTaylor2014, p. 204].

## SC052. K articulation and eventual reflex (`OEVelarPalatalizationKFront`) {#rule-OEVelarPalatalizationKFront}

```foma
define OEVelarPalatalizationKFront [
    {*k} -> {*ʧ} || .#. _ EnglishStarFrontVowel,
    {*k} -> {*ʧ} || _ [{*i} | {*ī}],
    {*k} -> {*ʧ} || _ {*ḯ},
    {*k} -> {*ʧ} || [{*i} | {*ī}] _ EnglishStarFrontVowel,
    {*k} -> {*ʧ} || {*ḯ} _ EnglishStarFrontVowel,
    {*k} -> {*ʧ} || [{*i} | {*ī}] _ .#.,
    {*k} -> {*ʧ} || {*ḯ} _ .#.
] .o. [
    {*k} {*k} -> {*ʧ} {*ʧ} || _ {*j}
] .o. [
    {*k} -> {*ʧ} || _ {*j}
];
```

Here ʧ is a telescoped eventual-reflex proxy, not a claim that early
palatal stops were already affricates. Ringe and Taylor explicitly separate
the initial palatal stop from subsequent affrication and its syncope
dependencies [@RingeTaylor2014, pp. 203--204].
The *weccan* 'wake', *licgan* 'lie' and *lecgan* 'lay' examples concern
inherited j-clusters, not independent proof of every plain-velar conditioner
[@RingeTaylor2014, pp. 213--214].

The deterministic kk-before-j path protects *streċċan* 'stretch'.
The original-front versus secondary-front distinction is more directly
tested by unrounded key than by rounded *cȳ* 'cow'; rounding alone can
give only a cutoff before later unrounding
[@Hogg1979, pp. 100--105; @Laker2007, pp. 167--168].

## SC052. Retained stop paths (`OEVelarPalatalizationStops`) {#rule-OEVelarPalatalizationStops}

```foma
define OEVelarPalatalizationStops [
    OEVelarPalatalizationKFront
] .o. [
    {*g} -> {*ʤ} || _ EnglishStarFrontVowel,
    {*g} -> {*ʤ} || EnglishStarFrontVowel _ .#.,
    {*g} -> {*ʤ} || EnglishStarFrontVowel _ EnglishStarFrontVowel,
    {*g} -> {*ʤ} || EnglishStarFrontVowel _ [EnglishStarConsonant - {*j}],,
    {*g} {*g} -> {*ʤ} {*ʤ} || _ {*j}
] .o. [
    {*g} -> {*ʤ} || _ {*j}
];
```

Singleton fricatives have already left this domain. The remaining gg/ng
paths use ʤ as an eventual-reflex proxy; the initial singleton fricative
is no longer represented as an early affricate. *Wicg* 'horse' is a
geminate-class illustration, *senġan* 'singe' a postnasal control, and
*lungen* 'lung' the unchanged back-vowel negative
[@RingeTaylor2014, pp. 203--204, 213--214; @Fulk2018, pp. 131--132].

The double comma separates the geminate-before-\emph{j} rule's context
from the singleton rules' front-vowel contexts. It corrects rewrite-rule
scoping, not the proposed historical environment, date or consonant-class
distinction. The separate geminate rule must replace the whole cluster,
not permit a competing singleton covering.

## SC052. Combined articulation (`OEVelarPalatalization`) {#rule-OEVelarPalatalization}

```foma
define OEVelarPalatalization Ctx([
    OEGFricativePalatal .o. OEVelarPalatalizationStops
]);
```

The combined operation does not give every class one sharply dated
palatalization/affrication/merger event. It supplies the class distinctions
needed by ordinary palatal diphthongization and mutation.
The common-stem onset remains a separate question
[@Luick1914, pp. 835--841; @Fulk2018, pp. 130--132].

### Key and day at the mutation checkpoint

Hogg's oblique comparison starts here from pre-palatal, pre-OE
\emph{*kājæ} and \emph{*dæɣæ}; neither is silently fed through a PGmc
prefix [@Hogg1979, p. 105]. The source target is *cǣġe* 'key',
with velar initial k, versus *dæġe* 'day'.

| Checkpoint | Key | Day under the adopted account |
|---|---|---|
| Before palatalization | \emph{*kājæ} | \emph{*dæɣæ} |
| Before mutation | Inherited j remains | Palatal ʝ is distinct from j |
| After mutation | \emph{*kǣjæ}, without new initial palatalization | \emph{*dæʝæ}, without æ-raising |
| After merger and native realization | *cǣġe* | *dæġe* |

Premature merger instead predicts pre-OE [dejæ]{.pred} under
these premises. The experiment tests that source-based contrast; the
existing day nominative is not the oblique discriminator
[@Hogg1979, pp. 105--110; @RingeTaylor2014, p. 204].

The complete key suffix additionally requires
[SC082 OEIntervocalicJVocalization](#rule-OEIntervocalicJVocalization)
to retain j after its non-high long front vowel. A correct mutation
checkpoint followed by model-only [*cǣie*]{.pred} would not constitute a
correct native derivation [@Hogg1979, p. 105].
