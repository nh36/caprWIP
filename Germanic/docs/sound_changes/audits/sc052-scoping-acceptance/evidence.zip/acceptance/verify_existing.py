import hashlib
import importlib.util
import json
from pathlib import Path
import tarfile

ROOT = Path.cwd()
base = ROOT / "Germanic/docs/sound_changes/audits"
capsule = base / "full-cascade-functionality/repair-evidence.tar.gz"
assert hashlib.sha256(capsule.read_bytes()).hexdigest() == (
    "25a41ea59695fd179a324b715baf295bb8ea72fcaa42418e0b40bc6f63a3939e")
with tarfile.open(capsule) as archive:
    manifest = json.load(archive.extractfile("repair-manifest.json"))
    for name, expected in manifest.items():
        assert hashlib.sha256(archive.extractfile(name).read()).hexdigest() == expected
    source = (ROOT / "Germanic/fsts/germanic.txt").read_bytes()
    assert source == archive.extractfile("fst.txt").read()
    scoped = archive.extractfile("scoped.txt").read()
    assert len(scoped) == len(source) + 1
    assert scoped.replace(b",,", b",", 1) == source
    spec = importlib.util.spec_from_file_location(
        "sc052_adoption_certificate", base / "parser-formal-resolution/functionality.py")
    proof = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(proof)
    for name in ("scoped-OEVelarPalatalizationStops",
                 "scoped-OEVelarPalatalization", "candidate-prefix-061"):
        text = archive.extractfile(name + ".att").read().decode()
        certificate = json.load(archive.extractfile(name + ".proof.json"))
        proof.verify(text, certificate)
    regression = json.load(archive.extractfile("regression.json"))
    assert regression["population"] == 391 and regression["matches"] == 383
    assert not regression["stage_changes"] and not regression["missing"]
    assert not regression["ambiguous"] and len(regression["mismatches"]) == 8
    assert all(control["ok"] for control in json.load(
        archive.extractfile("component-controls.json")))
    target = ROOT / ".capr-work/sc052-adoption/targets/Germanic/fsts/germanic.txt"
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(scoped)
print("PASS: complete capsule integrity, exact one-character source delta, "
      "independent global stop/wrapper/stage62 certificate replay, and "
      "complete391/110-stage regression reuse. Full-cascade functionality "
      "and totality are not certified.")
