import json
import os
from pathlib import Path
import sys

sys.path.insert(0, "/usr/app/tools")
import anglo_frisian_experiments as af
from sound_change_order_sensitivity import batch_apply_down, outputs_match_expected

source, recipes, rows, output = map(Path, sys.argv[1:])
os.environ["CAPR_FOMA_DEFINITION_IMAGE"] = "/tmp/capr-sc042-counterfactuals-20261111/image/defined.bin"
packet = af.load_recipes(recipes)
recipe = next(value for value in packet["recipes"] if value["id"] == "nasal-early-unrounding")
directory = output.parent / "prototype"
directory.mkdir()
assert af.definition_image_source(source.read_text(), directory).startswith("load defined ")
bins = af.compile_isolated(source, recipe, packet["probes"], directory)
population = json.loads(rows.read_text())
forms = [row["fst_input"] for row in population]
finals = batch_apply_down(bins["final"], forms)
intermediates = af.intermediate_outputs(bins, forms)
raw = ["rátōz", "rátǭ", "gébōz", "gébǭ", "gébôz", "námô"]
result = {
    "source_sha256": af.digest(source), "recipes_sha256": af.digest(recipes),
    "rows_sha256": af.digest(rows), "recipe": recipe,
    "accepted": len(population),
    "matches": sum(outputs_match_expected(value, row["counterpart"])
                   for row, value in zip(population, finals)),
    "no_output": sum(not value for value in finals),
    "multiple_output": sum(len(value) > 1 for value in finals),
    "rows": [{**row, "outputs": value, "changed": value != row["baseline_outputs"],
              "intermediates": {key: values[index] for key, values in intermediates.items()}}
             for index, (row, value) in enumerate(zip(population, finals))],
    "phonological_controls": {"raw": raw, "outputs": batch_apply_down(bins["final"], raw)},
    "binary_sha256": {key: af.digest(path) for key, path in bins.items()},
}
result["changed"] = sum(row["changed"] for row in result["rows"])
output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({key: value for key, value in result.items()
                  if key not in {"rows", "recipe"}}, ensure_ascii=False, indent=2), flush=True)
print("CHANGED", json.dumps([row for row in result["rows"] if row["changed"]],
                            ensure_ascii=False, indent=2), flush=True)
assert result["phonological_controls"]["outputs"] == [
    ["ræte"], ["ræte"], ["ġiefe"], ["ġiefe"], ["ġiefa"], ["nama"]]
assert result["no_output"] == result["multiple_output"] == 0
