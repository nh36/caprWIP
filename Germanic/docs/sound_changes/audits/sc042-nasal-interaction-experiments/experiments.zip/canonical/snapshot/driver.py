import hashlib
import json
from pathlib import Path
import sys

sys.path.insert(0, "/usr/app/tools")
from capr_runtime import layout
import oe_pipeline
from sound_change_order_sensitivity import batch_apply_down

rt = layout()
forms = ["rátōz", "rátǭ", "gébōz", "gébǭ", "fláskōn", "márōn"]
checkpoints = {
    "EnglishProtoInput", "PNWGmcNStemNLoss",
    "PWGmcSurvivingBimoricOUnrounding", "EAFBrightening",
    "EAFBrighteningLongFinal", "OEARestoration",
    "OEUnstressedLongVowelShortening", "OEUnstressedAEMerger",
}
records = []
for stage in oe_pipeline.named_stages():
    if stage.foma_identifier in checkpoints:
        binary = rt.bin_dir / stage.snapshot_bin
        records.append({
            "stage": stage.foma_identifier,
            "binary_sha256": hashlib.sha256(binary.read_bytes()).hexdigest(),
            "outputs": batch_apply_down(binary, forms),
        })
binary = rt.bin_dir / "old_english.bin"
finals = batch_apply_down(binary, forms)
print(json.dumps({
    "fst_sha256": hashlib.sha256(rt.germanic_fst.read_bytes()).hexdigest(),
    "raw_inputs": forms, "checkpoints": records,
    "final_bin_sha256": hashlib.sha256(binary.read_bytes()).hexdigest(),
    "final_outputs": finals,
    "nasal_oral_low_root_equivalent": finals[0] == finals[1],
    "nasal_oral_source_example_equivalent": finals[2] == finals[3],
}, ensure_ascii=False, indent=2))
assert all(len(value) == 1 for value in finals), "An input was rejected or ambiguous."
assert finals[2] == finals[3] == ["ġiefe"], "Source-example merger failed."
assert finals[0] == finals[1], "Delayed nasal proxy changes the root-vowel development."
