import json
import sys
from pathlib import Path

sys.path.insert(0, "/usr/app/tools")
from anglo_frisian_experiments import compile_isolated, complete_variant_order, corpus_rows
import oe_pipeline
from sound_change_order_sensitivity import batch_apply_down

root, out = map(Path, sys.argv[1:])
out.mkdir()
recipe = json.loads((root / "recipe.json").read_text())
forms = ["sáli-wàrðaz", "sáli-wàrðuz", "sáli-wàrðą",
         "xánðu-sàxsan", "xánðu-sàxsą"]
controls = [
    "*ʃ*y*l*d*i*ç*ǣ*t*j*ā",
    "*s*e*l*i*w*ea*r*d",
    "*l*a*n*d*w*ì*n*a",
    "*l*a*n*d*x*ù*s*a",
    "*x*a*n*d*u*s*ea*x",
    "*ȳ*t*y*m*i*s*t",
    "*b*o*n*d*i*n*s*t*a",
]
rows = corpus_rows(root / "corpus.tsv")
report = {}
for variant in ("late", "no-high", "light-loss"):
    candidate = dict(recipe)
    inline_definitions = recipe["definitions"].split("define AFHiSyn ")[0]
    if variant == "no-high":
        candidate["definitions"] = inline_definitions + """define AFHiSyn FootCtx([
            {*y} -> {*i} || EnglishStarVocalic OEAnyConsonant+ _])
            .o. Ctx([{*ì} -> {*i}, {*ù} -> {*u}, {*ỳ} -> {*y}]);"""
    elif variant == "light-loss":
        candidate["definitions"] = inline_definitions + """define AFHiSyn FootCtx([
            [{*i}|{*u}|{*y}] -> 0
                || .#. OEAnyConsonant* EnglishStarVocalic OEAnyConsonant+
                    _ OEAnyConsonant EnglishStarVocalic
        ]) .o. FootCtx([{*y} -> {*i} || EnglishStarVocalic OEAnyConsonant+ _])
        .o. Ctx([{*ì} -> {*i}, {*ù} -> {*u}, {*ỳ} -> {*y}]);"""
    directory = out / variant
    directory.mkdir()
    order = complete_variant_order(candidate)
    named = [name for name in order if name.isidentifier()]
    bins = compile_isolated(root / "source.txt", candidate, [], directory,
                            diagnostic_stages=named if variant == "late" else None)
    result = {
        "canonical": dict(zip(forms, batch_apply_down(bins["final"], forms))),
        "bailiff_post_umlaut": batch_apply_down(bins["staged:bailiff-post-umlaut"],
                                              ["*ʃ*y*l*d*i*ç*ǣ*t*j*ā"]),
        "bailiff_preoe": batch_apply_down(bins["staged:bailiff-preoe"],
                                        ["*s*k*ú*l*d*i*x*ā*t*i*j*ā"]),
        "furthest_post_umlaut": batch_apply_down(bins["staged:furthest-post-umlaut"],
                                               ["*ȳ*t*y*m*i*s*t"]),
        "furthest_preoe": batch_apply_down(bins["staged:furthest-preoe"],
                                         ["*ū*t*u*m*i*s*t"]),
        "companion_preoe": batch_apply_down(bins["staged:companion-preoe"],
                                          ["*g*á*d*u*l*i*n*g"]),
        "double_umlaut": batch_apply_down(
            bins["component:OEIUmlaut"],
            ["*ū*t*u*m*i", "*g*a*d*u*l*i*n*g",
             "*ū*t*a*m*i", "*ū*t*ù*m*i"]),
        "high_controls": dict(zip(controls, batch_apply_down(
            bins["component:AFHiSyn"], controls))),
        "breaking": batch_apply_down(bins["component:OEBreaking"],
                                    ["*f*u*l*w*i*x*t", "*s*æ*l*ì*w*æ*r*d"]),
        "selected": [
            {**row, "outputs": outputs}
            for row, outputs in zip(rows, batch_apply_down(
                bins["final"], [row["fst_input"] for row in rows]))
        ],
    }
    stressed = ["*l*á*n*d*x*ù*m*i", "*l*á*n*d*w*ì*n*a"]
    for component in ("OEStripSecondaryStress", "OEBreaking", "OEIUmlaut", "AFHiSyn"):
        stressed = [outputs[0] if len(outputs) == 1 else str(outputs)
                    for outputs in batch_apply_down(bins["component:" + component], stressed)]
    result["stressed_high_pipeline"] = stressed
    if variant == "late":
        stages = {name: bins["diagnostic:" + str(i)] for i, name in enumerate(named)}
        current = batch_apply_down(bins["component:EnglishProtoInput"],
                                   [row["fst_input"] for row in rows])
        traces = [{"stage": "EnglishProtoInput", "forms": current}]
        inline = {stage.inline_text: "ABI" + str(stage.exec_index)
                  for stage in oe_pipeline.stages() if stage.kind == "inline"}
        stages.update({name: bins["component:" + name] for name in inline.values()})
        for member in order[order.index("EnglishProtoInput") + 1:]:
            name = member if member.isidentifier() else inline[member]
            inputs = sorted({form for outputs in current for form in outputs})
            outputs = dict(zip(inputs, batch_apply_down(stages[name], inputs)))
            current = [sorted({value for form in group for value in outputs[form]})
                       for group in current]
            traces.append({"stage": name, "forms": current})
        assert current == [row["outputs"] for row in result["selected"]]
        result["named_traces"] = traces
    report[variant] = result
(out / "report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({name: {key: value for key, value in result.items()
                        if key not in ("selected", "named_traces")}
                  for name, result in report.items()},
                 ensure_ascii=False, indent=2))
