import json
import sys
from pathlib import Path

sys.path.insert(0, "/usr/app/tools")
from anglo_frisian_experiments import compile_isolated, corpus_rows
from sound_change_order_sensitivity import batch_apply_down

root, out = map(Path, sys.argv[1:])
out.mkdir()
recipe = json.loads((root / "recipe.json").read_text())
bins = compile_isolated(root / "source.txt", recipe, [], out)
forms = ["sáli-wàrðaz", "sáli-wàrðuz", "sáli-wàrðą",
         "xánðu-sàxsan", "xánðu-sàxsą"]
controls = [
    "*ʃ*y*l*d*i*h*ǣ*t*j*ā",
    "*s*e*l*i*w*ea*r*d",
    "*l*a*n*d*w*ì*n*a",
    "*l*a*n*d*h*ù*s*a",
    "*h*a*n*d*u*s*ea*x",
]
rows = corpus_rows(root / "corpus.tsv")
report = {
    "canonical": dict(zip(forms, batch_apply_down(bins["final"], forms))),
    "bailiff_stage": batch_apply_down(bins["staged:bailiff-post-umlaut"],
                                    ["*ʃ*y*l*d*i*h*ǣ*t*j*ā"]),
    "high_controls": dict(zip(controls, batch_apply_down(
        bins["component:AFHiSyn"], controls))),
    "breaking": batch_apply_down(bins["component:OEBreaking"],
                                ["*f*u*l*w*i*x*t", "*s*æ*l*ì*w*æ*r*d"]),
    "selected": [
        {**row, "outputs": outputs}
        for row, outputs in zip(rows, batch_apply_down(
            bins["final"], [row["fst_input"] for row in rows]))
    ],
}
(out / "report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({key: value for key, value in report.items() if key != "selected"},
                 ensure_ascii=False, indent=2))
