import json
from pathlib import Path
import subprocess
import sys

root, output = map(Path, sys.argv[1:])
output.mkdir()
sys.path.insert(0, "/usr/app/tools")
sys.path.insert(0, str(root))
from anglo_frisian_experiments import compile_isolated
import alignment
import functionality

relations = []
for name in ("old", "new"):
    directory = output / name
    directory.mkdir()
    recipe = {"definitions": "", "replace": {}, "insert_rule": None, "insert_after": None,
              "component_checks": [{"component": "EnglishProtoInput"}]}
    bins = compile_isolated(root / (name + ".txt"), recipe, [],
                            directory, components_only=True)
    subprocess.run(
        ["foma", "-q", "-e", "load stack " + str(bins["component:EnglishProtoInput"]),
         "-e", "print att > " + str(directory / "input.att"), "-e", "quit"],
        capture_output=True, text=True, check=True, timeout=600)
    relations.append((directory / "input.att").read_text())
domain = alignment.domain_check(relations, lambda flags: not flags[0] or flags[1])
a, fa = functionality.read_att(relations[0])
b, fb = functionality.read_att(relations[1])
offset = 1 + max(p for arc in a for p in arc[:2])
arcs = [(0, 1, "@0@", "@0@"), (0, offset + 1, "@0@", "@0@")]
arcs += [(p + 1, q + 1, x, y) for p, q, x, y in a]
arcs += [(p + offset + 1, q + offset + 1, x, y) for p, q, x, y in b]
union = alignment.att_text(arcs, {p + 1 for p in fa} | {p + offset + 1 for p in fb})
certificate = functionality.analyze(union)
assert domain["valid"] and certificate["functional"], (domain, certificate)
functionality.verify(union, certificate)
(output / "union.att").write_text(union)
(output / "certificate.json").write_text(json.dumps(certificate, indent=2) + "\n")
(output / "domain.json").write_text(json.dumps(domain, indent=2) + "\n")
print(json.dumps({"old_domain_subset": domain, "union_functional": True}))
