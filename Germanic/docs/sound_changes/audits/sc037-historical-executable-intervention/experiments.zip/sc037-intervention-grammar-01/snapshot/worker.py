import json
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, "/usr/app/tools")
from anglo_frisian_experiments import compile_isolated
from sound_change_order_sensitivity import batch_apply_down

root, out = map(Path, sys.argv[1:])
out.mkdir()
recipe = json.loads((root / "recipe.json").read_text())
inputs = [
    "sáli-wàrðaz", "sáli-wàrðuz", "sáli-wàrdaz", "sáli-wàrduz",
    "sáli-wàrðą", "sáli-wàrdą", "régna-bùgô", "síu-wàrdaz",
    "siu-wardaz", "sáli-wàrð", "sáli-wàrða", "xándu-sàxsan",
]
report = {"inputs": inputs, "variants": {}}
components = [entry["component"] for entry in recipe["component_checks"]]
for variant in ("base", "broad", "bounded", "dental"):
    directory = out / variant
    directory.mkdir()
    bins = compile_isolated(root / (variant + ".txt"), recipe, [], directory,
                            components_only=True)
    results = {name: batch_apply_down(bins["component:" + name], inputs)
               for name in components}
    results["native_functionality"] = subprocess.run(
        ["foma", "-q", "-e", "load stack " + str(bins["component:EnglishProtoNative"]),
         "-e", "test functional", "-e", "quit"],
        capture_output=True, text=True, check=True).stdout.strip()
    for name in ("EnglishProtoNative", "EnglishProtoInput"):
        subprocess.run(
            ["foma", "-q", "-e", "load stack " + str(bins["component:" + name]),
             "-e", "write att > " + str(directory / (name + ".att")), "-e", "quit"],
            capture_output=True, text=True, check=True)
    report["variants"][variant] = results
report["interpretation"] = (
    "Diagnostic recognition and ambiguity only. Printed Orel nominatives and regular "
    "a-stem accusative are historical hypotheses, not newly admitted lexical data. "
    "siu controls test preservation of the formerly accepted atomic diphthong reading.")
(out / "report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
print(json.dumps(report, ensure_ascii=False, indent=2))
