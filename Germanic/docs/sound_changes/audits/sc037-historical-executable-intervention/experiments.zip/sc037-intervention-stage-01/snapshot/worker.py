import hashlib
import json
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, "/usr/app/tools")
from anglo_frisian_experiments import compile_isolated
from sound_change_order_sensitivity import batch_apply_down

root, out = map(Path, sys.argv[1:])
out.mkdir()
recipe = json.loads((root / "recipe.json").read_text())
with tempfile.TemporaryDirectory(prefix="sc037_stage_") as temporary:
    bins = compile_isolated(root / "source.txt", recipe, [], Path(temporary),
                            components_only=True)
    cases = {
        "OEBreaking": [
            "*f*u*l*w*i*x*t", "*n*ā*w*i*x*t",
            "*s*i*w*a*n", "*s*í*w*a*n", "*s*i*w*i",
            "*s*æ*l*ì*w*æ*r*d", "*ᶠ*b*i*s*i*w*a*n",
        ],
        "OECompoundLinkingSyncope": [
            "*s*á*l*i*w*à*r*d*a", "*x*á*n*d*u*s*à*x*s*a",
        ],
        "AFPostUmlaut": ["*s*c*y*l*d*i*h*ǣ*t*j*ā"],
        "OEMedialSyncope": ["*s*c*y*l*d*i*h*ǣ*t*j*ā"],
        "OELAdjacentSyncope": ["*x*y*g*i*l*ā*k"],
    }
    report = {
        "source_sha256": hashlib.sha256((root / "source.txt").read_bytes()).hexdigest(),
        "cases": {
            name: [{"input": form, "outputs": outputs}
                   for form, outputs in zip(forms, batch_apply_down(
                       bins["component:" + name], forms))]
            for name, forms in cases.items()
        },
        "source_roles": {
            "fulwiht/nawiht": "Source-backed unstressed breaking controls, Hogg6.7-6.8",
            "sali/handu": "Premised Orel compound analyses, not independent formation dates",
            "scyldihætja": "Ringe-Taylor267 post-umlaut stage; NOT a PGmc derivation",
            "hygi-lak": "Conditional name analysis; no new formation date inferred",
        },
    }
    (out / "report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps(report, ensure_ascii=False, indent=2))
