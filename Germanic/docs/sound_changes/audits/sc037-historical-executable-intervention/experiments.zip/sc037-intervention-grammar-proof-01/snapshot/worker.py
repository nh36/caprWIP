import json
import sys
from pathlib import Path

root = Path(sys.argv[1])
sys.path.insert(0, str(root))
import alignment
import functionality

old = (root / "old.att").read_text()
new = (root / "new.att").read_text()
domain = alignment.domain_check([old, new], lambda flags: not flags[0] or flags[1])
arcs_a, finals_a = functionality.read_att(old)
arcs_b, finals_b = functionality.read_att(new)
offset = 1 + max(p for arc in arcs_a for p in arc[:2])
arcs = [(0, 1, "@0@", "@0@"), (0, offset + 1, "@0@", "@0@")]
arcs += [(p + 1, q + 1, a, b) for p, q, a, b in arcs_a]
arcs += [(p + offset + 1, q + offset + 1, a, b) for p, q, a, b in arcs_b]
finals = {p + 1 for p in finals_a} | {p + offset + 1 for p in finals_b}
union = alignment.att_text(arcs, finals)
certificate = functionality.analyze(union)
if certificate["functional"]:
    functionality.verify(union, certificate)
(root.parent / "staging" / "domain.json").write_text(json.dumps(domain, indent=2) + "\n")
(root.parent / "staging" / "union-functionality.json").write_text(
    json.dumps(certificate, indent=2) + "\n")
print(json.dumps({"old_domain_subset": domain, "union_functional": certificate["functional"]}))
assert domain["valid"] and certificate["functional"]
