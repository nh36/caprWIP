import json
import sys
from pathlib import Path

sys.path.insert(0, "/usr/app/tools")
from anglo_frisian_experiments import compile_isolated, corpus_rows
from sound_change_order_sensitivity import batch_apply_down

root, out = map(Path, sys.argv[1:])
out.mkdir()
recipe = json.loads((root / "recipe.json").read_text())
suffix = json.loads((root / "suffix.json").read_text())
diagnostics = [stage["name"] for stage in suffix if stage["kind"] == "named"]
hypotheses = ["sáli-wàrðaz", "sáli-wàrðuz", "sáli-wàrðą",
              "xánðu-sàxsan", "xánðu-sàxsą"]
controls = ["*s*i*w*a*n", "*s*í*w*a*n", "*s*i*w*i", "*s*í*w*ī",
            "*s*æ*l*i*w*æ*r*d", "*s*æ*l*ì*w*æ*r*d",
            "*s*æ*l*í*w*æ*r*d", "*ᶠ*b*i*s*i*w*a*n",
            "*b*i*r*x*t", "*b*í*r*x*t*i", "*s*æ*l*i*r*θ*a",
            "*s*æ*l*i*x*a"]
rows = corpus_rows(root / "corpus.tsv")
report = {"hypotheses": hypotheses, "controls": controls,
          "variants": {}, "selected_count": len(rows)}
protected = {}
for variant in ("incumbent", "grammar", "corrected", "former"):
    directory = out / variant
    directory.mkdir()
    bins = compile_isolated(
        root / (variant + ".txt"), recipe, [], directory,
        diagnostic_stages=diagnostics)
    stages = {name: bins["diagnostic:" + str(i)] for i, name in enumerate(diagnostics)}
    stages.update({stage["name"]: bins["component:" + stage["name"]]
                   for stage in suffix if stage["kind"] == "inline"})
    parser = batch_apply_down(bins["component:EnglishProtoInput"], hypotheses)
    finals = batch_apply_down(bins["final"], hypotheses)
    details = []
    for form, parsed, final in zip(hypotheses, parser, finals):
        current = parsed or ["".join("*" + c for c in form.replace("-", ""))]
        changes, checkpoints = [], {}
        for stage in suffix:
            after = sorted({v for result in batch_apply_down(stages[stage["name"]], current)
                            for v in result})
            if stage["name"] in {"OECompoundLinkingSyncope", "OEBreaking", "OEIUmlaut",
                                  "OEMedUnstressedILowering1"}:
                checkpoints[stage["name"]] = {"before": current, "after": after}
            if after != current:
                changes.append({"stage": stage["name"], "before": current, "after": after})
            current = after
        if parsed:
            assert current == sorted(final), (form, variant, current, final)
        details.append({"input": form, "parser": parsed, "canonical_final": final,
                        "conditional_final": current, "changes": changes,
                        "checkpoints": checkpoints,
                        "status": "Published comparative hypothesis; date not inferred from output"})
    report["variants"][variant] = {
        "hypotheses": details,
        "first_member": batch_apply_down(bins["component:pgrmCompoundFirst"],
                                         ["sáli", "sála", "sá", "síu"]),
        "second_member": batch_apply_down(bins["component:pgrmCompoundSecond"],
                                          ["wàrðaz", "wàrðuz", "wàrdaz"]),
        "breaking": batch_apply_down(bins["component:OEBreaking"], controls),
        "i_umlaut": batch_apply_down(bins["component:OEIUmlaut"], controls),
    }
    selected = [row["fst_input"] for row in rows]
    previous = batch_apply_down(bins["component:EnglishProtoInput"], selected)
    trace = [{"stage": "EnglishProtoInput", "forms": previous}]
    for stage in suffix:
        flat = sorted({value for values in previous for value in values})
        applied = dict(zip(flat, batch_apply_down(stages[stage["name"]], flat)))
        previous = [sorted({v for old in values for v in applied[old]}) for values in previous]
        trace.append({"stage": stage["name"], "forms": previous})
    canonical = batch_apply_down(bins["final"], selected)
    assert previous == canonical, variant
    protected[variant] = trace
    report["variants"][variant]["selected_final"] = canonical
report["selected_changes"] = {}
for variant in ("grammar", "corrected", "former"):
    differences = []
    for old, new in zip(protected["incumbent"], protected[variant]):
        assert old["stage"] == new["stage"]
        for row, a, b in zip(rows, old["forms"], new["forms"]):
            if a != b:
                differences.append({"stage": old["stage"], "row_id": row["id"],
                                    "concept": row["concept"], "before": a, "after": b})
    report["selected_changes"][variant] = differences
(out / "report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
(out / "protected-traces.json").write_text(json.dumps(protected, ensure_ascii=False) + "\n")
print(json.dumps({"selected_count": len(rows),
                  "selected_changes": {key: len(value) for key, value in report["selected_changes"].items()},
                  "finals": {v: [(r["input"], r["canonical_final"]) for r in d["hypotheses"]]
                             for v, d in report["variants"].items()}}, ensure_ascii=False, indent=2))
