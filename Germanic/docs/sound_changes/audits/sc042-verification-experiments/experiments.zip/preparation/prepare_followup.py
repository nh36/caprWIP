import json
from pathlib import Path
import sys

root = Path.cwd()
sys.path.insert(0, str(root / "Germanic/tools"))
import anglo_frisian_experiments as af
import experiment_snapshot
from executable_facts import parse_defines

work = root / ".capr-work/sc042-final-verification"
packet = json.loads((work / "recipes.json").read_text())
base = packet["recipes"][0]
body = parse_defines((root / "Germanic/fsts/germanic.txt").read_text())["EAFFinalZDeletion"].body
needle = "EnglishStarVocalic ?* _ .#."
assert body.count(needle) == 1
changed = body.replace(needle, "[EnglishStarVocalic | {*ô}] ?* _ .#.")
packet["recipes"].append({
    **base, "id": "trimoric-z", "description": "Bounded prospective SC020 second-nucleus recognition of trimoric o; SC042 unchanged.",
    "definitions": "define AF20 [ " + changed + " ];\ndefine AF0 [?*];",
    "insert_after": "PNWGmcFinalLongORaising", "insert_rule": "AF20",
    "replace": {"EAFFinalZDeletion": "AF0"},
    "sources": [{"key": "RingeTaylor2014", "pages": "44-45,58-60"}],
    "assumptions": "Prototype only; original trimoric assertion and failed production observations remain unchanged.",
    "limitations": "No global vowel-inventory expansion; only the second nucleus of the polysyllabic final-z environment is extended.",
})
(work / "followup-recipes.json").write_text(json.dumps(packet, ensure_ascii=False, indent=2) + "\n")
af.load_recipes(work / "followup-recipes.json")
snapshot = experiment_snapshot.create_snapshot(
    "sc042-final-verification-followup-20261112",
    "Independent targeted ordering experiments plus one narrowly scoped conditioning prototype following a preserved genuine negative result.",
    {"recipes": work / "followup-recipes.json", "rows": work / "rows.json",
     "controls": work / "controls.json", "driver": work / "followup_driver.py",
     "original_failure": work / "failed-conditioning-observations.json",
     "diagnosis": work / "trimoric-diagnosis.json",
     "prior_snapshot": Path(json.loads((work / "snapshot.json").read_text())["snapshot"]) / "receipt.json"},
    variants={r["id"]: json.dumps(r, ensure_ascii=False, sort_keys=True) for r in packet["recipes"]},
    probes=packet["probes"], expected_outcomes={"original_assertions": json.loads((work / "controls.json").read_text()),
         "source_positive": "gébôz must derive ġiefa, not reject; gébōz must remain ġiefe.",
         "corpus_protection": "All394 accepted outputs unchanged, zero missing/multiple outputs."},
    negative_controls=["gébōz", "námô", "stressed-monosyllable", "nonfinal-r-negative"],
    environment={"original_source_commit": "88fdcf15130cb42f882888150fa9a6e10ab24759",
                 "compilation_parent": json.loads((work / "snapshot.json").read_text())["parent"]})
(work / "followup-snapshot.json").write_text(json.dumps({"snapshot": str(snapshot.root)}, indent=2) + "\n")
print("Pinned follow-up:", snapshot.root)
