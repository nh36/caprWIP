import hashlib
import json
from pathlib import Path
import sys

root = Path.cwd()
sys.path.insert(0, str(root / "Germanic/tools"))
import anglo_frisian_experiments as af
import experiment_snapshot
import oe_pipeline
from executable_facts import parse_defines
from oe_trace_parse import parse_entries

work = root / ".capr-work/sc042-final-verification"
parent = experiment_snapshot.Snapshot(root / ".capr-work/experiments/sc042-baseline-20261111")
parent.verify()
source = root / "Germanic/fsts/germanic.txt"
old = parse_defines(parent.input_path("germanic_fst").read_text())
new = parse_defines(source.read_text())
assert {k: v.body for k, v in old.items()} == {k: v.body for k, v in new.items()}
trace_path = root / "Germanic/docs/debug_snapshots/oe_full_trace_report.txt"
trace = parse_entries(trace_path.read_text())
previous = parse_entries(parent.input_path("full_trace").read_text())
assert trace.keys() == previous.keys()
assert all(trace[k].stages == previous[k].stages and trace[k].outputs == previous[k].outputs for k in trace)
rows = oe_pipeline.load_rows(root / "Germanic/data/germanic-aligned-final.tsv")
for row in rows:
    row["baseline_outputs"] = trace[(row["concept"], row["proto"], row["counterpart"])].outputs.split(" | ")
(work / "rows.json").write_text(json.dumps(rows, ensure_ascii=False, indent=2) + "\n")
base = {"id": "identity", "description": "Authenticated existing identity; not recompiled.",
        "definitions": "", "insert_after": "", "insert_rule": "", "replace": {},
        "sources": [], "assumptions": "", "limitations": ""}
recipes = [base]
for name, anchor in [("after-z", "EAFFinalZDeletion"),
                     ("after-hiatus", "EAFHiatusWInsertion")]:
    recipes.append({
        **base, "id": name, "description": "Move SC042 after " + anchor,
        "definitions": "define AF42 [ PWGmcSurvivingBimoricOUnrounding ];\ndefine AF0 [?*];",
        "insert_after": anchor, "insert_rule": "AF42",
        "replace": {"PWGmcSurvivingBimoricOUnrounding": "AF0"},
        "sources": [{"key": "RingeTaylor2014", "pages": "55,58-60,149-151,299-300"}],
        "assumptions": "Same selected rows and canonical contexts; unchanged complete definitions.",
        "limitations": "Hiatus probe is a conditional guard diagnostic, not an attested lexeme or independently established historical boundary.",
    })
packet = {"schema_version": 1, "recipes": recipes, "probes": [
    {"id": "moved_before", "stage": "$inserted", "side": "before"},
    {"id": "moved_after", "stage": "$inserted", "side": "after"},
    {"id": "final_before", "stage": "EAFBrighteningLongFinal", "side": "before"},
    {"id": "final_after", "stage": "EAFBrighteningLongFinal", "side": "after"},
]}
(work / "recipes.json").write_text(json.dumps(packet, ensure_ascii=False, indent=2) + "\n")
af.load_recipes(work / "recipes.json")
controls = []
def add(name, value, steps, expected, warrant):
    controls.append({"id": name, "input": value, "steps": steps,
                     "expected": expected, "warrant": warrant})

oral = ["PNWGmcFinalLongORaising", "EAFFinalZDeletion", "PWGmcSurvivingBimoricOUnrounding"]
add("light-surviving-final", "*r*á*t*ō*z", oral, "*r*á*t*ā", "Ringe-Taylor58-59: z-sheltered bimoric final ending.")
add("heavy-surviving-final", "*r*á*s*t*ō*z", oral, "*r*á*s*t*ā", "Same law, not conditioned by preceding syllable weight.")
add("inherited-oral-final", "*r*á*t*ō", oral, "*r*á*t*u", "Ringe-Taylor55: original oral final o had already raised.")
add("heavy-inherited-oral-final", "*r*á*s*t*ō", oral, "*r*á*s*t*u", "Same earlier oral raising; weight does not select unrounding.")
before_r = ["PWGmcEarlyIApocope", "PWGmcFinalOrLowering"]
add("bimoric-before-r", "*w*á*t*ō*r", before_r, "*w*á*t*a*r", "Ringe-Taylor59-60: unrounding and subsequent before-r shortening, telescoped by SC007.")
add("heavy-bimoric-before-r", "*r*á*s*t*ō*r", before_r, "*r*á*s*t*a*r", "Before-r generalization has no light-root restriction.")
add("new-final-r", "*r*á*t*ō*r*i", before_r, "*r*á*t*a*r", "Ringe-Taylor55,58: third-syllable high-vowel loss and newly final consonants.")
add("trimoric-before-r-negative", "*r*á*t*ô*r", before_r, "*r*á*t*ô*r", "Ringe-Taylor58-60: trimoric quantity must not undergo bimoric unrounding; marker retained for later operations.")
add("nonfinal-r-negative", "*r*á*t*ō*r*u", ["PWGmcFinalOrLowering"], "*r*á*t*ō*r*u", "Before r is insufficient: r must be final.")
tail = ["PNWGmcNStemNLoss", "PWGmcSurvivingBimoricOUnrounding",
        "EAFBrighteningLongFinal", "OEUnstressedLongVowelShortening", "OEUnstressedAEMerger"]
add("nasal-stem-adaptation", "*t*ú*n*g*ō*n", tail, "*t*ú*n*g*e", "Existing SC023 normalization, then Ringe-Taylor59 nasal bimoric low/front outcome.")
add("already-nasal-final", "*r*á*t*ǭ", tail, "*r*á*t*e", "Ringe-Taylor55,59: nasal bimoric ending, not already unrounded in the input.")
add("trimoric-final", "*n*á*m*ô", tail, "*n*á*m*a", "Ringe-Taylor59: name quantity contrasts with nasal bimoric final.")
add("z-protected-trimoric", "*r*á*t*ô*z", ["EAFFinalZDeletion"] + tail, "*r*á*t*a", "Ringe-Taylor59: loss of z must not turn trimoric quantity into the bimoric class.")
add("stressed-monosyllable", "*d*ō", ["PNWGmcStressedMonosyllableORaising"] + oral, "*d*ū", "Separate stressed-monosyllable pathway; not the unstressed law.")
add("other-final-consonant", "*r*á*t*ō*s", oral, "*r*á*t*ō*s", "Ringe-Taylor58: other final consonants protect against unrounding.")
add("late-protected-vowel", "*r*á*t*ō*s", oral + ["OELateOShortening", "OEFinalUnstressedOLowering"], "*r*á*t*a*s", "Later o-shortening/final lowering is not early unrounding.")
add("medial-long-o", "*r*á*t*ō*d*u*n", oral, "*r*á*t*ō*d*u*n", "Ringe-Taylor59-60: other unstressed environments retain o.")
add("late-medial-o", "*r*á*t*ō*d*u*n", oral + ["OELateOShortening", "OEMedUnstressedORaising", "OEFinalUnstressedOLowering"], "*r*á*t*u*d*u*n", "Existing late medial/final split, not early unrounding.")
(work / "controls.json").write_text(json.dumps(controls, ensure_ascii=False, indent=2) + "\n")
inputs = {"recipes": work / "recipes.json", "rows": work / "rows.json",
          "controls": work / "controls.json", "driver": work / "driver.py",
          "hypothesis": work / "hypothesis.json", "current_fst": source,
          "current_trace": trace_path, "parent_receipt": parent.receipt_path}
for name in ("anglo_frisian_experiments", "oe_pipeline", "sound_change_order_sensitivity"):
    inputs[name] = root / ("Germanic/tools/" + name + ".py")
snapshot = experiment_snapshot.create_snapshot(
    "sc042-final-verification-20261112", "Bounded distributed conditioning and two current ordering positions; reuse authenticated previous identity and common-definition image.",
    inputs, variants={r["id"]: json.dumps(r, sort_keys=True, ensure_ascii=False) for r in recipes},
    probes=packet["probes"], expected_outcomes={"distributed_controls": controls,
        "ordering": "Measure; no assumed equivalence or historically licensed hiatus witness."},
    negative_controls=[c["id"] for c in controls if "negative" in c["id"] or "trimoric" in c["id"] or "protected" in c["id"]],
    environment={**parent.receipt()["environment"], "compilation_parent": str(parent.root),
                 "current_fst_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
                 "definition_bodies_equal_to_parent": len(new)})
(work / "snapshot.json").write_text(json.dumps({"snapshot": str(snapshot.root), "parent": str(parent.root)}, indent=2) + "\n")
print("Pinned new verification inputs:", snapshot.root)
