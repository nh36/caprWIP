import json
import os
from pathlib import Path
import sys
import time

sys.path.insert(0, "/usr/app/tools")
import anglo_frisian_experiments as af
from sound_change_order_sensitivity import batch_apply_down, outputs_match_expected

source, recipes_path, rows_path, controls_path, output_path = map(Path, sys.argv[1:6])
image = Path("/tmp/capr-sc042-counterfactuals-20261111/image/defined.bin")
os.environ["CAPR_FOMA_DEFINITION_IMAGE"] = str(image)
packet = af.load_recipes(recipes_path)
rows = json.loads(rows_path.read_text())
controls = json.loads(controls_path.read_text())
out = output_path.parent
out.mkdir(parents=True)
if not af.definition_image_source(source.read_text(), out).startswith("load defined "):
    raise RuntimeError("Prior definition image no longer authenticates; do not silently repeat compilation.")
result = {"source_sha256": af.digest(source), "recipes_sha256": af.digest(recipes_path),
          "rows_sha256": af.digest(rows_path), "controls_sha256": af.digest(controls_path),
          "definition_image_reused": json.loads(image.with_suffix(".json").read_text()),
          "identity": "Authenticated prior identity and current full traces reused, not re-executed.",
          "accepted": len(rows), "controls": [], "variants": {}}
def save():
    output_path.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")

directory = out / "components"
directory.mkdir()
networks = sorted({s for c in controls for s in c["steps"]} | {
    "EAFHiatusWInsertion", "EAFLongANasalRounding", "EAFNasalizedLowRounding",
    "EAFLongAFronting", "OEStripSecondaryStress", "NWGmcInStemNLoss",
    "EAFBrighteningUnstressed", "EAFBrightening",
})
bins = af.compile_isolated(source, packet["recipes"][0], [], directory,
                           components_only=True, diagnostic_stages=networks)
components = {name: bins["diagnostic:" + str(i)] for i, name in enumerate(networks)}
for control in controls:
    state, steps = [control["input"]], []
    for stage in control["steps"]:
        actual = batch_apply_down(components[stage], state)
        if len(actual) != 1 or len(actual[0]) != 1:
            raise RuntimeError("Control became missing/ambiguous: " + control["id"])
        state = actual[0]
        steps.append({"stage": stage, "outputs": state})
    result["controls"].append({**control, "outputs": state, "steps": steps,
                               "passed": state == [control["expected"]]})
save()
failed = [c["id"] for c in result["controls"] if not c["passed"]]
print("Distributed controls:", len(controls), "failed:", failed, flush=True)
if failed:
    raise RuntimeError("Independently predicted distributed controls failed: " + str(failed))

forms = [row["fst_input"] for row in rows]
for recipe in packet["recipes"]:
    if recipe["id"] == "identity":
        continue
    directory = out / recipe["id"]
    directory.mkdir()
    start = time.monotonic()
    variant_bins = af.compile_isolated(source, recipe, packet["probes"], directory)
    finals = batch_apply_down(variant_bins["final"], forms)
    probes = af.intermediate_outputs(variant_bins, forms)
    record = {"elapsed_seconds": time.monotonic() - start,
              "order": af.complete_variant_order(recipe),
              "matches": sum(outputs_match_expected(v, r["counterpart"]) for r, v in zip(rows, finals)),
              "no_output": sum(not v for v in finals), "multiple_output": sum(len(v) > 1 for v in finals),
              "rows": [{**r, "outputs": v, "changed": v != r["baseline_outputs"],
                        "intermediates": {key: values[i] for key, values in probes.items()}}
                       for i, (r, v) in enumerate(zip(rows, finals))]}
    record["changed"] = sum(r["changed"] for r in record["rows"])
    result["variants"][recipe["id"]] = record
    save()
    print(recipe["id"], {k: record[k] for k in ("elapsed_seconds", "matches", "changed", "no_output", "multiple_output")}, flush=True)

result["hiatus_diagnostic"] = {}
for name, sequence in {
    "early": ["PWGmcSurvivingBimoricOUnrounding", "EAFHiatusWInsertion", "EAFBrighteningLongFinal"],
    "post-hiatus": ["EAFHiatusWInsertion", "PWGmcSurvivingBimoricOUnrounding", "EAFBrighteningLongFinal"],
}.items():
    state, steps = ["*t*ā*ō"], []
    for stage in sequence:
        state = batch_apply_down(components[stage], state)[0]
        steps.append({"stage": stage, "outputs": state})
    result["hiatus_diagnostic"][name] = {"input": "*t*ā*ō", "steps": steps, "outputs": state,
        "status": "Conditional structural probe, not an attested or independently reconstructed lexeme."}
save()
print("Hiatus diagnostic:", result["hiatus_diagnostic"], flush=True)
