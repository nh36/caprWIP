import json
import os
from pathlib import Path
import sys
import time

sys.path.insert(0, "/usr/app/tools")
import anglo_frisian_experiments as af
from sound_change_order_sensitivity import batch_apply_down, outputs_match_expected

source, recipes_path, rows_path, controls_path, output_path = map(Path, sys.argv[1:6])
image = Path("/tmp/capr-sc042-counterfactuals-20261111/image/defined.bin")
os.environ["CAPR_FOMA_DEFINITION_IMAGE"] = str(image)
packet = af.load_recipes(recipes_path)
rows = json.loads(rows_path.read_text())
controls = json.loads(controls_path.read_text())
out = output_path.parent
out.mkdir(parents=True)
assert af.definition_image_source(source.read_text(), out).startswith("load defined ")
result = {"source_sha256": af.digest(source), "recipes_sha256": af.digest(recipes_path),
          "rows_sha256": af.digest(rows_path), "controls_sha256": af.digest(controls_path),
          "definition_image_reused": json.loads(image.with_suffix(".json").read_text()),
          "identity": "Existing authenticated identity and current full traces reused, not repeated.",
          "accepted": len(rows), "variants": {}}
def save():
    output_path.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")

forms = [row["fst_input"] for row in rows]
for recipe in packet["recipes"]:
    if recipe["id"] == "identity":
        continue
    directory = out / recipe["id"]
    directory.mkdir()
    start = time.monotonic()
    extra = sorted({s for c in controls for s in c["steps"]} | {
        "EAFHiatusWInsertion", "EAFBrighteningLongFinal", "PWGmcSurvivingBimoricOUnrounding"})
    if recipe["id"] == "trimoric-z":
        extra.remove("EAFFinalZDeletion")
        extra.append("AF20")
    else:
        extra = []
    bins = af.compile_isolated(source, recipe, packet["probes"], directory, diagnostic_stages=extra)
    finals = batch_apply_down(bins["final"], forms)
    probes = af.intermediate_outputs(bins, forms)
    record = {"elapsed_seconds": time.monotonic() - start,
              "order": af.complete_variant_order(recipe),
              "matches": sum(outputs_match_expected(v, r["counterpart"]) for r, v in zip(rows, finals)),
              "no_output": sum(not v for v in finals), "multiple_output": sum(len(v) > 1 for v in finals),
              "rows": [{**r, "outputs": v, "changed": v != r["baseline_outputs"],
                        "intermediates": {key: values[i] for key, values in probes.items()}}
                       for i, (r, v) in enumerate(zip(rows, finals))]}
    record["changed"] = sum(r["changed"] for r in record["rows"])
    result["variants"][recipe["id"]] = record
    save()
    print(recipe["id"], {k: record[k] for k in ("elapsed_seconds", "matches", "changed", "no_output", "multiple_output")}, flush=True)
    if recipe["id"] != "trimoric-z":
        continue
    components = {name: bins["diagnostic:" + str(i)] for i, name in enumerate(extra)}
    checked = []
    for control in controls:
        state, steps = [control["input"]], []
        for stage in control["steps"]:
            component = "AF20" if stage == "EAFFinalZDeletion" else stage
            actual = batch_apply_down(components[component], state)
            assert len(actual) == 1 and len(actual[0]) == 1, control["id"]
            state = actual[0]
            steps.append({"stage": component, "outputs": state})
        checked.append({**control, "steps": steps, "outputs": state,
                        "passed": state == [control["expected"]]})
    record["controls"] = checked
    raw = ["gébôz", "gébōz", "námô"]
    record["source_positives"] = {"raw": raw, "outputs": batch_apply_down(bins["final"], raw),
                                  "expected": [["ġiefa"], ["ġiefe"], ["nama"]]}
    result["hiatus_diagnostic"] = {}
    for name, sequence in {
        "early": ["PWGmcSurvivingBimoricOUnrounding", "EAFHiatusWInsertion", "EAFBrighteningLongFinal"],
        "post-hiatus": ["EAFHiatusWInsertion", "PWGmcSurvivingBimoricOUnrounding", "EAFBrighteningLongFinal"],
    }.items():
        state, steps = ["*t*ā*ō"], []
        for stage in sequence:
            state = batch_apply_down(components[stage], state)[0]
            steps.append({"stage": stage, "outputs": state})
        result["hiatus_diagnostic"][name] = {"input": "*t*ā*ō", "steps": steps, "outputs": state,
            "status": "Conditional structural probe, not an attested or independently reconstructed lexeme."}
    save()
    assert all(c["passed"] for c in checked), [c for c in checked if not c["passed"]]
    assert record["source_positives"]["outputs"] == record["source_positives"]["expected"]
    assert record["changed"] == record["no_output"] == record["multiple_output"] == 0
print("All new measurements completed; prototype is not a production adoption.", flush=True)
